"""Serializer for the deletion-audit output contract (Requirements 11.1-11.6).

This module turns in-memory :class:`~ghost_audit.models.Step` /
:class:`~ghost_audit.models.CaseResult` values into the exact ``output.csv``
artifact required by the challenge contract (AGENTS.md §6.3).

Canonical JSON
--------------

``steps_to_json`` serializes a step list with
``json.dumps(obj, sort_keys=True, separators=(",", ":"))``:

- ``sort_keys=True`` yields a canonical (alphabetical) object-key order, so
  repeated serialization of the same steps is byte-identical -- idempotent
  serialization (Requirement 16.3). The grader ignores object-key order and
  whitespace, so the alphabetical order is safe and deterministic, and matches
  the alphabetical-key rows seen in ``sample_output.csv``.
- ``separators=(",", ":")`` produces compact output with no incidental
  whitespace.

Each serialized step object contains EXACTLY these seven fields and no others:
``step_no``, ``phase``, ``system_id``, ``resource_id``, ``operation``,
``state``, ``evidence_id`` (design "Output JSON Step Schema"). ``step_no`` is a
JSON number (int); the rest are strings.

Round trip
----------

``json_to_steps`` parses a ``steps_json`` string back into ``list[Step]``,
preserving array order (Requirements 11.5, 11.6). Array order is independent of
object-key sorting, so ``json_to_steps(steps_to_json(x)) == x`` holds for any
step list built from the seven fields above.

CSV
---

``write_output`` writes ``output.csv`` at the repository root with the exact
header ``case_id,deletion_status,steps_json``, one row per
:class:`~ghost_audit.models.CaseResult`, rows sorted by ``case_id`` ascending
(Requirements 11.1, 11.3). The standard-library ``csv`` writer with
``QUOTE_MINIMAL`` quotes the ``steps_json`` column automatically (it contains
commas and quotes) and escapes embedded ``"`` as ``""``. The file is opened with
``newline=""`` and ``encoding="utf-8"`` for correct, cross-platform CSV output.

``build_rows`` fills in any missing ``case_id`` from the full request list with a
safe default of ``NOT_APPLICABLE`` / ``[]`` so every case emits exactly one row
(Requirements 11.2, 15.2); the pipeline uses it to guarantee 518 rows.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

from .models import CaseResult, Step

__all__ = [
    "STEP_FIELDS",
    "OUTPUT_HEADER",
    "steps_to_json",
    "json_to_steps",
    "build_rows",
    "write_output",
]

# The exact, ordered set of fields each serialized step object carries.
STEP_FIELDS = (
    "step_no",
    "phase",
    "system_id",
    "resource_id",
    "operation",
    "state",
    "evidence_id",
)

# The exact header line required by the output contract (Requirement 11.1).
OUTPUT_HEADER = ("case_id", "deletion_status", "steps_json")


def _step_to_dict(step: Step) -> dict:
    """Project a :class:`Step` onto exactly the seven contract fields.

    ``step_no`` is kept as an ``int`` so it serializes as a JSON number; all
    other fields are strings taken directly from the dataclass.
    """
    return {
        "step_no": step.step_no,
        "phase": step.phase,
        "system_id": step.system_id,
        "resource_id": step.resource_id,
        "operation": step.operation,
        "state": step.state,
        "evidence_id": step.evidence_id,
    }


def steps_to_json(steps: list[Step]) -> str:
    """Serialize a step list to canonical, compact ``steps_json``.

    Uses ``json.dumps(obj, sort_keys=True, separators=(",", ":"))`` so output is
    deterministic and byte-identical for equal inputs (Requirement 16.3).
    """
    obj = [_step_to_dict(step) for step in steps]
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def json_to_steps(s: str) -> list[Step]:
    """Parse a ``steps_json`` string back into ``list[Step]``.

    Array order is preserved (Requirements 11.5, 11.6). Each object must carry
    the seven contract fields; ``step_no`` is coerced to ``int``.
    """
    obj = json.loads(s)
    steps: list[Step] = []
    for item in obj:
        steps.append(
            Step(
                step_no=int(item["step_no"]),
                phase=item["phase"],
                system_id=item["system_id"],
                resource_id=item["resource_id"],
                operation=item["operation"],
                state=item["state"],
                evidence_id=item["evidence_id"],
            )
        )
    return steps


def build_rows(
    results: dict[str, CaseResult], all_case_ids: list[str]
) -> list[CaseResult]:
    """Return one :class:`CaseResult` per ``case_id``, filling gaps with a default.

    Iterates the full ``all_case_ids`` list so every case emits a row; any
    ``case_id`` missing from ``results`` (e.g. a case whose pipeline raised) is
    defaulted to ``NOT_APPLICABLE`` with an empty step plan (Requirements 11.2,
    15.2). The returned list is sorted by ``case_id`` ascending.
    """
    rows: list[CaseResult] = []
    for case_id in all_case_ids:
        result = results.get(case_id)
        if result is None:
            result = CaseResult(
                case_id=case_id,
                deletion_status="NOT_APPLICABLE",
                steps=(),
            )
        rows.append(result)
    rows.sort(key=lambda r: r.case_id)
    return rows


def write_output(rows: list[CaseResult], root: Path) -> None:
    """Write ``output.csv`` at the repository root from ``rows``.

    The header is exactly ``case_id,deletion_status,steps_json`` and rows are
    sorted by ``case_id`` ascending (Requirements 11.1, 11.3). The ``steps_json``
    column is serialized with :func:`steps_to_json` and quoted automatically by
    the CSV writer (``QUOTE_MINIMAL``). The file is UTF-8 with ``newline=""``.
    """
    path = Path(root) / "output.csv"
    ordered = sorted(rows, key=lambda r: r.case_id)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, quoting=csv.QUOTE_MINIMAL)
        writer.writerow(OUTPUT_HEADER)
        for row in ordered:
            writer.writerow(
                [
                    row.case_id,
                    row.deletion_status,
                    steps_to_json(list(row.steps)),
                ]
            )
