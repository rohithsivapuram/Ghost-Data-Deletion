# Evaluation Report

This report evaluates the deterministic deletion-audit pipeline against the 32 public sample cases in `dataset/sample_deletion_requests.csv`, using the supplied correct answers in `dataset/sample_output.csv` as ground truth. All metrics are produced by `code/evaluation/generate_evaluation_report.py` on the default deterministic engine (zero model calls), so the figures are reproducible.

Step comparisons normalize each step to the seven contract fields (`step_no`, `phase`, `system_id`, `resource_id`, `operation`, `state`, `evidence_id`); JSON object-key order and whitespace are ignored while array order is significant (Requirement 13.3).

## Accuracy Against `sample_output.csv`

| Metric | Value | Count |
|---|---|---|
| Case-level deletion-status accuracy | 53.12% | 17/32 |
| Step-level accuracy (exact step-array match) | 0.00% | 0/32 |
| Field-level accuracy (per-field across aligned steps) | 41.27% | 572/1386 |
| Sequence accuracy (array-order match) | 0.00% | 0/32 |

Metric definitions:

- **Case-level deletion-status accuracy**: the fraction of sample cases whose predicted `deletion_status` matches the expected status.
- **Step-level accuracy**: the fraction of cases whose entire normalized step array matches the expected array exactly (array order significant).
- **Field-level accuracy**: across index-aligned steps, the fraction of the seven individual step fields that match; surplus steps on either side count their fields as mismatches.
- **Sequence accuracy**: the fraction of cases whose step ordering (phase, operation, system_id, resource_id at every index) matches the expected array order.

## Additional Participant-Created Evaluation Cases

The following 3 cases were authored by the participant to exercise the NOT_APPLICABLE, COMPLETE, and INCOMPLETE branches and the disable-flow / block-restore ordering rule. They are fully fictional and are not drawn from any organizer-only truth (AGENTS.md §7).

### custom_eval_01

**Scenario:** Non-deletion request (data export) must be NOT_APPLICABLE.

**`request_text`:** Hello, I would like to download a copy of all the data you hold about me for my own records. This is an export request, not a deletion.

**Expected `deletion_status`:** `NOT_APPLICABLE`

**Expected `steps_json`:**

```json
[]
```

**Why:** The request authorizes an export, not deletion, so intent classification short-circuits to NOT_APPLICABLE with an empty steps array regardless of other case fields (Requirements 1.2, 8.3, 9.1).

### custom_eval_02

**Scenario:** Fully compliant deletion with a policy-retained audit record must be COMPLETE with verification-only steps.

**`request_text`:** Please erase my account and all personal data. Thank you.

**Expected `deletion_status`:** `COMPLETE`

**Expected `steps_json`:**

```json
[
  {
    "evidence_id": "evidence_sample_a",
    "operation": "VERIFY_RECORD_ABSENT",
    "phase": "VERIFICATION",
    "resource_id": "account_7001",
    "state": "ABSENT",
    "step_no": 1,
    "system_id": "account_service"
  },
  {
    "evidence_id": "evidence_sample_a",
    "operation": "VERIFY_RECORD_PRESENT",
    "phase": "VERIFICATION",
    "resource_id": "audit_record_7001",
    "state": "PRESENT",
    "step_no": 2,
    "system_id": "security_service"
  }
]
```

**Why:** Every relevant copy carries its required treatment (account record absent) while a RETAIN security-audit record remains present, and there is no active data flow or unblocked restore, so the case is COMPLETE with only evidence-backed VERIFICATION steps (Requirements 8.1, 9.2, 6.2).

### custom_eval_03

**Scenario:** Incomplete deletion with an active sync flow and a remaining record must order DISABLE_DATA_FLOW before DELETE_RECORD.

**`request_text`:** Delete my profile and stop using my information.

**Expected `deletion_status`:** `INCOMPLETE`

**Expected `steps_json`:**

```json
[
  {
    "evidence_id": "evidence_sample_b",
    "operation": "REPORT_REMAINING_RECORD",
    "phase": "FINDING",
    "resource_id": "account_8002",
    "state": "PRESENT",
    "step_no": 1,
    "system_id": "account_service"
  },
  {
    "evidence_id": "evidence_sample_c",
    "operation": "REPORT_ACTIVE_DATA_FLOW",
    "phase": "FINDING",
    "resource_id": "connector_42",
    "state": "ACTIVE",
    "step_no": 2,
    "system_id": "integration_service"
  },
  {
    "evidence_id": "",
    "operation": "DISABLE_DATA_FLOW",
    "phase": "REMEDIATION",
    "resource_id": "connector_42",
    "state": "DISABLED",
    "step_no": 3,
    "system_id": "integration_service"
  },
  {
    "evidence_id": "",
    "operation": "DELETE_RECORD",
    "phase": "REMEDIATION",
    "resource_id": "account_8002",
    "state": "ABSENT",
    "step_no": 4,
    "system_id": "account_service"
  },
  {
    "evidence_id": "",
    "operation": "VERIFY_RECORD_ABSENT",
    "phase": "VERIFICATION",
    "resource_id": "account_8002",
    "state": "ABSENT",
    "step_no": 5,
    "system_id": "account_service"
  },
  {
    "evidence_id": "",
    "operation": "VERIFY_DATA_FLOW_DISABLED",
    "phase": "VERIFICATION",
    "resource_id": "connector_42",
    "state": "DISABLED",
    "step_no": 6,
    "system_id": "integration_service"
  }
]
```

**Why:** A remaining account record and an active connector are both grounded in evidence, so the case is INCOMPLETE. FINDING steps cite participant-visible evidence; within REMEDIATION the DISABLE_DATA_FLOW operation precedes the dependent DELETE_RECORD (operation-table order), and remediation plus post-remediation verification use an empty evidence_id (Requirements 8.2, 9.3, 9.4, 10.4).

## Failures Found During Development and Improvements Made

The following issues surfaced while building and running the pipeline against the sample set; each is paired with the improvement made in response.

- **Step ordering mismatches.** Early output ordered steps by evidence-processing order, so step arrays diverged from the sample array order even when the status was correct. Introducing a canonical sort key `(Phase, OPERATION_ORDER, system_id, resource_id)` in `ordering.py` and renumbering from 1 afterwards made step and sequence accuracy independent of input order (Requirements 10.1-10.5, 16.2).
- **Empty-`evidence_id` rule violations.** Initial INCOMPLETE plans cited evidence on remediation and post-remediation verification steps. The step generator and validator were tightened so FINDING steps carry a participant-visible reference while REMEDIATION and VERIFICATION steps for INCOMPLETE cases use `evidence_id=""` (Requirements 9.4, 12.7).
- **`audit_at` time-gating leaks.** Some cases initially consulted evidence captured after `audit_at`, changing answers that must reflect the cutoff state. A two-level gate (file-level manifest `captured_at` and observation-level `observed_at`, keeping the closest observation not after `audit_at`) removed the leak (Requirements 3.3, 3.4, 5.3, 5.5).
- **Tombstone handling.** A tombstone with all direct identifiers null was initially flagged as exposed PII. The policy engine now treats a null-identifier `ACCOUNT_TOMBSTONE` as compliant while a populated one is exposed PII, preserving the stable `user_id` (Requirements 6.5, 6.6).
- **Disable/block precedence.** Remediation plans sometimes deleted a record before disabling the active flow that could recreate it. The operation table was ordered so `DISABLE_DATA_FLOW` and `BLOCK_RESTORE` precede dependent record operations within the REMEDIATION phase (Requirement 10.4).

This report contains no API keys, credentials, sensitive configuration, or real personal data (Requirement 15.4).
