"""Property-based tests for the step generator (``code/ghost_audit/steps.py``).

These tests use Hypothesis to validate universal ordering/numbering properties
of :func:`ghost_audit.steps.generate_steps` across many generated inputs.

Properties covered:

- 12.3 steps are ordered FINDING < REMEDIATION < VERIFICATION
  (**Validates: Requirements 10.1**).
- 12.4 step_no values are 1..N with no gaps or repeats
  (**Validates: Requirements 10.3, 10.5**).
- 12.5 step order and numbering are independent of input record order
  (**Validates: Requirements 16.2**).
- 12.6 within REMEDIATION, DISABLE_DATA_FLOW and BLOCK_RESTORE precede the
  dependent record ops (**Validates: Requirements 10.4**).

Generator strategy
------------------

Each :class:`PolicyDecision` is built from one of a few canned
``(finding_op, remediation_op, verification_op)`` triples drawn from the design
policy table, so the finding/remediation/verification ops are always mutually
consistent with a real data category. A random ``compliant`` flag and random
``system_id``/``resource_id`` strings exercise the ordering and numbering logic
across the whole input space.
"""

from __future__ import annotations

from hypothesis import given
from hypothesis import strategies as st

from ghost_audit.models import PolicyDecision, RecordState
from ghost_audit.ordering import Phase
from ghost_audit.steps import generate_steps

# Canned (finding_op, remediation_op, verification_op) triples from the design
# policy table. Each triple is internally consistent for a data category.
_TRIPLES: list[tuple[str | None, str | None, str]] = [
    # DELETE categories (USER_PROFILE, SEARCH_INDEX_ENTRY, CACHE_ENTRY, ...)
    ("REPORT_REMAINING_RECORD", "DELETE_RECORD", "VERIFY_RECORD_ABSENT"),
    # REDACT categories (SUPPORT_MESSAGE, EMAIL_DELIVERY_LOG, ACCOUNT_TOMBSTONE)
    ("REPORT_EXPOSED_PII", "REDACT_RECORD", "VERIFY_RECORD_REDACTED"),
    # ANONYMIZE categories (ANALYTICS_PROFILE, PRODUCT_TELEMETRY)
    ("REPORT_EXPOSED_PII", "ANONYMIZE_RECORD", "VERIFY_RECORD_ANONYMIZED"),
    # RETAIN categories (SECURITY_AUDIT_LOG, LEGAL_HOLD_RECORD)
    (None, None, "VERIFY_RECORD_PRESENT"),
    # BACKUP_ARCHIVE (RETAIN + block restore)
    ("REPORT_RESTORE_RISK", "BLOCK_RESTORE", "VERIFY_RESTORE_BLOCKED"),
    # DATA_FLOW (active)
    ("REPORT_ACTIVE_DATA_FLOW", "DISABLE_DATA_FLOW", "VERIFY_DATA_FLOW_DISABLED"),
]

_STATUSES = ["COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"]


@st.composite
def _policy_decisions(draw) -> PolicyDecision:
    """Generate a single consistent :class:`PolicyDecision`."""
    finding_op, remediation_op, verification_op = draw(st.sampled_from(_TRIPLES))
    compliant = draw(st.booleans())
    system_id = draw(st.sampled_from(["account_service", "search_service", "backup_service", "integration_service"]))
    resource_id = draw(st.sampled_from(["res_1", "res_2", "res_3", "account_005", "idx_9"]))
    evidence_id = f"evidence_{draw(st.integers(min_value=0, max_value=99))}"
    state = RecordState(
        system_id=system_id,
        resource_id=resource_id,
        data_category="X",
        present=draw(st.booleans()),
        exposed_identifiers=frozenset(),
        treatment="NONE",
        is_active_flow=False,
        is_restore_risk=False,
        proving_evidence_id=evidence_id,
    )
    # A compliant decision carries no finding/remediation op (policy contract).
    if compliant:
        finding_op = None
        remediation_op = None
    return PolicyDecision(
        state=state,
        required_action="X",
        compliant=compliant,
        finding_op=finding_op,
        remediation_op=remediation_op,
        verification_op=verification_op,
    )


_decision_lists = st.lists(_policy_decisions(), min_size=0, max_size=8)


class TestPhaseOrdering:
    """Task 12.3 property test."""

    @given(status=st.sampled_from(_STATUSES), decisions=_decision_lists)
    def test_phases_ordered_finding_remediation_verification(self, status, decisions):
        """Property: steps are ordered FINDING < REMEDIATION < VERIFICATION.

        Validates: Requirements 10.1

        The phase rank of each step is non-decreasing across the output list, so
        every FINDING precedes every REMEDIATION, which precedes every
        VERIFICATION.
        """
        steps = generate_steps(status, decisions)
        ranks = [Phase[s.phase] for s in steps]
        assert ranks == sorted(ranks)


class TestConsecutiveNumbering:
    """Task 12.4 property test."""

    @given(status=st.sampled_from(_STATUSES), decisions=_decision_lists)
    def test_step_no_is_one_to_n_no_gaps_or_repeats(self, status, decisions):
        """Property: step_no values are 1..N with no gaps or repeats.

        Validates: Requirements 10.3, 10.5
        """
        steps = generate_steps(status, decisions)
        numbers = [s.step_no for s in steps]
        assert numbers == list(range(1, len(steps) + 1))


class TestOrderingIndependence:
    """Task 12.5 property test."""

    @given(status=st.sampled_from(_STATUSES), decisions=_decision_lists, seed=st.integers())
    def test_order_and_numbering_independent_of_input_order(self, status, decisions, seed):
        """Property: output is independent of input record order.

        Validates: Requirements 16.2

        Generating steps from the decisions, then from a shuffled copy of the
        same decisions, yields identical step lists (same operations, order, and
        numbering).
        """
        import random

        original = generate_steps(status, list(decisions))
        shuffled = list(decisions)
        random.Random(seed).shuffle(shuffled)
        reshuffled = generate_steps(status, shuffled)
        assert original == reshuffled


class TestDisableBlockPrecedence:
    """Task 12.6 property test."""

    @given(decisions=_decision_lists)
    def test_disable_block_precede_dependent_record_ops(self, decisions):
        """Property: within REMEDIATION, DISABLE_DATA_FLOW/BLOCK_RESTORE precede
        dependent record ops.

        Validates: Requirements 10.4

        For an INCOMPLETE case, the index of any DISABLE_DATA_FLOW or
        BLOCK_RESTORE remediation step is less than the index of any
        DELETE_RECORD / REDACT_RECORD / ANONYMIZE_RECORD remediation step.
        """
        steps = generate_steps("INCOMPLETE", decisions)
        remediation = [s for s in steps if s.phase == "REMEDIATION"]
        flow_block_idx = [
            i for i, s in enumerate(remediation)
            if s.operation in ("DISABLE_DATA_FLOW", "BLOCK_RESTORE")
        ]
        record_idx = [
            i for i, s in enumerate(remediation)
            if s.operation in ("DELETE_RECORD", "REDACT_RECORD", "ANONYMIZE_RECORD")
        ]
        if flow_block_idx and record_idx:
            assert max(flow_block_idx) < min(record_idx)
