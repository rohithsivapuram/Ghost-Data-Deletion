"""Property-based tests for the policy engine.

These tests use Hypothesis to validate universal properties of
``code/ghost_audit/policy.py`` across many generated inputs.

Properties covered:

- 9.2 A RETAIN record is never assigned a delete/redact/anonymize remediation
  op (**Validates: Requirement 6.2**).

The generator builds :class:`RecordState` instances for the RETAIN categories
(``SECURITY_AUDIT_LOG``, ``LEGAL_HOLD_RECORD``) and ``BACKUP_ARCHIVE`` with
randomized presence, treatment, exposure, and flow/restore flags so the
retain-never-removed invariant is exercised across the whole input space.
"""

from __future__ import annotations

from hypothesis import given
from hypothesis import strategies as st

from ghost_audit.models import PolicyRule, RecordState
from ghost_audit.policy import apply_policy

# Remediation ops that a RETAIN record must NEVER be assigned (Requirement 6.2).
_REMOVAL_OPS = {"DELETE_RECORD", "REDACT_RECORD", "ANONYMIZE_RECORD"}

# RETAIN-governed categories: the two pure-RETAIN rules plus BACKUP_ARCHIVE,
# which is RETAIN-with-block-restore (remediation may be BLOCK_RESTORE or None).
_RETAIN_CATEGORIES = ["SECURITY_AUDIT_LOG", "LEGAL_HOLD_RECORD", "BACKUP_ARCHIVE"]

_RULES: dict[str, PolicyRule] = {
    "SECURITY_AUDIT_LOG": PolicyRule(
        rule_id="rule_12",
        data_category="SECURITY_AUDIT_LOG",
        condition="Record is within the supplied retention period",
        required_action="RETAIN",
    ),
    "LEGAL_HOLD_RECORD": PolicyRule(
        rule_id="rule_13",
        data_category="LEGAL_HOLD_RECORD",
        condition="A supplied legal hold is active",
        required_action="RETAIN",
    ),
    "BACKUP_ARCHIVE": PolicyRule(
        rule_id="rule_14",
        data_category="BACKUP_ARCHIVE",
        condition="Restore access can be blocked",
        required_action="RETAIN",
    ),
}

_treatments = st.sampled_from(["NONE", "REDACTED", "ANONYMIZED", "DELETED"])
_identifier_sets = st.sets(
    st.sampled_from(["a@x.com", "b@y.com", "+15551234567", "Ada Lovelace"]),
    max_size=3,
).map(frozenset)


@st.composite
def _retain_states(draw) -> RecordState:
    """Generate a RecordState for a RETAIN-governed category with random flags."""
    category = draw(st.sampled_from(_RETAIN_CATEGORIES))
    return RecordState(
        system_id=draw(st.sampled_from(["security_service", "legal_service", "backup_service"])),
        resource_id=draw(st.sampled_from(["res_1", "res_2", "res_3"])),
        data_category=category,
        present=draw(st.booleans()),
        exposed_identifiers=draw(_identifier_sets),
        treatment=draw(_treatments),
        is_active_flow=draw(st.booleans()),
        is_restore_risk=draw(st.booleans()),
        proving_evidence_id=f"evidence_{draw(st.integers(min_value=0, max_value=9999))}",
    )


class TestRetainNeverRemoved:
    """Task 9.2 property test for :func:`apply_policy`."""

    @given(state=_retain_states())
    def test_retain_never_assigned_removal_op(self, state):
        """Property: a RETAIN record is never assigned a removal remediation op.

        Validates: Requirement 6.2

        For any RETAIN-governed record (SECURITY_AUDIT_LOG, LEGAL_HOLD_RECORD,
        BACKUP_ARCHIVE), the policy decision's ``remediation_op`` must never be
        DELETE_RECORD, REDACT_RECORD, or ANONYMIZE_RECORD. BACKUP_ARCHIVE may
        legitimately yield BLOCK_RESTORE or None, which are allowed.
        """
        decision = apply_policy(state, _RULES)
        assert decision.remediation_op not in _REMOVAL_OPS
