# Ghost Data Deletion-Audit Agent

An AI-powered deletion-audit agent for the HackerRank Orchestrate "Ghost Data
Still Exists" challenge. For every request in `dataset/deletion_requests.csv`
(518 cases) the agent decides whether the request authorizes deletion, resolves
the subject's current and historical identifiers, reconstructs the true
per-record state at each case's `audit_at` cutoff from multimodal evidence,
applies `deletion_rules.csv`, and emits an ordered `steps_json` plan. It writes
`output.csv` at the repository root with exactly 518 rows sorted by `case_id`.

## Architecture: deterministic-first, LLM-optional

The supplied evidence is highly structured and carries explicit state signals,
so the **default engine is a deterministic, rules-based Python pipeline that
makes zero model calls**. It is reproducible, costs nothing, and reports zero
model calls in the usage report. An optional, pluggable LLM layer handles only
ambiguous deletion-intent classification and PDF/image artifacts that
deterministic extraction cannot read; its output is normalized back into the
same structures so downstream ordering stays deterministic.

## Requirements

- Python 3.10 or newer (the runtime uses only the standard library).
- Test/dev dependencies: `pytest` and `hypothesis` (see `code/requirements.txt`).

## Setup

All commands are run **from the repository root** (the directory containing
`AGENTS.md` and `dataset/`). Dataset and output paths are resolved relative to
the repository root, so the agent runs identically on macOS, Linux, and Windows.

```bash
# (optional) create and activate a virtual environment
python -m venv .venv
# macOS / Linux:
source .venv/bin/activate
# Windows (PowerShell):
.venv\Scripts\Activate.ps1

# install test/dev dependencies (the pipeline itself needs none)
python -m pip install -r code/requirements.txt
```

> On Windows, `py` may be used in place of `python` (e.g. `py code/main.py`).

## Running the full audit

Process every case in `dataset/deletion_requests.csv`, write `output.csv` at the
repository root, validate the output against the contract, and write the usage
report:

```bash
python code/main.py
```

Optional flags:

```bash
python code/main.py --root .        # set the repository root explicitly
python code/main.py --sample        # run over sample_deletion_requests.csv instead
```

The command prints the number of cases processed, the output path, the status
distribution, the usage-report path, and a validation summary. It exits `0` when
the output is contract-valid and `1` if the validator finds any violation.

## Configuration (environment variables only)

All configuration and secrets are read **only** from environment variables; no
secret is ever printed or written to `output.csv`, `log.txt`, or the reports.

| Variable       | Default         | Purpose                                                        |
|----------------|-----------------|----------------------------------------------------------------|
| `ENGINE`       | `deterministic` | `deterministic` (no model calls) or `llm_assisted` (optional). |
| `LLM_PROVIDER` | _(unset)_       | Provider name for the optional LLM-assisted engine.            |
| `LLM_MODEL`    | _(unset)_       | Model identifier for the optional LLM-assisted engine.         |
| `KIRO_TOOL`    | `ghost-audit`   | Value written to the `tool=` line in `log.txt`.                |

### Engine selection

The deterministic engine is the default and the only one required. It is used
whenever `ENGINE` is unset or set to `deterministic`:

```bash
# deterministic (default): zero model calls, fully reproducible
python code/main.py

# optional LLM-assisted path (falls back to deterministic if unavailable)
ENGINE=llm_assisted LLM_PROVIDER=<provider> LLM_MODEL=<model> python code/main.py
```

If the optional engine cannot be configured or imported, the pipeline falls
back to the deterministic engine so a run never breaks on configuration.

## Sample-set conformance

Run the pipeline over the 32 public sample cases and compare against
`dataset/sample_output.csv` (status, step, field, and sequence differences):

```bash
python -m ghost_audit.sample_harness --root .
```

> Run this from the `code/` directory, or ensure `code/` is on `PYTHONPATH`, so
> that `ghost_audit` is importable.

## Determinism check

Run the full pipeline twice and confirm the two `output.csv` artifacts are
byte-identical in row order, statuses, and step arrays:

```bash
python -m ghost_audit.determinism --root .
```

## Evaluation and usage reports

Regenerate the evaluation report (accuracy metrics plus participant-authored
cases) and the usage report for the final run:

```bash
python code/evaluation/generate_evaluation_report.py --root .
python code/evaluation/generate_usage_report.py --root .
```

These write `code/evaluation/evaluation_report.md` and
`code/evaluation/usage_report.md`. On the deterministic engine the usage report
states zero model calls and `$0.00` cost.

## Tests

```bash
python -m pytest code/tests
```

Property-based tests (Hypothesis) cover the universal correctness properties;
unit tests cover specific examples and edge cases.

## Project layout

```text
code/
├── main.py                      # terminal entry point (full run)
├── requirements.txt             # test/dev dependencies
├── ghost_audit/                 # pipeline package
│   ├── loaders.py               # read CSVs + evidence manifest
│   ├── intent.py                # deletion-intent classification + Engine
│   ├── identity.py              # current/historical identity resolution
│   ├── evidence.py              # audit_at gating + subject matching
│   ├── parsers/                 # text, log, JSON, SQL (+ optional PDF/image)
│   ├── state.py                 # per-record state reconstruction at audit_at
│   ├── policy.py                # deletion_rules.csv application
│   ├── decision.py              # COMPLETE / INCOMPLETE / NOT_APPLICABLE
│   ├── ordering.py / steps.py   # canonical step ordering + generation
│   ├── serialize.py             # output.csv + canonical steps_json
│   ├── validate.py              # output contract + sample comparison
│   ├── sample_harness.py        # sample-set conformance runner
│   ├── determinism.py           # two-run determinism check
│   ├── logging_util.py          # append-only session/turn logging to log.txt
│   └── usage.py                 # usage/cost reporting
├── evaluation/                  # evaluation + usage report generators
└── tests/                       # unit and property-based tests
```

## Output contract

`output.csv` is written at the repository root with the exact header
`case_id,deletion_status,steps_json`, exactly 518 data rows sorted by `case_id`,
and each `steps_json` a JSON array whose step objects contain exactly `step_no`,
`phase`, `system_id`, `resource_id`, `operation`, `state`, and `evidence_id`.
`steps_json` is serialized canonically (`sort_keys=True`, compact separators) so
repeated runs are byte-identical.
