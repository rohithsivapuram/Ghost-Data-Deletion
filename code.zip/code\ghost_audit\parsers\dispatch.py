"""Parser dispatch for evidence files.

The dispatcher selects a format-specific parser for an :class:`EvidenceFile`
based on its file extension and filename, reads the file, and returns the
extracted :class:`ParsedRecord`s. Any failure (unreadable file, unknown
format, parser error) is captured as a parse failure keyed by ``file_id`` and
processing continues on the remaining evidence (Requirement 4.5).

Dispatch mapping (Requirement 4.1):

- ``.txt`` handover files (filename contains ``handover``) -> handover parser
- ``.log`` lookup/trace files -> logs parser
- ``.json`` files (snapshot bundles, service resource exports, and other JSON
  records) -> JSON records parser
- ``.sql`` -> SQL snapshot parser
- ``.pdf`` -> PDF parser (optional; task 7.7)
- ``.png`` / image -> image parser (optional; task 7.7)

Optional parser modules (``pdf``/``image``) may not exist yet; their imports
are wrapped so a missing module is treated as a parse failure rather than an
error. The dispatcher is deterministic and side-effect-free apart from reading
the evidence file off disk.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from ..models import EvidenceFile, ParsedRecord

__all__ = ["ParseOutcome", "dispatch_parse", "parse_all"]

# Image extensions routed to the (optional) image parser.
_IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff"}


@dataclass(frozen=True)
class ParseOutcome:
    """The result of dispatching a single evidence file through a parser.

    ``records`` holds the extracted facts; ``failed`` is ``True`` when parsing
    could not complete, in which case ``error`` carries a short reason. The
    ``file_id`` ties the outcome back to the manifest entry.
    """

    file_id: str
    records: tuple[ParsedRecord, ...] = ()
    failed: bool = False
    error: str | None = None


def _read_text(path: Path) -> str:
    """Read a text evidence file as UTF-8, tolerating a BOM."""
    return path.read_text(encoding="utf-8-sig")


def _parse_by_format(evidence_file: EvidenceFile) -> list[ParsedRecord]:
    """Route ``evidence_file`` to the parser for its format and return records.

    Raises on any read/parse error or unknown format; the caller converts that
    into a recorded parse failure.
    """
    path = Path(evidence_file.file_path)
    suffix = path.suffix.lower()
    name = path.name.lower()
    file_id = evidence_file.file_id

    if suffix == ".txt":
        # Handover text records (filename contains "handover"); any other
        # ``.txt`` is still routed to the handover parser as the text handler.
        from .handover import parse_handover_txt

        return parse_handover_txt(_read_text(path), file_id)

    if suffix == ".log":
        from .logs import parse_lookup_log

        return parse_lookup_log(_read_text(path), file_id)

    if suffix == ".json":
        # Snapshot bundles, service resource exports, and other JSON records
        # all flow through the JSON records parser, which branches on shape.
        from .json_records import parse_json_records

        obj = json.loads(_read_text(path))
        return parse_json_records(obj, file_id)

    if suffix == ".sql":
        from .sql import parse_sql_snapshot

        return parse_sql_snapshot(path, file_id)

    if suffix == ".pdf":
        # Optional parser (task 7.7); tolerate a missing module.
        from .pdf import parse_pdf  # type: ignore[import-not-found]

        return parse_pdf(path, file_id)

    if suffix in _IMAGE_SUFFIXES:
        # Optional parser (task 7.7); tolerate a missing module.
        from .image import parse_image  # type: ignore[import-not-found]

        return parse_image(path, file_id)

    raise ValueError(f"unsupported evidence format: {suffix or '<none>'} ({name})")


def dispatch_parse(evidence_file: EvidenceFile) -> tuple[list[ParsedRecord], str | None]:
    """Parse one evidence file, selecting the parser by extension/filename.

    Returns ``(records, None)`` on success and ``([], error)`` on failure. This
    function never raises; parse failures are reported via the error string so
    callers can record them by ``file_id`` and continue (Requirement 4.5).
    """
    try:
        records = _parse_by_format(evidence_file)
        return list(records), None
    except Exception as exc:  # pragma: no cover - exact message varies by cause
        return [], f"{type(exc).__name__}: {exc}"


def parse_all(
    files: list[EvidenceFile],
) -> tuple[list[ParsedRecord], dict[str, str]]:
    """Dispatch every file, aggregating records and collecting failures.

    Runs each :class:`EvidenceFile` through :func:`dispatch_parse`, concatenates
    all extracted records in manifest order (deterministic), and builds a
    ``{file_id: error}`` map for files that failed to parse. Never raises
    (Requirement 4.5).
    """
    all_records: list[ParsedRecord] = []
    failures: dict[str, str] = {}
    for evidence_file in files:
        records, error = dispatch_parse(evidence_file)
        if error is not None:
            failures[evidence_file.file_id] = error
            continue
        all_records.extend(records)
    return all_records, failures
