"""Pluggable intent-classification engines.

The default engine for the whole pipeline is the deterministic lexicon
classifier in :mod:`ghost_audit.intent` (``DeterministicEngine``). This package
holds the *optional* engines that implement the same ``Engine`` protocol
(``classify(self, request_text) -> IntentResult``) but may escalate genuinely
ambiguous inputs to a model.

Only :mod:`ghost_audit.engines.llm` lives here for now. It is imported lazily by
``ghost_audit.pipeline.select_engine`` so that the deterministic default never
depends on any optional SDK being installed (Requirements 15.3, 15.4).
"""
