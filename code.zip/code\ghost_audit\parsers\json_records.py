"""JSON evidence parser (task 7.4).

Decoded JSON evidence comes in several grounded shapes; this parser inspects
the object's keys and dispatches accordingly:

(A) **Snapshot bundle** (``customer_data_snapshot_bundle_*.json``): a top-level
    ``snapshots`` list. Each snapshot has ``captured_at``, ``data_store``
    (the ``system_id``), ``collection``, and ``records``. Records are mapped to
    a policy ``data_category`` by collection and turned into present records
    with a state signal derived from the collection semantics (tombstone null
    vs populated, connector enabled, backup restore_allowed, analytics
    identifier presence). ``operational_record_history`` collections carry
    ``{system, resource_id, record_type, result, lookup_value}`` claim rows and
    are handled by the generic history branch.

(B) **Service resource export** (``service_resource_export_*.json``): a
    ``service_exports`` dict keyed by system. Each system holds lists of
    per-resource observations (``profile_lookups``, ``profiles``,
    ``restore_entries``, ``connectors``, ``index_queries``, ``tickets``,
    ``audit_records``, ``exports``). Each item carries ``observed_at`` and
    ``resource_id`` plus status/flag fields used to derive state.

(C) **Single-collection snapshot / operational history** (e.g.
    ``customer_analytics_report_*.json``, ``customer_export_jobs_*.json``,
    ``connector_configurations_*.json``, ``*_manifest_*.json``,
    ``security_audit_ledger_*.json``): a top-level ``collection``+``records`` or
    ``origin``+``records`` object. Collection-record objects reuse the snapshot
    record logic; operational-history records reuse the history branch.

Any unrecognized shape yields ``[]`` (best effort; the dispatcher does not mark
an empty result as a failure).
"""

from __future__ import annotations

from typing import Any

from ..loaders import parse_timestamp
from ..models import ParsedRecord
from ._common import (
    IdentifierCollector,
    is_nullish,
    map_collection_category,
)

__all__ = ["parse_json_records"]

# System -> data_category fallback when a collection name is not decisive
# (used by the service-export branch where only the system key is known).
_SYSTEM_CATEGORY: dict[str, str] = {
    "account_service": "USER_PROFILE",
    "search_service": "SEARCH_INDEX_ENTRY",
    "analytics_platform": "ANALYTICS_PROFILE",
    "support_platform": "SUPPORT_MESSAGE",
    "export_service": "USER_EXPORT",
    "integration_service": "DATA_FLOW",
    "backup_service": "BACKUP_ARCHIVE",
    "security_service": "SECURITY_AUDIT_LOG",
}

# record_type (operational history) -> data_category.
_RECORD_TYPE_CATEGORY: dict[str, str] = {
    "USER_PROFILE": "USER_PROFILE",
    "SEARCH_INDEX_ENTRY": "SEARCH_INDEX_ENTRY",
    "ANALYTICS_PROFILE": "ANALYTICS_PROFILE",
    "SUPPORT_MESSAGE": "SUPPORT_MESSAGE",
    "SUPPORT_ATTACHMENT": "SUPPORT_ATTACHMENT",
    "USER_EXPORT": "USER_EXPORT",
    "DATA_FLOW": "DATA_FLOW",
    "BACKUP_ARCHIVE": "BACKUP_ARCHIVE",
    "SECURITY_AUDIT_LOG": "SECURITY_AUDIT_LOG",
    "ACCOUNT_TOMBSTONE": "ACCOUNT_TOMBSTONE",
    "LEGAL_HOLD_RECORD": "LEGAL_HOLD_RECORD",
}


def _truthy(value: Any) -> bool:
    """Interpret a JSON boolean / 0-1 / "true"-"false" value as a bool."""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        return value.strip().lower() in {"true", "1", "yes"}
    return False


def _collect_record_identifiers(record: dict[str, Any]) -> IdentifierCollector:
    """Collect identifiers from the many identifier-bearing fields of a record.

    Handles both flat records and the search-document shape where identifiers
    live under a nested ``document`` object.
    """
    collector = IdentifierCollector()

    def harvest(obj: dict[str, Any]) -> None:
        for key in ("email", "requester_email", "customer_email", "owner_email"):
            collector.add_email(obj.get(key))
        for key in (
            "full_name",
            "display_name",
            "name",
            "requester_name",
        ):
            collector.add_name(obj.get(key))
        for key in ("phone", "requester_phone", "owner_phone"):
            collector.add_phone(obj.get(key))
        collector.add_hash(obj.get("email_hash"))
        for key in (
            "customer_reference",
            "subject_reference",
            "user_id",
            "subject_selector",
            "uploaded_by",
            "lookup_value",
        ):
            # These may be opaque references or emails (subject_selector /
            # uploaded_by are often emails); add_reference auto-detects emails.
            collector.add_reference(obj.get(key))

    harvest(record)
    document = record.get("document")
    if isinstance(document, dict):
        harvest(document)
    return collector


def _snapshot_record_state(
    collection: str | None, record: dict[str, Any]
) -> tuple[str, str | None]:
    """Derive ``(state_signal, data_category)`` for a snapshot collection record."""
    category = map_collection_category(collection)

    if collection == "deleted_customer_references":
        # Tombstone: compliant only when all direct identifiers are null.
        exposed = any(
            not is_nullish(record.get(field))
            for field in ("name", "email", "phone", "email_hash")
        )
        return ("IDENTIFIABLE" if exposed else "ANONYMIZED"), category

    if collection in ("connector_configurations", "connector_subscriptions"):
        return ("ACTIVE" if _truthy(record.get("enabled")) else "DISABLED"), category

    if collection in ("backup_catalog", "backup_restore_entries"):
        return (
            "ACTIVE" if _truthy(record.get("restore_allowed")) else "BLOCKED"
        ), category

    if collection in ("customer_analytics_reports", "customer_analytics_profiles"):
        exposed = any(
            not is_nullish(record.get(field))
            for field in ("email", "phone", "email_hash")
        )
        return ("IDENTIFIABLE" if exposed else "ANONYMIZED"), category

    return "FOUND", category


def _parse_snapshot_record(
    record: dict[str, Any],
    system_id: str,
    collection: str | None,
    observed_at: Any,
    file_id: str,
) -> ParsedRecord | None:
    """Build a :class:`ParsedRecord` for one snapshot-collection record."""
    resource_id = record.get("resource_id")
    if not resource_id:
        return None
    state_signal, category = _snapshot_record_state(collection, record)
    collector = _collect_record_identifiers(record)
    return ParsedRecord(
        file_id=file_id,
        system_id=system_id,
        resource_id=str(resource_id),
        data_category=category,
        observed_at=observed_at,
        present=True,
        identifiers=collector.frozen(),
        state_signal=state_signal,
        raw=dict(record),
    )


def _parse_history_record(
    record: dict[str, Any], file_id: str
) -> ParsedRecord | None:
    """Parse an operational-history claim row.

    Shape: ``{recorded_at, system, resource_id, record_type, result,
    subject_reference|lookup_value}``. ``result`` carries the state signal
    (``FOUND``/``NOT_FOUND``/``IDENTIFIABLE``/``ANONYMIZED``/...).
    """
    resource_id = record.get("resource_id")
    system_id = record.get("system")
    if not resource_id or not system_id:
        return None

    ts = record.get("recorded_at") or record.get("observed_at")
    try:
        observed_at = parse_timestamp(str(ts))
    except (ValueError, TypeError):
        return None

    result = str(record.get("result", "")).strip().upper() or "FOUND"
    present = result != "NOT_FOUND"

    record_type = record.get("record_type")
    category = _RECORD_TYPE_CATEGORY.get(str(record_type)) if record_type else None

    collector = _collect_record_identifiers(record)

    return ParsedRecord(
        file_id=file_id,
        system_id=str(system_id),
        resource_id=str(resource_id),
        data_category=category,
        observed_at=observed_at,
        present=present,
        identifiers=collector.frozen(),
        state_signal=result,
        raw=dict(record),
    )


def _is_history_record(record: dict[str, Any]) -> bool:
    """Return ``True`` for the operational-history claim-row shape."""
    return (
        isinstance(record, dict)
        and "system" in record
        and "record_type" in record
        and "result" in record
    )


def _parse_snapshot_collection(
    system_id: str,
    collection: str | None,
    observed_at: Any,
    records: list[Any],
    file_id: str,
) -> list[ParsedRecord]:
    """Parse the ``records`` list of one snapshot/collection block."""
    out: list[ParsedRecord] = []
    for record in records:
        if not isinstance(record, dict):
            continue
        if _is_history_record(record):
            parsed = _parse_history_record(record, file_id)
        else:
            parsed = _parse_snapshot_record(
                record, system_id, collection, observed_at, file_id
            )
        if parsed is not None:
            out.append(parsed)
    return out


def _parse_snapshot_bundle(obj: dict[str, Any], file_id: str) -> list[ParsedRecord]:
    """Shape (A): iterate ``snapshots[]`` and emit records from each block."""
    out: list[ParsedRecord] = []
    for snapshot in obj.get("snapshots", []):
        if not isinstance(snapshot, dict):
            continue
        records = snapshot.get("records") or []
        if not records:
            continue
        system_id = str(snapshot.get("data_store", "") or "")
        collection = snapshot.get("collection")
        try:
            observed_at = parse_timestamp(str(snapshot.get("captured_at")))
        except (ValueError, TypeError):
            continue
        out.extend(
            _parse_snapshot_collection(
                system_id, collection, observed_at, records, file_id
            )
        )
    return out


def _state_from_export_item(
    system_id: str, item: dict[str, Any]
) -> tuple[bool, str, str | None]:
    """Derive ``(present, state_signal, data_category)`` for a service-export item."""
    category = _SYSTEM_CATEGORY.get(system_id)

    status_code = item.get("status_code")
    if status_code is not None:
        if int(status_code) == 404:
            return False, "NOT_FOUND", category
        if int(status_code) == 200:
            return True, "FOUND", category

    if "enabled" in item:
        return (True, "ACTIVE", category) if _truthy(item.get("enabled")) else (
            True,
            "DISABLED",
            category,
        )

    if "restore_allowed" in item:
        if _truthy(item.get("restore_allowed")):
            return True, "ACTIVE", category
        return True, "BLOCKED", category

    if "hits" in item:
        hits = item.get("hits") or {}
        total = hits.get("total", 0) if isinstance(hits, dict) else 0
        if total:
            return True, "FOUND", category
        return False, "NOT_FOUND", category

    # Profiles / tickets / exports / audit records: present with identifier
    # presence deciding identifiable vs anonymized for analytics.
    if system_id == "analytics_platform":
        exposed = any(
            not is_nullish(item.get(field))
            for field in ("email", "phone", "email_hash")
        )
        return True, ("IDENTIFIABLE" if exposed else "ANONYMIZED"), category
    return True, "FOUND", category


def _parse_export_item(
    system_id: str, item: dict[str, Any], file_id: str
) -> ParsedRecord | None:
    """Parse one item from a service-export system list."""
    resource_id = item.get("resource_id")
    if not resource_id:
        return None
    try:
        observed_at = parse_timestamp(str(item.get("observed_at")))
    except (ValueError, TypeError):
        return None

    present, state_signal, category = _state_from_export_item(system_id, item)

    collector = _collect_record_identifiers(item)
    # Nested profile (account profile_lookups) and search hits carry identifiers.
    profile = item.get("profile")
    if isinstance(profile, dict):
        collector.merge(_collect_record_identifiers(profile))
    hits = item.get("hits")
    if isinstance(hits, dict):
        for doc in hits.get("documents", []) or []:
            if isinstance(doc, dict):
                collector.merge(_collect_record_identifiers(doc))

    return ParsedRecord(
        file_id=file_id,
        system_id=system_id,
        resource_id=str(resource_id),
        data_category=category,
        observed_at=observed_at,
        present=present,
        identifiers=collector.frozen(),
        state_signal=state_signal,
        raw=dict(item),
    )


def _parse_service_export(obj: dict[str, Any], file_id: str) -> list[ParsedRecord]:
    """Shape (B): iterate ``service_exports[system]`` lists of observations."""
    out: list[ParsedRecord] = []
    service_exports = obj.get("service_exports", {})
    if not isinstance(service_exports, dict):
        return out
    for system_id, lists in service_exports.items():
        if not isinstance(lists, dict):
            continue
        for items in lists.values():
            if not isinstance(items, list):
                continue
            for item in items:
                if not isinstance(item, dict):
                    continue
                parsed = _parse_export_item(str(system_id), item, file_id)
                if parsed is not None:
                    out.append(parsed)
    return out


def _parse_single_collection(obj: dict[str, Any], file_id: str) -> list[ParsedRecord]:
    """Shape (C): a top-level ``records`` list (collection or history rows)."""
    records = obj.get("records")
    if not isinstance(records, list) or not records:
        return []

    # Operational-history style records are self-describing (carry ``system``).
    if all(_is_history_record(r) for r in records if isinstance(r, dict)):
        out: list[ParsedRecord] = []
        for record in records:
            if isinstance(record, dict):
                parsed = _parse_history_record(record, file_id)
                if parsed is not None:
                    out.append(parsed)
        return out

    # Otherwise treat as a single-collection snapshot using the top-level
    # ``collection``/``source`` and ``captured_at`` metadata.
    collection = obj.get("collection")
    system_id = str(obj.get("source") or obj.get("origin") or "")
    ts = obj.get("captured_at") or obj.get("exported_at")
    try:
        observed_at = parse_timestamp(str(ts))
    except (ValueError, TypeError):
        return []

    # Prefer a system inferred from the collection's category when possible.
    category = map_collection_category(collection)
    if category:
        # Map category back to a canonical system for consistency with other
        # evidence; fall back to the declared source string otherwise.
        system_id = _category_system(category, system_id)

    return _parse_snapshot_collection(
        system_id, collection, observed_at, records, file_id
    )


def _category_system(category: str, default: str) -> str:
    """Return the canonical system for a data_category, or ``default``."""
    for system, cat in _SYSTEM_CATEGORY.items():
        if cat == category:
            return system
    return default


def parse_json_records(obj: dict, file_id: str) -> list[ParsedRecord]:
    """Parse a decoded JSON object into :class:`ParsedRecord`s.

    Dispatches on the object's shape (snapshot bundle, service export, or a
    single-collection / operational-history record set). Unknown shapes return
    an empty list so the dispatcher does not record a spurious failure.
    """
    if not isinstance(obj, dict):
        return []

    if "snapshots" in obj:
        return _parse_snapshot_bundle(obj, file_id)

    if "service_exports" in obj:
        return _parse_service_export(obj, file_id)

    if "records" in obj:
        return _parse_single_collection(obj, file_id)

    return []
