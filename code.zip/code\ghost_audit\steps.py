"""Step generator (Requirements 9.1-9.8, 10.1-10.5).

:func:`generate_steps` turns a case's ``deletion_status`` and its per-record
:class:`PolicyDecision` list into the ordered ``steps_json`` plan.

Per-status behavior (design.md "Step Generator"):

- ``NOT_APPLICABLE`` => ``[]`` (Requirement 9.1).
- ``COMPLETE`` => VERIFICATION steps only, one per :class:`PolicyDecision` (all
  are compliant). Each verification step cites the ``evidence_id`` that proved
  the compliant state at ``audit_at`` -- ``decision.state.proving_evidence_id``
  (Requirement 9.2).
- ``INCOMPLETE`` => FINDING steps (one per NON-compliant decision, citing the
  participant-visible ``proving_evidence_id``), then the REMEDIATION plan (one
  per non-compliant decision, ``evidence_id=""``), then VERIFICATION steps (one
  per non-compliant/remediated decision, ``evidence_id=""``). Remediation and
  post-remediation verification describe future work, so they carry an empty
  ``evidence_id`` (Requirements 9.3, 9.4).

INCOMPLETE verification scope
-----------------------------

The design focuses verification on the records/processes that were remediated:
"Verification must cover the required final state for each remediated record or
process" (AGENTS.md §6.5). For an ``INCOMPLETE`` case we therefore emit a
VERIFICATION step only for the NON-compliant (remediated) decisions, not for the
already-compliant ones. This keeps the plan deterministic and aligned with the
remediation set.

Allowed operation/state pairs
------------------------------

Only the operation/state pairs enumerated in AGENTS.md §6.4 are ever produced.
:data:`OPERATION_STATE` maps each operation to its single allowed state, and the
builders below always pair an operation with ``OPERATION_STATE[operation]`` so
no illegal pair can be emitted (Requirements 9.5-9.8).

Ordering and numbering
----------------------

All built steps are collected unordered, then sorted by the canonical key
``(Phase[phase], OPERATION_ORDER[operation], system_id, resource_id)`` and
numbered ``1..N`` consecutively (Requirements 10.1, 10.2, 10.3, 10.5). Because
numbering is a pure function of the sorted list, the output is independent of
the order in which ``decisions`` are supplied (Requirement 16.2).
"""

from __future__ import annotations

from .models import PolicyDecision, Step
from .ordering import OPERATION_ORDER, Phase

__all__ = ["generate_steps", "OPERATION_STATE"]

_FINDING = "FINDING"
_REMEDIATION = "REMEDIATION"
_VERIFICATION = "VERIFICATION"

# The single allowed state for each operation (AGENTS.md §6.4 / design table).
# Pairing an operation with OPERATION_STATE[op] guarantees only allowed
# operation/state pairs are produced (Requirements 9.5-9.8).
OPERATION_STATE: dict[str, str] = {
    # FINDING
    "REPORT_REMAINING_RECORD": "PRESENT",
    "REPORT_EXPOSED_PII": "PRESENT",
    "REPORT_ACTIVE_DATA_FLOW": "ACTIVE",
    "REPORT_RESTORE_RISK": "ACTIVE",
    # REMEDIATION
    "DISABLE_DATA_FLOW": "DISABLED",
    "BLOCK_RESTORE": "BLOCKED",
    "DELETE_RECORD": "ABSENT",
    "REDACT_RECORD": "REDACTED",
    "ANONYMIZE_RECORD": "ANONYMIZED",
    # VERIFICATION
    "VERIFY_RECORD_ABSENT": "ABSENT",
    "VERIFY_RECORD_PRESENT": "PRESENT",
    "VERIFY_RECORD_REDACTED": "REDACTED",
    "VERIFY_RECORD_ANONYMIZED": "ANONYMIZED",
    "VERIFY_DATA_FLOW_DISABLED": "DISABLED",
    "VERIFY_RESTORE_BLOCKED": "BLOCKED",
}


def _make_step(phase: str, operation: str, decision: PolicyDecision, evidence_id: str) -> Step:
    """Build a single :class:`Step` with ``step_no`` deferred (set to 0).

    The operation is always paired with its allowed state via
    :data:`OPERATION_STATE`, and ``system_id``/``resource_id`` are taken from the
    decision's :class:`RecordState`. ``step_no`` is assigned later after sorting.
    """
    state = decision.state
    return Step(
        step_no=0,
        phase=phase,
        system_id=state.system_id,
        resource_id=state.resource_id,
        operation=operation,
        state=OPERATION_STATE[operation],
        evidence_id=evidence_id,
    )


def _sort_key(step: Step):
    """Canonical sort key, extended to a TOTAL order for determinism.

    The design's canonical key is ``(Phase, OPERATION_ORDER, system_id,
    resource_id)``. That key is not a total order: two steps can tie on all four
    components yet differ (e.g. two VERIFY_RECORD_ABSENT steps on the same
    system/resource but different proving ``evidence_id``). Since ``sorted`` is
    stable, such ties would otherwise be broken by input order, which violates
    order-independence (Requirement 16.2). Appending ``operation``, ``state``,
    and ``evidence_id`` makes the key total so numbering is fully independent of
    the order in which ``decisions`` are supplied, while preserving the design's
    leading phase/operation ranks.
    """
    return (
        Phase[step.phase],
        OPERATION_ORDER[step.operation],
        step.system_id,
        step.resource_id,
        step.operation,
        step.state,
        step.evidence_id,
    )


def _number(steps: list[Step]) -> list[Step]:
    """Sort ``steps`` by the canonical key and assign ``step_no`` 1..N.

    Numbering is a pure function of the sorted list, so the result is
    independent of the input order (Requirements 10.3, 10.5, 16.2).
    """
    ordered = sorted(steps, key=_sort_key)
    return [
        Step(
            step_no=i,
            phase=s.phase,
            system_id=s.system_id,
            resource_id=s.resource_id,
            operation=s.operation,
            state=s.state,
            evidence_id=s.evidence_id,
        )
        for i, s in enumerate(ordered, start=1)
    ]


def generate_steps(status: str, decisions: list[PolicyDecision]) -> list[Step]:
    """Return the ordered, consecutively numbered step plan for a case.

    See the module docstring for the full per-status contract. ``status`` is one
    of ``COMPLETE`` / ``INCOMPLETE`` / ``NOT_APPLICABLE``.
    """
    # NOT_APPLICABLE: no auditable work (Requirement 9.1).
    if status == "NOT_APPLICABLE":
        return []

    steps: list[Step] = []

    if status == "COMPLETE":
        # VERIFICATION-only, one per (compliant) decision, each citing the
        # evidence that proved the compliant state (Requirement 9.2).
        for d in decisions:
            steps.append(
                _make_step(
                    _VERIFICATION,
                    d.verification_op,
                    d,
                    d.state.proving_evidence_id,
                )
            )
        return _number(steps)

    if status == "INCOMPLETE":
        # Remediate only the non-compliant decisions; already-compliant records
        # need no finding/remediation/verification in the plan.
        non_compliant = [d for d in decisions if not d.compliant]

        # FINDING: cite the participant-visible proving evidence (Req 9.3).
        for d in non_compliant:
            if d.finding_op is not None:
                steps.append(
                    _make_step(
                        _FINDING,
                        d.finding_op,
                        d,
                        d.state.proving_evidence_id,
                    )
                )

        # REMEDIATION: future work, empty evidence_id (Req 9.4).
        for d in non_compliant:
            if d.remediation_op is not None:
                steps.append(_make_step(_REMEDIATION, d.remediation_op, d, ""))

        # VERIFICATION of each remediated record: future work, empty evidence_id
        # (Req 9.4). Verification covers the required final state for each
        # remediated record/process (AGENTS.md §6.5).
        for d in non_compliant:
            steps.append(_make_step(_VERIFICATION, d.verification_op, d, ""))

        return _number(steps)

    # Unknown status: no steps. (decide() only ever yields the three statuses.)
    return []
