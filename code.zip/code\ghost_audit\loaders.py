"""Input loaders for the deletion-audit pipeline.

Each loader reads one participant-facing CSV under ``dataset/`` into the typed
structures defined in :mod:`ghost_audit.models`. All paths are resolved relative
to the repository root passed in as ``root`` so the pipeline works identically
on macOS, Linux, and Windows (Requirements 14.1, 15.1).

Timestamps in the dataset are ISO-8601 with a trailing ``Z`` (UTC). They are
parsed into timezone-aware :class:`datetime.datetime` values so that all
downstream ``audit_at`` gating compares aware datetimes consistently.
"""

from __future__ import annotations

import csv
from datetime import datetime, timezone
from pathlib import Path

from .models import (
    ActivityRow,
    AuditLogEntry,
    Case,
    EvidenceFile,
    IdentitySnapshot,
    IdentityStore,
    PolicyRule,
)

__all__ = [
    "DATASET_DIR",
    "parse_timestamp",
    "load_requests",
    "load_identities",
    "load_rules",
    "load_evidence_manifest",
    "load_system_activity",
]

# Name of the participant-facing dataset directory, relative to the repo root.
DATASET_DIR = "dataset"


def parse_timestamp(value: str) -> datetime:
    """Parse an ISO-8601 timestamp into a timezone-aware UTC ``datetime``.

    Dataset timestamps use a trailing ``Z`` to denote UTC (e.g.
    ``2026-07-16T08:00:00Z``). ``datetime.fromisoformat`` does not accept ``Z``
    before Python 3.11, so it is normalized to ``+00:00`` first. Values that are
    already offset-aware are returned unchanged; naive values are assumed UTC.
    """
    text = value.strip()
    if text.endswith("Z") or text.endswith("z"):
        text = text[:-1] + "+00:00"
    parsed = datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _open_rows(path: Path):
    """Yield ``dict`` rows from a UTF-8 CSV, tolerating a BOM."""
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        yield from csv.DictReader(handle)


def load_requests(root: Path, filename: str = "deletion_requests.csv") -> list[Case]:
    """Load a deletion-requests CSV into a list of :class:`Case`.

    Columns: ``case_id,email,requested_at,reported_status,reported_at,audit_at,
    request_text`` (518 rows in the evaluation ``deletion_requests.csv``; 32 in
    the public ``sample_deletion_requests.csv``). ``filename`` selects which
    participant-facing request file under ``dataset/`` to read so the same
    loader serves both the full run and the sample-set harness (Req 13.1).
    """
    path = Path(root) / DATASET_DIR / filename
    cases: list[Case] = []
    for row in _open_rows(path):
        cases.append(
            Case(
                case_id=row["case_id"],
                email=row["email"],
                requested_at=parse_timestamp(row["requested_at"]),
                reported_status=row["reported_status"],
                reported_at=parse_timestamp(row["reported_at"]),
                audit_at=parse_timestamp(row["audit_at"]),
                request_text=row["request_text"],
            )
        )
    return cases


def load_identities(root: Path) -> IdentityStore:
    """Load ``user_identities.csv`` and ``user_audit_log.csv``.

    The current snapshot rows and the historical change rows are returned
    together in an :class:`IdentityStore` for later identity resolution.
    """
    identities_path = Path(root) / DATASET_DIR / "user_identities.csv"
    audit_path = Path(root) / DATASET_DIR / "user_audit_log.csv"

    snapshots: list[IdentitySnapshot] = []
    for row in _open_rows(identities_path):
        snapshots.append(
            IdentitySnapshot(
                user_id=row["user_id"],
                name=row["name"],
                email=row["email"],
                phone=row["phone"],
                email_hash=row["email_hash"],
                updated_at=parse_timestamp(row["updated_at"]),
            )
        )

    audit_log: list[AuditLogEntry] = []
    for row in _open_rows(audit_path):
        audit_log.append(
            AuditLogEntry(
                audit_id=row["audit_id"],
                user_id=row["user_id"],
                event_time=parse_timestamp(row["event_time"]),
                field_name=row["field_name"],
                old_value=row["old_value"],
                new_value=row["new_value"],
            )
        )

    return IdentityStore(
        snapshots=tuple(snapshots),
        audit_log=tuple(audit_log),
    )


def load_rules(root: Path) -> dict[str, PolicyRule]:
    """Load ``deletion_rules.csv`` into a dict keyed by ``data_category``.

    Columns: ``rule_id,data_category,condition,required_action``. Each data
    category maps to exactly one rule in the supplied dataset.
    """
    path = Path(root) / DATASET_DIR / "deletion_rules.csv"
    rules: dict[str, PolicyRule] = {}
    for row in _open_rows(path):
        rule = PolicyRule(
            rule_id=row["rule_id"],
            data_category=row["data_category"],
            condition=row["condition"],
            required_action=row["required_action"],
        )
        rules[rule.data_category] = rule
    return rules


def load_evidence_manifest(root: Path) -> list[EvidenceFile]:
    """Load ``evidence_files.csv`` into a list of :class:`EvidenceFile`.

    Columns: ``file_id,file_path,origin,captured_at``. ``file_path`` is stored
    relative to the ``dataset/`` directory (e.g. ``evidence/logs/...``); it is
    resolved to an absolute path under ``dataset/`` so parsers can open the
    file regardless of the current working directory.
    """
    dataset_root = Path(root) / DATASET_DIR
    path = dataset_root / "evidence_files.csv"
    files: list[EvidenceFile] = []
    for row in _open_rows(path):
        resolved_path = str(dataset_root / Path(row["file_path"]))
        files.append(
            EvidenceFile(
                file_id=row["file_id"],
                file_path=resolved_path,
                origin=row["origin"],
                captured_at=parse_timestamp(row["captured_at"]),
            )
        )
    return files


def load_system_activity(root: Path) -> list[ActivityRow]:
    """Load ``system_activity.csv`` into a list of :class:`ActivityRow`.

    These rows are treated only as claims by the pipeline (Requirement 5.2).
    Columns: ``activity_id,event_time,event_type,source_system,target_system,
    resource_id,reported_result,details``.
    """
    path = Path(root) / DATASET_DIR / "system_activity.csv"
    rows: list[ActivityRow] = []
    for row in _open_rows(path):
        rows.append(
            ActivityRow(
                activity_id=row["activity_id"],
                event_time=parse_timestamp(row["event_time"]),
                event_type=row["event_type"],
                source_system=row["source_system"],
                target_system=row["target_system"],
                resource_id=row["resource_id"],
                reported_result=row["reported_result"],
                details=row["details"],
            )
        )
    return rows
