"""Property-based tests for the decision engine.

These tests use Hypothesis to validate universal properties of
``code/ghost_audit/decision.py`` across many generated inputs.

Properties covered:

- 11.2 ``decide`` returns exactly one of COMPLETE/INCOMPLETE/NOT_APPLICABLE for
  every case (**Validates: Requirement 8.4**).

The generators build arbitrary combinations of (identity present or ``None``),
a random list of :class:`PolicyDecision` with random ``compliant`` booleans, and
a random :class:`IntentResult`, so the single-status invariant is exercised
across the whole input space.
"""

from __future__ import annotations

from hypothesis import given
from hypothesis import strategies as st

from ghost_audit.decision import COMPLETE, INCOMPLETE, NOT_APPLICABLE, decide
from ghost_audit.intent import IntentResult
from ghost_audit.models import PolicyDecision, RecordState, ResolvedIdentity

_VALID_STATUSES = {COMPLETE, INCOMPLETE, NOT_APPLICABLE}


def _record_state(compliant: bool) -> RecordState:
    """A minimal RecordState; its fields don't affect the decision directly."""
    return RecordState(
        system_id="sys",
        resource_id="res",
        data_category="USER_PROFILE",
        present=not compliant,
        exposed_identifiers=frozenset(),
        treatment="NONE",
        is_active_flow=False,
        is_restore_risk=False,
        proving_evidence_id="evidence_01",
    )


@st.composite
def _policy_decisions(draw) -> list[PolicyDecision]:
    """Generate a random list of PolicyDecisions with random compliant flags."""
    compliant_flags = draw(st.lists(st.booleans(), max_size=6))
    return [
        PolicyDecision(
            state=_record_state(flag),
            required_action="DELETE",
            compliant=flag,
            finding_op=None if flag else "REPORT_REMAINING_RECORD",
            remediation_op=None if flag else "DELETE_RECORD",
            verification_op="VERIFY_RECORD_ABSENT",
        )
        for flag in compliant_flags
    ]


@st.composite
def _identities(draw) -> ResolvedIdentity | None:
    """Generate either ``None`` or a populated ResolvedIdentity."""
    if draw(st.booleans()):
        return None
    return ResolvedIdentity(
        user_id=draw(st.text(min_size=1, max_size=8)),
        emails=frozenset(),
        email_hashes=frozenset(),
        phones=frozenset(),
        names=frozenset(),
    )


_intents = st.builds(
    IntentResult,
    is_deletion=st.booleans(),
    reason=st.sampled_from(
        ["deletion_term", "no_signal", "exclusion_intent", "weak_deletion_term"]
    ),
)


class TestSingleStatusAssignment:
    """Task 11.2 property test for :func:`decide`."""

    @given(identity=_identities(), decisions=_policy_decisions(), intent=_intents)
    def test_decide_returns_exactly_one_valid_status(self, identity, decisions, intent):
        """Property: decide returns exactly one of the three valid statuses.

        Validates: Requirement 8.4

        For every combination of identity (present or ``None``), arbitrary
        policy decisions, and intent, ``decide`` must return a single string
        that is one of COMPLETE / INCOMPLETE / NOT_APPLICABLE.
        """
        result = decide(identity, decisions, intent)
        assert isinstance(result, str)
        assert result in _VALID_STATUSES
