"""Optional LLM-assisted intent engine (Requirements 4.3, 1.1).

Deterministic-first, LLM-optional
---------------------------------

The deterministic lexicon classifier (:class:`ghost_audit.intent.DeterministicEngine`)
is the default and the only required path; it makes **zero** model calls. This
module provides an *optional* engine that implements the same ``Engine`` protocol
(``classify(self, request_text) -> IntentResult``) and only escalates genuinely
ambiguous inputs to a model.

The escalation contract:

1. :meth:`LLMEngine.classify` first runs the deterministic engine.
2. If the deterministic result is confident (``reason != "no_signal"``), that
   result is returned unchanged -- no model call is made.
3. Only when the deterministic result is ambiguous (``reason == "no_signal"``)
   does the engine *attempt* a model call via :meth:`LLMEngine._maybe_llm_classify`.

No network calls by default
---------------------------

This repository must not require third-party SDKs and must not make network
calls by default. The actual model call therefore lives behind a lazily-imported,
credential-guarded client:

- If the relevant SDK (``openai`` / ``anthropic``) is not importable, or the API
  key is absent from ``os.environ`` (``OPENAI_API_KEY`` / ``ANTHROPIC_API_KEY``),
  :meth:`_maybe_llm_classify` returns ``None`` **without** making a call or
  recording any usage. ``classify`` then returns the deterministic result.
- In the default/no-credentials environment this means ZERO calls, zero tokens,
  and fully deterministic behaviour (usage stays at zero).
- If credentials *are* present, a minimal model call MAY be made; every real
  call is recorded via :meth:`UsageReporter.record_call` so the usage report is
  accurate (Requirements 18.2-18.6). Because this environment cannot exercise a
  real call, the request itself is kept behind the import/credential guard and
  the method degrades to the deterministic result when not configured.

Normalizing LLM output back to the deterministic contract
----------------------------------------------------------

Whatever an LLM returns, it is normalized back into the same
:class:`ghost_audit.intent.IntentResult` boolean contract
(``is_deletion: bool``, ``reason: str``). Downstream decision and ordering logic
therefore see an identical structure regardless of which engine produced it, so
the pipeline's determinism and step ordering are unaffected (design
"LLM-assisted path"). When the model is used, the ``reason`` is set to
``"llm_classified"``.

The PDF/image OCR fallback described in the design is handled conceptually by
``parsers/pdf.py`` and ``parsers/image.py`` and is out of scope for this module,
which focuses solely on the intent :class:`Engine`.

Safety
------

:meth:`classify` never raises: any failure in the optional path is caught and
the deterministic result is returned instead.
"""

from __future__ import annotations

import os

from ..intent import DeterministicEngine, Engine, IntentResult
from ..usage import UsageReporter

__all__ = ["LLMEngine", "build_engine"]


# Reason tag applied to any intent result derived from a real model call, so it
# is distinguishable from deterministic reasons in logs and explanations.
_LLM_REASON = "llm_classified"

# The deterministic reason tag that marks an ambiguous ("no signal") text --
# the only case in which we consider escalating to a model.
_AMBIGUOUS_REASON = "no_signal"

# Provider -> environment variable that holds the API key. Presence of the key
# (and an importable SDK) is what gates any real call.
_PROVIDER_ENV_KEY = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
}


class LLMEngine:
    """Deterministic-first intent engine with an optional model fallback.

    The engine always runs the deterministic lexicon classifier first and only
    escalates genuinely ambiguous (``no_signal``) texts to a model -- and even
    then only when an SDK and credentials are available. In the default
    environment (no SDK/credentials) it is behaviourally identical to the
    deterministic engine and records zero usage.
    """

    def __init__(
        self,
        provider: str,
        model: str,
        usage: UsageReporter | None = None,
        deterministic: Engine | None = None,
    ) -> None:
        self._provider = (provider or "").strip().lower()
        self._model = (model or "").strip()
        self._usage = usage
        # Default to the shared deterministic lexicon engine.
        self._deterministic: Engine = (
            deterministic if deterministic is not None else DeterministicEngine()
        )

    def classify(self, request_text: str) -> IntentResult:
        """Classify ``request_text`` deterministically, escalating only if ambiguous.

        Returns the deterministic result unless it is ambiguous
        (``reason == "no_signal"``) AND a model call succeeds via
        :meth:`_maybe_llm_classify`. The method never raises: any error in the
        optional path falls back to the deterministic result.
        """
        result = self._deterministic.classify(request_text)

        # Deterministic engine is confident -> return it, make no model call.
        if result.reason != _AMBIGUOUS_REASON:
            return result

        # Ambiguous: optionally escalate to the model. Never let the optional
        # path raise out of classify; fall back to the deterministic result.
        try:
            llm_result = self._maybe_llm_classify(request_text)
        except Exception:
            llm_result = None

        if llm_result is not None:
            return llm_result
        return result

    def _maybe_llm_classify(self, request_text: str) -> IntentResult | None:
        """Attempt a model classification, or return ``None`` when not configured.

        Returns ``None`` (no call, no usage recorded) when the required SDK is
        not importable or no API key is present in ``os.environ``. This is the
        default path in this environment, keeping the engine deterministic and
        usage at zero.

        When an SDK and credentials ARE available, a minimal real call MAY be
        made; if so, usage MUST be recorded via ``self._usage.record_call(...)``
        and the returned :class:`IntentResult` carries ``reason="llm_classified"``.
        Because real calls cannot be exercised here, the actual request stays
        behind the guard below and the method returns ``None`` when unconfigured.
        """
        env_key = _PROVIDER_ENV_KEY.get(self._provider)
        if env_key is None:
            # Unknown/unsupported provider: no safe way to call; stay offline.
            return None

        api_key = os.environ.get(env_key)
        if not api_key:
            # No credentials -> no call, no usage. Deterministic fallback.
            return None

        # Lazily import the SDK only when credentials are present, so the
        # deterministic default never requires the optional dependency.
        client = self._load_client(api_key)
        if client is None:
            # SDK not installed -> no call, no usage. Deterministic fallback.
            return None

        # Credentials + SDK are present. A real implementation would issue a
        # minimal classification request here and record token usage. We keep
        # the request itself behind this guard because real network calls are
        # out of scope for this environment; a concrete deployment can fill in
        # the request/response handling and MUST record usage like so:
        #
        #     response = client.<classify request for request_text>
        #     in_tok, out_tok = <token counts from response>
        #     if self._usage is not None:
        #         self._usage.record_call(
        #             self._provider, self._model, in_tok, out_tok
        #         )
        #     is_deletion = <bool parsed from response>
        #     return IntentResult(is_deletion=is_deletion, reason=_LLM_REASON)
        #
        # Until that is implemented, degrade safely to the deterministic result.
        return None

    def _load_client(self, api_key: str):
        """Lazily import and construct the provider SDK client, or return ``None``.

        Importing is wrapped so a missing optional dependency never breaks the
        deterministic default. The constructed client is returned only to gate
        whether a real call *could* be made; no request is issued here.
        """
        try:  # pragma: no cover - optional dependency, not installed by default
            if self._provider == "openai":
                import openai  # type: ignore[import-not-found]

                return openai.OpenAI(api_key=api_key)
            if self._provider == "anthropic":
                import anthropic  # type: ignore[import-not-found]

                return anthropic.Anthropic(api_key=api_key)
        except Exception:
            return None
        return None


def build_engine(
    provider: str, model: str, usage: UsageReporter | None = None
) -> Engine:
    """Construct an :class:`LLMEngine` (the optional LLM-assisted intent engine).

    This is the factory imported lazily by
    ``ghost_audit.pipeline.select_engine`` via
    ``from .engines.llm import build_engine``. It returns an object satisfying
    the :class:`ghost_audit.intent.Engine` protocol. The returned engine is
    deterministic-first and makes zero model calls unless an SDK and credentials
    are present (Requirements 4.3, 1.1, 15.3, 15.4).
    """
    return LLMEngine(provider=provider, model=model, usage=usage)
