"""Identity resolution for the deletion-audit pipeline (Requirement 2).

The :func:`resolve_identity` function takes a :class:`~ghost_audit.models.Case`
and the loaded :class:`~ghost_audit.models.IdentityStore` (current snapshot rows
from ``user_identities.csv`` plus historical change rows from
``user_audit_log.csv``) and resolves:

1. the subject's stable ``user_id`` (Requirements 2.1, 2.3), and
2. the set of identifiers (emails, email hashes, phones, names) valid at or
   before the Case ``audit_at`` (Requirements 2.2, 2.4).

Matching is case-insensitive for emails (via
:func:`ghost_audit.normalize.normalize_email`) and casefolded-exact for
``email_hash`` values. A match may occur against a *current* email/hash in the
snapshot or a *historical* email/hash recorded in the audit log; either form
resolves the same stable ``user_id`` the snapshot assigns to that subject
(Requirement 2.3). When nothing matches, :func:`resolve_identity` returns
``None`` to signal "no subject resolved" (Requirement 2.5).

audit_at gating of historical identifiers (Requirement 2.4)
-----------------------------------------------------------
Requirement 2.4 says to include only identifier values whose associated
``event_time`` is at or before ``audit_at``. Each identity field carries a
distinct notion of "event time":

- The current snapshot (``user_identities.csv``) has a single ``updated_at`` that
  acts as the event_time for *every* value in that row. A snapshot value is
  therefore included only if ``snapshot.updated_at <= audit_at``.
- Each audit-log row (``user_audit_log.csv``) records a change to one field at a
  specific ``event_time``: ``old_value`` was the active identifier *before* the
  change and ``new_value`` became active *at* the change. Both of these were
  real identifiers that existed at or before ``event_time``, so when
  ``event_time <= audit_at`` we include BOTH ``old_value`` and ``new_value`` for
  that field. This conservative choice maximizes recall for matching records
  that may still carry an older identifier in downstream systems, while never
  admitting any value whose change happened *after* ``audit_at``.

Note that matching (deciding which subject the Case email belongs to) is
performed against the full snapshot + audit history and is NOT gated by
``audit_at`` -- gating only governs which identifiers are *compiled into* the
resulting identifier sets used for evidence matching. The subject's identity is
a fact about who they are; the gate controls which of their identifiers were
valid at the audit cutoff.
"""

from __future__ import annotations

from datetime import datetime

from .models import (
    AuditLogEntry,
    Case,
    IdentitySnapshot,
    IdentityStore,
    ResolvedIdentity,
)
from .normalize import normalize_email, normalize_name

__all__ = ["resolve_identity"]

# Audit-log field names that carry each kind of identifier. ``field_name``
# values in ``user_audit_log.csv`` use these tokens.
_EMAIL_FIELD = "email"
_EMAIL_HASH_FIELD = "email_hash"
_PHONE_FIELD = "phone"
_NAME_FIELD = "name"


def _normalize_hash(value: str) -> str:
    """Normalize an ``email_hash`` for exact, case-insensitive comparison.

    Hashes have no accents or internal whitespace to worry about, so a simple
    strip + casefold yields a canonical form that compares equal regardless of
    the original casing.
    """
    if value is None:
        return ""
    return value.strip().casefold()


def _subject_matches(
    snapshot: IdentitySnapshot,
    audit_rows: list[AuditLogEntry],
    target_email: str,
    target_hash_candidates: set[str],
) -> bool:
    """Return ``True`` if this subject matches the Case email/hash.

    A subject matches when the Case email (normalized) equals any of the
    subject's current or historical emails, OR when the Case value matches any
    of the subject's current or historical ``email_hash`` values.

    ``audit_rows`` are the audit-log entries already filtered to this subject's
    ``user_id``. Matching considers the full history (not gated by ``audit_at``)
    because subject identity does not change with the audit cutoff.
    """
    # Current snapshot email / hash.
    if target_email and normalize_email(snapshot.email) == target_email:
        return True
    snapshot_hash = _normalize_hash(snapshot.email_hash)
    if snapshot_hash and snapshot_hash in target_hash_candidates:
        return True

    # Historical emails / hashes from the audit log (old and new values).
    for row in audit_rows:
        if row.field_name == _EMAIL_FIELD:
            if target_email and (
                normalize_email(row.old_value) == target_email
                or normalize_email(row.new_value) == target_email
            ):
                return True
        elif row.field_name == _EMAIL_HASH_FIELD:
            if _normalize_hash(row.old_value) in target_hash_candidates and target_hash_candidates:
                return True
            if _normalize_hash(row.new_value) in target_hash_candidates and target_hash_candidates:
                return True
    return False


def _collect_identifiers(
    snapshot: IdentitySnapshot,
    audit_rows: list[AuditLogEntry],
    audit_at: datetime,
) -> tuple[frozenset[str], frozenset[str], frozenset[str], frozenset[str]]:
    """Compile the gated identifier sets for a resolved subject.

    Includes snapshot values only when ``snapshot.updated_at <= audit_at`` and
    audit-log ``old_value``/``new_value`` pairs only when their
    ``event_time <= audit_at`` (see module docstring for the reasoning).

    Empty strings are never added so that downstream evidence matching does not
    spuriously treat a blank as an identifier.
    """
    emails: set[str] = set()
    email_hashes: set[str] = set()
    phones: set[str] = set()
    names: set[str] = set()

    def add_email(value: str) -> None:
        norm = normalize_email(value)
        if norm:
            emails.add(norm)

    def add_hash(value: str) -> None:
        norm = _normalize_hash(value)
        if norm:
            email_hashes.add(norm)

    def add_phone(value: str) -> None:
        if value and value.strip():
            phones.add(value.strip())

    def add_name(value: str) -> None:
        norm = normalize_name(value)
        if norm:
            names.add(norm)

    # Current snapshot values are gated by the snapshot's updated_at.
    if snapshot.updated_at <= audit_at:
        add_email(snapshot.email)
        add_hash(snapshot.email_hash)
        add_phone(snapshot.phone)
        add_name(snapshot.name)

    # Historical values gated by each change's event_time.
    for row in audit_rows:
        if row.event_time > audit_at:
            continue
        if row.field_name == _EMAIL_FIELD:
            add_email(row.old_value)
            add_email(row.new_value)
        elif row.field_name == _EMAIL_HASH_FIELD:
            add_hash(row.old_value)
            add_hash(row.new_value)
        elif row.field_name == _PHONE_FIELD:
            add_phone(row.old_value)
            add_phone(row.new_value)
        elif row.field_name == _NAME_FIELD:
            add_name(row.old_value)
            add_name(row.new_value)

    return (
        frozenset(emails),
        frozenset(email_hashes),
        frozenset(phones),
        frozenset(names),
    )


def resolve_identity(case: Case, store: IdentityStore) -> ResolvedIdentity | None:
    """Resolve the subject's stable ``user_id`` and gated identifier sets.

    Args:
        case: The deletion request whose ``email`` identifies the subject and
            whose ``audit_at`` gates which identifiers are compiled.
        store: The loaded :class:`IdentityStore` (current snapshots + audit log).

    Returns:
        A :class:`ResolvedIdentity` when the Case email matches a current or
        historical email/hash for some subject (Requirements 2.1-2.4), or
        ``None`` when nothing matches any subject (Requirement 2.5).

    When several snapshot rows share a ``user_id`` (not expected in the dataset,
    which has one row per user) the first matching row is used. Historical and
    current matches both resolve the ``user_id`` recorded on the matching rows,
    so a historical-email hit yields the same ``user_id`` the snapshot assigns to
    that subject (Requirement 2.3).
    """
    target_email = normalize_email(case.email)
    # The Case email could itself be an email_hash in unusual data; treat the
    # normalized email token as a hash candidate too so a hash-only match still
    # resolves. The primary hash candidate is the casefolded raw email value.
    target_hash_candidates: set[str] = set()
    raw_hash = _normalize_hash(case.email)
    if raw_hash:
        target_hash_candidates.add(raw_hash)

    # Index audit-log rows by user_id for efficient per-subject lookup.
    audit_by_user: dict[str, list[AuditLogEntry]] = {}
    for row in store.audit_log:
        audit_by_user.setdefault(row.user_id, []).append(row)

    # First, try to match against current snapshot subjects (and their history).
    matched_user_id: str | None = None
    matched_snapshot: IdentitySnapshot | None = None
    for snapshot in store.snapshots:
        audit_rows = audit_by_user.get(snapshot.user_id, [])
        if _subject_matches(snapshot, audit_rows, target_email, target_hash_candidates):
            matched_user_id = snapshot.user_id
            matched_snapshot = snapshot
            break

    # If no snapshot subject matched directly, the email may appear only in the
    # audit log for a user_id that still has a current snapshot. Scan audit rows
    # to find the owning user_id, then resolve that user's snapshot.
    if matched_user_id is None:
        snapshot_by_user = {s.user_id: s for s in store.snapshots}
        for row in store.audit_log:
            is_email_match = row.field_name == _EMAIL_FIELD and target_email and (
                normalize_email(row.old_value) == target_email
                or normalize_email(row.new_value) == target_email
            )
            is_hash_match = (
                row.field_name == _EMAIL_HASH_FIELD
                and target_hash_candidates
                and (
                    _normalize_hash(row.old_value) in target_hash_candidates
                    or _normalize_hash(row.new_value) in target_hash_candidates
                )
            )
            if is_email_match or is_hash_match:
                matched_user_id = row.user_id
                matched_snapshot = snapshot_by_user.get(row.user_id)
                break

    if matched_user_id is None:
        # Requirement 2.5: no subject resolved for this Case.
        return None

    audit_rows = audit_by_user.get(matched_user_id, [])
    if matched_snapshot is not None:
        emails, email_hashes, phones, names = _collect_identifiers(
            matched_snapshot, audit_rows, case.audit_at
        )
    else:
        # Subject exists only in the audit history (no current snapshot row).
        # Compile identifiers from the gated audit history alone.
        emails, email_hashes, phones, names = _collect_identifiers(
            _empty_snapshot(matched_user_id, case.audit_at),
            audit_rows,
            case.audit_at,
        )

    return ResolvedIdentity(
        user_id=matched_user_id,
        emails=emails,
        email_hashes=email_hashes,
        phones=phones,
        names=names,
    )


def _empty_snapshot(user_id: str, audit_at: datetime) -> IdentitySnapshot:
    """Build a placeholder snapshot that contributes no current values.

    Used when a subject is resolvable only through the audit log. The
    ``updated_at`` is set just after ``audit_at`` so the empty current fields are
    excluded by the gate and only historical audit values are compiled.
    """
    from datetime import timedelta

    return IdentitySnapshot(
        user_id=user_id,
        name="",
        email="",
        phone="",
        email_hash="",
        updated_at=audit_at + timedelta(seconds=1),
    )
