"""Unit tests for the decision engine (``code/ghost_audit/decision.py``).

Covers the decision branches (Requirements 8.1, 8.2, 8.3):

- non-authorizing intent => NOT_APPLICABLE (even with a resolved identity and
  decisions present);
- authorizing + identity + all decisions compliant => COMPLETE;
- authorizing + identity + any non-compliant decision => INCOMPLETE;
- authorizing + identity None => NOT_APPLICABLE.
"""

from __future__ import annotations

from ghost_audit.decision import (
    COMPLETE,
    EMPTY_DECISIONS_STATUS,
    INCOMPLETE,
    NOT_APPLICABLE,
    decide,
)
from ghost_audit.intent import IntentResult
from ghost_audit.models import PolicyDecision, RecordState, ResolvedIdentity

# --- Fixtures --------------------------------------------------------------

_IDENTITY = ResolvedIdentity(
    user_id="user_001",
    emails=frozenset({"ada@example.com"}),
    email_hashes=frozenset(),
    phones=frozenset(),
    names=frozenset({"ada lovelace"}),
)

_AUTHORIZING = IntentResult(is_deletion=True, reason="deletion_term")
_NON_AUTHORIZING = IntentResult(is_deletion=False, reason="exclusion_intent")


def _state(
    data_category: str = "USER_PROFILE",
    *,
    present: bool = False,
    is_active_flow: bool = False,
    is_restore_risk: bool = False,
    system_id: str = "account_service",
    resource_id: str = "account_001",
) -> RecordState:
    return RecordState(
        system_id=system_id,
        resource_id=resource_id,
        data_category=data_category,
        present=present,
        exposed_identifiers=frozenset(),
        treatment="NONE",
        is_active_flow=is_active_flow,
        is_restore_risk=is_restore_risk,
        proving_evidence_id="evidence_01",
    )


def _decision(compliant: bool, state: RecordState | None = None) -> PolicyDecision:
    st = state if state is not None else _state(present=not compliant)
    return PolicyDecision(
        state=st,
        required_action="DELETE",
        compliant=compliant,
        finding_op=None if compliant else "REPORT_REMAINING_RECORD",
        remediation_op=None if compliant else "DELETE_RECORD",
        verification_op="VERIFY_RECORD_ABSENT",
    )


# --- Non-authorizing intent => NOT_APPLICABLE (Requirement 8.3) ------------


class TestNonAuthorizing:
    def test_non_authorizing_is_not_applicable_even_with_identity_and_decisions(self):
        """Non-deletion intent short-circuits to NOT_APPLICABLE.

        Even with a resolved identity and compliant decisions present, a
        non-authorizing request is NOT_APPLICABLE (Requirements 8.3, 1.2).
        """
        decisions = [_decision(True), _decision(True)]
        assert decide(_IDENTITY, decisions, _NON_AUTHORIZING) == NOT_APPLICABLE

    def test_non_authorizing_wins_over_non_compliant_decisions(self):
        """Non-authorizing intent overrides even non-compliant decisions."""
        decisions = [_decision(False)]
        assert decide(_IDENTITY, decisions, _NON_AUTHORIZING) == NOT_APPLICABLE


# --- Authorizing + identity + all compliant => COMPLETE (Requirement 8.1) --


class TestComplete:
    def test_all_compliant_is_complete(self):
        """Every relevant copy carrying its required treatment => COMPLETE."""
        decisions = [_decision(True), _decision(True), _decision(True)]
        assert decide(_IDENTITY, decisions, _AUTHORIZING) == COMPLETE

    def test_single_compliant_is_complete(self):
        decisions = [_decision(True)]
        assert decide(_IDENTITY, decisions, _AUTHORIZING) == COMPLETE


# --- Authorizing + identity + any non-compliant => INCOMPLETE (Req 8.2) ----


class TestIncomplete:
    def test_remaining_record_is_incomplete(self):
        """A remaining (present) record that should be absent => INCOMPLETE."""
        decisions = [_decision(True), _decision(False)]
        assert decide(_IDENTITY, decisions, _AUTHORIZING) == INCOMPLETE

    def test_active_data_flow_is_incomplete(self):
        """An active data flow surfaces as a non-compliant decision."""
        flow_state = _state(
            data_category="DATA_FLOW",
            present=True,
            is_active_flow=True,
            system_id="integration_service",
            resource_id="connector_001",
        )
        flow_decision = PolicyDecision(
            state=flow_state,
            required_action="DISABLE",
            compliant=False,
            finding_op="REPORT_ACTIVE_DATA_FLOW",
            remediation_op="DISABLE_DATA_FLOW",
            verification_op="VERIFY_DATA_FLOW_DISABLED",
        )
        decisions = [_decision(True), flow_decision]
        assert decide(_IDENTITY, decisions, _AUTHORIZING) == INCOMPLETE

    def test_unblocked_restore_is_incomplete(self):
        """An unblocked restore path surfaces as a non-compliant decision."""
        restore_state = _state(
            data_category="BACKUP_ARCHIVE",
            present=True,
            is_restore_risk=True,
            system_id="backup_service",
            resource_id="archive_001",
        )
        restore_decision = PolicyDecision(
            state=restore_state,
            required_action="RETAIN",
            compliant=False,
            finding_op="REPORT_RESTORE_RISK",
            remediation_op="BLOCK_RESTORE",
            verification_op="VERIFY_RESTORE_BLOCKED",
        )
        decisions = [restore_decision]
        assert decide(_IDENTITY, decisions, _AUTHORIZING) == INCOMPLETE


# --- Authorizing + identity None => NOT_APPLICABLE -------------------------


class TestUnresolvedIdentity:
    def test_authorizing_no_identity_is_not_applicable(self):
        """Authorizing request with no resolvable subject => NOT_APPLICABLE."""
        assert decide(None, [], _AUTHORIZING) == NOT_APPLICABLE

    def test_authorizing_no_identity_ignores_decisions(self):
        """With no identity, any stray decisions still yield NOT_APPLICABLE."""
        assert decide(None, [_decision(False)], _AUTHORIZING) == NOT_APPLICABLE


# --- Empty-decisions tunable choice ----------------------------------------


class TestEmptyDecisions:
    def test_authorizing_identity_no_decisions_uses_tunable_default(self):
        """Authorizing + identity + zero decisions uses EMPTY_DECISIONS_STATUS."""
        assert decide(_IDENTITY, [], _AUTHORIZING) == EMPTY_DECISIONS_STATUS
