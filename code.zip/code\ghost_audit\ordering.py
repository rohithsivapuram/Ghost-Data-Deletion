"""Canonical operation ordering for the step plan (Requirements 10.1-10.5).

Steps are sorted by a composite key before they are numbered:

```python
key = (Phase[step.phase], OPERATION_ORDER[step.operation], step.system_id, step.resource_id)
```

- :class:`Phase` ranks the three phases so that ``FINDING`` < ``REMEDIATION`` <
  ``VERIFICATION`` (Requirement 10.1).
- :data:`OPERATION_ORDER` ranks the operations *within* a phase. The remediation
  ranks intentionally place ``DISABLE_DATA_FLOW`` (0) and ``BLOCK_RESTORE`` (1)
  before the dependent record operations ``DELETE_RECORD`` (2),
  ``REDACT_RECORD`` (3), and ``ANONYMIZE_RECORD`` (4), so a data flow is stopped
  and an unsafe restore blocked before dependent records are changed
  (Requirement 10.4).

The ``OPERATION_ORDER`` values are reused per-phase (each phase's operations are
numbered from 0); because the sort key leads with the phase rank, the per-phase
operation ranks never collide across phases.
"""

from __future__ import annotations

from enum import IntEnum

__all__ = ["Phase", "OPERATION_ORDER"]


class Phase(IntEnum):
    """Phase rank used as the leading component of the step sort key.

    ``FINDING`` < ``REMEDIATION`` < ``VERIFICATION`` (Requirement 10.1).
    """

    FINDING = 0
    REMEDIATION = 1
    VERIFICATION = 2


# Operation rank within a phase (Requirements 10.2, 10.4). Values match the
# "Canonical Operation Order" table in design.md exactly.
OPERATION_ORDER: dict[str, int] = {
    # FINDING
    "REPORT_REMAINING_RECORD": 0,
    "REPORT_EXPOSED_PII": 1,
    "REPORT_ACTIVE_DATA_FLOW": 2,
    "REPORT_RESTORE_RISK": 3,
    # REMEDIATION: disable/block precede dependent record ops (Requirement 10.4).
    "DISABLE_DATA_FLOW": 0,
    "BLOCK_RESTORE": 1,
    "DELETE_RECORD": 2,
    "REDACT_RECORD": 3,
    "ANONYMIZE_RECORD": 4,
    # VERIFICATION
    "VERIFY_RECORD_ABSENT": 0,
    "VERIFY_RECORD_PRESENT": 1,
    "VERIFY_RECORD_REDACTED": 2,
    "VERIFY_RECORD_ANONYMIZED": 3,
    "VERIFY_DATA_FLOW_DISABLED": 4,
    "VERIFY_RESTORE_BLOCKED": 5,
}
