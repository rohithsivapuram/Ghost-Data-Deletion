"""Determinism check for the full pipeline (Requirements 16.1, 16.2, 16.3).

This module runs the full deletion-audit pipeline twice over the same inputs and
the same configuration and asserts the two ``output.csv`` artifacts are
equivalent in row order, statuses, and step arrays.

Why this matters
----------------

The challenge requires deterministic output (AGENTS.md §6.7): a clean run must
be reproducible. Three design guarantees back this up and are exercised here:

- :func:`ghost_audit.pipeline.run` parses all evidence once in fixed manifest
  order and reuses the master record list for every case, so case processing is
  order-independent (Requirement 16.1).
- :func:`ghost_audit.steps.generate_steps` sorts and numbers steps purely from
  the sorted list, independent of evidence-processing order (Requirement 16.2).
- :func:`ghost_audit.serialize.steps_to_json` uses ``sort_keys=True`` with
  compact separators, so repeated serialization of the same steps is
  byte-identical (idempotent serialization, Requirement 16.3).

What it does
------------

:func:`run_twice` runs :func:`ghost_audit.pipeline.run` twice with the default
deterministic engine and serializes each result set to the exact ``output.csv``
row shape (header + ``case_id,deletion_status,steps_json`` rows sorted by
``case_id``) via :func:`ghost_audit.serialize`. It does NOT write to disk; it
builds the two row lists in memory so the check is side-effect free and safe to
run anywhere.

:func:`check_determinism` compares the two artifacts and returns a
:class:`DeterminismReport` describing any difference (the first differing
``case_id`` and whether the row order, a status, or a step array diverged). The
CLI entry point prints the report and exits non-zero on any difference so it can
be used as a conformance gate.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from . import pipeline, serialize
from .intent import Engine
from .models import CaseResult

__all__ = [
    "OutputRow",
    "DeterminismReport",
    "results_to_rows",
    "run_twice",
    "check_determinism",
]


# A serialized output row: (case_id, deletion_status, steps_json). This is the
# exact triple that ``write_output`` would write to ``output.csv`` for one case.
OutputRow = tuple[str, str, str]


@dataclass(frozen=True)
class DeterminismReport:
    """The outcome of a two-run determinism comparison.

    ``deterministic`` is True only when both runs produced byte-identical output
    rows in the same order. When False, the remaining fields pinpoint the first
    divergence: ``differing_case_id`` (or ``None`` when only the row count/order
    differs) and a human-readable ``reason``.
    """

    deterministic: bool
    row_count_first: int
    row_count_second: int
    differing_case_id: str | None = None
    reason: str = ""
    differences: list[str] = field(default_factory=list)

    def summary(self) -> str:
        """Render a one-line summary of the comparison outcome."""
        if self.deterministic:
            return (
                f"deterministic: {self.row_count_first} rows identical "
                "across both runs"
            )
        return f"NON-DETERMINISTIC: {self.reason}"


def results_to_rows(results: dict[str, CaseResult]) -> list[OutputRow]:
    """Serialize pipeline results into the ordered ``output.csv`` row shape.

    Rows are produced for exactly the case ids present in ``results`` and sorted
    by ``case_id`` ascending, mirroring :func:`ghost_audit.serialize.write_output`
    (Requirement 11.3). Each ``steps_json`` is produced by
    :func:`ghost_audit.serialize.steps_to_json`, so the comparison runs on the
    exact bytes that would be written to disk (Requirement 16.3).
    """
    case_ids = sorted(results.keys())
    rows: list[OutputRow] = []
    for case_id in case_ids:
        result = results[case_id]
        steps_json = serialize.steps_to_json(list(result.steps))
        rows.append((result.case_id, result.deletion_status, steps_json))
    return rows


def run_twice(
    root: Path,
    engine: Engine | None = None,
    requests_filename: str = "deletion_requests.csv",
) -> tuple[list[OutputRow], list[OutputRow]]:
    """Run the full pipeline twice and return both serialized row lists.

    Both runs use the same ``root``, the same engine (the default deterministic
    engine when ``engine`` is None), and the same request file, so any
    difference between the returned lists is a determinism defect. No files are
    written; the rows are the in-memory equivalent of two ``output.csv``
    artifacts.
    """
    root = Path(root)
    first_results = pipeline.run(
        root, engine=engine, requests_filename=requests_filename
    )
    second_results = pipeline.run(
        root, engine=engine, requests_filename=requests_filename
    )
    return results_to_rows(first_results), results_to_rows(second_results)


def compare_rows(
    first: list[OutputRow], second: list[OutputRow]
) -> DeterminismReport:
    """Compare two serialized row lists for full equivalence.

    Checks, in order: equal row count, identical ``case_id`` order, and for each
    position identical ``deletion_status`` and ``steps_json`` (Requirement 16.1).
    Returns a :class:`DeterminismReport`; on the first divergence it records the
    offending ``case_id`` and a reason and stops at the row-level detail.
    """
    if len(first) != len(second):
        return DeterminismReport(
            deterministic=False,
            row_count_first=len(first),
            row_count_second=len(second),
            differing_case_id=None,
            reason=(
                f"row count differs: {len(first)} vs {len(second)}"
            ),
        )

    differences: list[str] = []
    first_divergence: str | None = None
    first_reason = ""

    for (case_a, status_a, steps_a), (case_b, status_b, steps_b) in zip(
        first, second
    ):
        if case_a != case_b:
            reason = f"row order differs: {case_a} vs {case_b}"
            differences.append(reason)
            if first_divergence is None:
                first_divergence = case_a
                first_reason = reason
            continue
        if status_a != status_b:
            reason = (
                f"case {case_a}: status differs {status_a} vs {status_b}"
            )
            differences.append(reason)
            if first_divergence is None:
                first_divergence = case_a
                first_reason = reason
        if steps_a != steps_b:
            reason = f"case {case_a}: steps_json differs"
            differences.append(reason)
            if first_divergence is None:
                first_divergence = case_a
                first_reason = reason

    if differences:
        return DeterminismReport(
            deterministic=False,
            row_count_first=len(first),
            row_count_second=len(second),
            differing_case_id=first_divergence,
            reason=first_reason,
            differences=differences,
        )

    return DeterminismReport(
        deterministic=True,
        row_count_first=len(first),
        row_count_second=len(second),
    )


def check_determinism(
    root: Path,
    engine: Engine | None = None,
    requests_filename: str = "deletion_requests.csv",
) -> DeterminismReport:
    """Run the pipeline twice over ``root`` and report whether output is stable.

    This is the public entry point for the determinism check: it asserts the two
    ``output.csv`` artifacts are equivalent in row order, statuses, and step
    arrays (Requirements 16.1, 16.2, 16.3).
    """
    first, second = run_twice(
        Path(root), engine=engine, requests_filename=requests_filename
    )
    return compare_rows(first, second)


def main(argv: list[str] | None = None) -> int:
    """CLI entry point: run the determinism check and print the report.

    Returns ``0`` when both runs are byte-identical, ``1`` otherwise, so it can
    be used as a conformance gate in CI.
    """
    import argparse

    parser = argparse.ArgumentParser(
        prog="ghost-audit-determinism",
        description="Run the full pipeline twice and confirm identical output.",
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parent.parent.parent,
        help="Repository root containing dataset/ (default: repo root).",
    )
    parser.add_argument(
        "--requests",
        default="deletion_requests.csv",
        help="Request file under dataset/ to audit (default: full set).",
    )
    args = parser.parse_args(argv)

    report = check_determinism(
        Path(args.root).resolve(), requests_filename=args.requests
    )
    print(report.summary())
    if not report.deterministic:
        for diff in report.differences[:20]:
            print(f"  - {diff}")
    return 0 if report.deterministic else 1


if __name__ == "__main__":  # pragma: no cover - thin CLI wrapper
    raise SystemExit(main())
