"""Unit tests for the state reconstructor (``code/ghost_audit/state.py``).

Covers recreation-path flags (active data flow, unblocked restore), exposed
identifier computation, and the treatment mapping.

Requirements: 7.1, 7.2
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from ghost_audit.models import ParsedRecord, ResolvedIdentity
from ghost_audit.state import reconstruct_state

_AUDIT_AT = datetime(2026, 6, 1, tzinfo=timezone.utc)
_OBSERVED = datetime(2026, 5, 1, tzinfo=timezone.utc)

_SUBJECT_EMAIL = "subject@example.com"


def _identity(**overrides) -> ResolvedIdentity:
    """Build a small ResolvedIdentity with a single subject email by default."""
    base = dict(
        user_id="user_1",
        emails=frozenset({_SUBJECT_EMAIL}),
        email_hashes=frozenset(),
        phones=frozenset(),
        names=frozenset(),
    )
    base.update(overrides)
    return ResolvedIdentity(**base)


def _record(**overrides) -> ParsedRecord:
    """Build a ParsedRecord with sensible defaults for state tests."""
    base = dict(
        file_id="evidence_01",
        system_id="account_service",
        resource_id="res_1",
        data_category=None,
        observed_at=_OBSERVED,
        present=True,
        identifiers=frozenset(),
        state_signal="FOUND",
    )
    base.update(overrides)
    return ParsedRecord(**base)


def _matched(*records):
    """Fold records into the (system_id, resource_id) -> record dict shape."""
    return {(r.system_id, r.resource_id): r for r in records}


def _only(states):
    """Assert exactly one state was produced and return it."""
    assert len(states) == 1
    return states[0]


class TestActiveDataFlowDetection:
    """Requirement 7.1: active data-flow detection."""

    def test_active_integration_flow_is_flagged(self):
        rec = _record(
            system_id="integration_service",
            resource_id="connector_1",
            data_category="DATA_FLOW",
            state_signal="ACTIVE",
        )
        state = _only(reconstruct_state(_matched(rec), _identity(), _AUDIT_AT))
        assert state.is_active_flow is True
        assert state.is_restore_risk is False

    def test_disabled_integration_flow_is_not_flagged(self):
        rec = _record(
            system_id="integration_service",
            resource_id="connector_1",
            data_category="DATA_FLOW",
            state_signal="DISABLED",
        )
        state = _only(reconstruct_state(_matched(rec), _identity(), _AUDIT_AT))
        assert state.is_active_flow is False


class TestRestoreRiskDetection:
    """Requirement 7.2: unblocked restore detection."""

    def test_active_backup_is_restore_risk(self):
        rec = _record(
            system_id="backup_service",
            resource_id="archive_1",
            data_category="BACKUP_ARCHIVE",
            state_signal="ACTIVE",
        )
        state = _only(reconstruct_state(_matched(rec), _identity(), _AUDIT_AT))
        assert state.is_restore_risk is True
        # A backup is not an active data flow.
        assert state.is_active_flow is False

    def test_blocked_backup_is_not_restore_risk(self):
        rec = _record(
            system_id="backup_service",
            resource_id="archive_1",
            data_category="BACKUP_ARCHIVE",
            state_signal="BLOCKED",
        )
        state = _only(reconstruct_state(_matched(rec), _identity(), _AUDIT_AT))
        assert state.is_restore_risk is False


class TestExposedIdentifiers:
    """Requirements 7.1/7.2 support: exposed identifier computation."""

    def test_user_profile_found_exposes_subject_email(self):
        rec = _record(
            system_id="account_service",
            resource_id="account_5",
            data_category="USER_PROFILE",
            state_signal="FOUND",
            identifiers=frozenset({_SUBJECT_EMAIL}),
        )
        state = _only(reconstruct_state(_matched(rec), _identity(), _AUDIT_AT))
        assert _SUBJECT_EMAIL in state.exposed_identifiers

    def test_anonymized_tombstone_with_only_user_id_exposes_nothing(self):
        # A compliant tombstone keeps only the stable user_id. The user_id must
        # NOT count as exposed PII.
        rec = _record(
            system_id="identity_service",
            resource_id="tombstone_1",
            data_category="ACCOUNT_TOMBSTONE",
            state_signal="ANONYMIZED",
            identifiers=frozenset({"user_1"}),
        )
        state = _only(reconstruct_state(_matched(rec), _identity(), _AUDIT_AT))
        assert state.exposed_identifiers == frozenset()

    def test_exposed_identifiers_exclude_non_subject_values(self):
        rec = _record(
            identifiers=frozenset({_SUBJECT_EMAIL, "other@example.com"}),
            state_signal="FOUND",
        )
        state = _only(reconstruct_state(_matched(rec), _identity(), _AUDIT_AT))
        assert state.exposed_identifiers == frozenset({_SUBJECT_EMAIL})


class TestTreatmentMapping:
    """Treatment derived from the raw state signal."""

    @pytest.mark.parametrize(
        "signal,expected",
        [
            ("NOT_FOUND", "DELETED"),
            ("ANONYMIZED", "ANONYMIZED"),
            ("REDACTED", "REDACTED"),
            ("FOUND", "NONE"),
            ("IDENTIFIABLE", "NONE"),
            ("ACTIVE", "NONE"),
        ],
    )
    def test_treatment_mapping(self, signal, expected):
        rec = _record(state_signal=signal)
        state = _only(reconstruct_state(_matched(rec), _identity(), _AUDIT_AT))
        assert state.treatment == expected


class TestDeterministicOutput:
    """Output is sorted and one state per matched resource."""

    def test_states_sorted_by_system_then_resource(self):
        rec_a = _record(system_id="search_service", resource_id="res_2")
        rec_b = _record(system_id="account_service", resource_id="res_9")
        rec_c = _record(system_id="account_service", resource_id="res_1")
        states = reconstruct_state(
            _matched(rec_a, rec_b, rec_c), _identity(), _AUDIT_AT
        )
        keys = [(s.system_id, s.resource_id) for s in states]
        assert keys == sorted(keys)

    def test_data_category_falls_back_to_system_map(self):
        rec = _record(system_id="search_service", data_category=None)
        state = _only(reconstruct_state(_matched(rec), _identity(), _AUDIT_AT))
        assert state.data_category == "SEARCH_INDEX_ENTRY"

    def test_record_after_audit_at_is_skipped(self):
        late = _record(observed_at=datetime(2026, 7, 1, tzinfo=timezone.utc))
        states = reconstruct_state(_matched(late), _identity(), _AUDIT_AT)
        assert states == []
