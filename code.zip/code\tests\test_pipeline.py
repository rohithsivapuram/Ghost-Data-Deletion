"""Unit tests for the pipeline orchestrator (``code/ghost_audit/pipeline.py``).

These are fast, in-memory tests of :func:`process_case` built from small
fixtures (no disk I/O, no full 518-case run). They cover the three primary
case outcomes:

- a non-deletion intent case => ``NOT_APPLICABLE`` with no steps;
- a deletion case with a resolved subject and an all-compliant evidence record
  (an absent USER_PROFILE) => ``COMPLETE`` with verification-only steps;
- a deletion case with a present USER_PROFILE record (not yet deleted) =>
  ``INCOMPLETE`` with a finding citing the proving evidence.

They also exercise :func:`select_engine` env handling and the file-level
``audit_at`` gate (Requirement 3.3).

Requirements: 8.4, 14.1, 15.3, 15.4, 16.1
"""

from __future__ import annotations

from datetime import datetime, timezone

from ghost_audit import intent, pipeline
from ghost_audit.models import (
    Case,
    IdentitySnapshot,
    IdentityStore,
    ParsedRecord,
    PolicyRule,
)

_AUDIT_AT = datetime(2026, 6, 1, tzinfo=timezone.utc)
_OBSERVED = datetime(2026, 5, 1, tzinfo=timezone.utc)
_CAPTURED = datetime(2026, 5, 2, tzinfo=timezone.utc)

_SUBJECT_EMAIL = "subject@example.com"
_FILE_ID = "evidence_01"


def _store() -> IdentityStore:
    """A store with a single subject resolvable by ``_SUBJECT_EMAIL``."""
    snapshot = IdentitySnapshot(
        user_id="user_1",
        name="Subject One",
        email=_SUBJECT_EMAIL,
        phone="+15550001",
        email_hash="hash_1",
        updated_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
    )
    return IdentityStore(snapshots=(snapshot,), audit_log=())


def _rules() -> dict[str, PolicyRule]:
    """A minimal rule set mapping USER_PROFILE -> DELETE."""
    return {
        "USER_PROFILE": PolicyRule(
            rule_id="rule_user_profile",
            data_category="USER_PROFILE",
            condition="",
            required_action="DELETE",
        ),
    }


def _case(request_text: str) -> Case:
    """Build a Case for the single subject at ``_AUDIT_AT``."""
    return Case(
        case_id="case_001",
        email=_SUBJECT_EMAIL,
        requested_at=datetime(2026, 4, 1, tzinfo=timezone.utc),
        reported_status="COMPLETE",
        reported_at=datetime(2026, 4, 2, tzinfo=timezone.utc),
        audit_at=_AUDIT_AT,
        request_text=request_text,
    )


def _profile_record(present: bool, state_signal: str) -> ParsedRecord:
    """A USER_PROFILE record for the subject tied to ``_FILE_ID``."""
    return ParsedRecord(
        file_id=_FILE_ID,
        system_id="account_service",
        resource_id="account_5",
        data_category="USER_PROFILE",
        observed_at=_OBSERVED,
        present=present,
        identifiers=frozenset({_SUBJECT_EMAIL}),
        state_signal=state_signal,
    )


_FILE_CAPTURED_AT = {_FILE_ID: _CAPTURED}
_ENGINE = intent.DEFAULT_ENGINE


class TestProcessCase:
    def test_non_deletion_intent_is_not_applicable(self):
        case = _case("Please correct my email; do not close the account.")
        result = pipeline.process_case(
            case, _store(), _rules(), [], _FILE_CAPTURED_AT, _ENGINE
        )
        assert result.case_id == "case_001"
        assert result.deletion_status == "NOT_APPLICABLE"
        assert result.steps == ()

    def test_deletion_with_absent_profile_is_complete(self):
        # An absent USER_PROFILE is compliant with a DELETE rule => COMPLETE.
        record = _profile_record(present=False, state_signal="NOT_FOUND")
        case = _case("Please delete my account and erase all my personal data.")
        result = pipeline.process_case(
            case, _store(), _rules(), [record], _FILE_CAPTURED_AT, _ENGINE
        )
        assert result.deletion_status == "COMPLETE"
        assert len(result.steps) == 1
        step = result.steps[0]
        assert step.phase == "VERIFICATION"
        assert step.operation == "VERIFY_RECORD_ABSENT"
        # COMPLETE verifications cite the proving evidence file.
        assert step.evidence_id == _FILE_ID

    def test_deletion_with_present_profile_is_incomplete(self):
        # A present USER_PROFILE under a DELETE rule => INCOMPLETE with a
        # finding citing the proving evidence.
        record = _profile_record(present=True, state_signal="FOUND")
        case = _case("I want to delete my account and all associated data.")
        result = pipeline.process_case(
            case, _store(), _rules(), [record], _FILE_CAPTURED_AT, _ENGINE
        )
        assert result.deletion_status == "INCOMPLETE"
        phases = [s.phase for s in result.steps]
        assert "FINDING" in phases
        finding = next(s for s in result.steps if s.phase == "FINDING")
        assert finding.operation == "REPORT_REMAINING_RECORD"
        assert finding.evidence_id == _FILE_ID
        # Remediation/verification for INCOMPLETE carry empty evidence_id.
        for s in result.steps:
            if s.phase in ("REMEDIATION", "VERIFICATION"):
                assert s.evidence_id == ""

    def test_unresolved_identity_is_not_applicable(self):
        record = _profile_record(present=True, state_signal="FOUND")
        case = Case(
            case_id="case_002",
            email="nobody@example.com",
            requested_at=datetime(2026, 4, 1, tzinfo=timezone.utc),
            reported_status="COMPLETE",
            reported_at=datetime(2026, 4, 2, tzinfo=timezone.utc),
            audit_at=_AUDIT_AT,
            request_text="Please delete all my data.",
        )
        result = pipeline.process_case(
            case, _store(), _rules(), [record], _FILE_CAPTURED_AT, _ENGINE
        )
        assert result.deletion_status == "NOT_APPLICABLE"
        assert result.steps == ()

    def test_file_captured_after_audit_at_is_gated_out(self):
        # The only record's source file was captured AFTER audit_at, so it must
        # not contribute: no located records => NOT_APPLICABLE (empty-decisions).
        record = _profile_record(present=True, state_signal="FOUND")
        late_captured = {_FILE_ID: datetime(2026, 7, 1, tzinfo=timezone.utc)}
        case = _case("Please delete my account and all data.")
        result = pipeline.process_case(
            case, _store(), _rules(), [record], late_captured, _ENGINE
        )
        assert result.deletion_status == "NOT_APPLICABLE"
        assert result.steps == ()


class TestSelectEngine:
    def test_default_is_deterministic(self):
        assert pipeline.select_engine({}) is intent.DEFAULT_ENGINE

    def test_explicit_deterministic(self):
        assert (
            pipeline.select_engine({"ENGINE": "deterministic"})
            is intent.DEFAULT_ENGINE
        )

    def test_llm_assisted_returns_deterministic_first_engine(self):
        # The optional LLM engine module now exists (task 16.3). Selecting it
        # returns an LLMEngine that is deterministic-first: with no SDK/
        # credentials it delegates to the deterministic lexicon engine and
        # makes zero model calls, so behaviour stays deterministic.
        engine = pipeline.select_engine({"ENGINE": "llm_assisted"})
        assert isinstance(engine, intent.Engine)
        # A clear deletion phrase classifies identically to deterministic.
        result = engine.classify("Please delete my account and all data.")
        assert result.is_deletion is True
