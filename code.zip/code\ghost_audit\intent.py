"""Deletion-intent classification (Requirement 1).

The Intent_Classifier decides, from ``request_text`` alone, whether a case
authorizes personal-data deletion. Non-deletion requests (access, correction,
export, marketing opt-out) are classified as non-authorizing so the Decision
Engine can short-circuit them to ``NOT_APPLICABLE`` with an empty plan
(Requirements 1.1, 1.2, 1.4).

Design (from design.md):

- A normalized, multilingual lexicon of deletion verbs/nouns (erase, delete,
  remove, "right to be forgotten", and localized equivalents).
- An exclusion lexicon for access/correction/export/opt-out intents.
- Language-agnostic normalization (casefold + strip accents) so the same
  criteria apply regardless of language (Requirement 1.3).

Why exclusion must dominate: real cases such as
``"...correct it without removing any of my records?"`` contain an incidental
deletion verb ("removing") yet are clearly *not* deletion requests. The
heuristic therefore treats a strong non-deletion intent (correction of a field,
export/download, access/login help, opt-out) combined with a "keep the account"
signal as decisive, overriding incidental deletion verbs.

An ``Engine`` abstraction keeps intent classification pluggable: the default
``DeterministicEngine`` performs lexicon matching with zero model calls, while a
later optional LLM engine (task 16.3) can implement the same interface for
genuinely ambiguous texts.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from .normalize import normalize_text

__all__ = [
    "IntentResult",
    "Engine",
    "DeterministicEngine",
    "classify_intent",
    "DEFAULT_ENGINE",
]


@dataclass(frozen=True)
class IntentResult:
    """The outcome of intent classification for one ``request_text``.

    ``is_deletion`` is the boolean contract consumed by the Decision Engine;
    ``reason`` is a short machine-readable tag explaining *why* the text was
    classified the way it was (useful for logging and explainability).
    """

    is_deletion: bool
    reason: str


# ---------------------------------------------------------------------------
# Lexicons
# ---------------------------------------------------------------------------
#
# All English/accented terms are matched against normalized text (casefold +
# strip accents). CJK terms (Japanese/Korean) are matched against the *original*
# text because casefold is a no-op for CJK and accent-stripping must not break
# the characters; substring containment is the right test there.

# Deletion-authorizing verbs/nouns across languages, stored normalized.
_DELETION_TERMS_LATIN: frozenset[str] = frozenset(
    {
        # English
        "delete",
        "deletion",
        "deleted",
        "erase",
        "erased",
        "erasure",
        "right to be forgotten",
        "account-deletion",
        "account deletion",
        # Portuguese
        "exclusao",  # exclusão -> accent stripped
        "excluir",
        "apagar",
        # Spanish
        "eliminacion",  # eliminación -> accent stripped
        "eliminar",
        "suprimir",
        "borrar",
        # French
        "suppression",
        "supprimer",
        "effacer",
    }
)

# CJK deletion terms matched against original (un-normalized) text.
_DELETION_TERMS_CJK: frozenset[str] = frozenset(
    {
        "削除",  # Japanese/Chinese "delete"
        "삭제",  # Korean "delete"
    }
)

# "remove" is a deletion verb in English but is weak: it appears in non-deletion
# corrections such as "without removing any of my records". It is treated as a
# deletion signal only when exclusion intent does not dominate.
_WEAK_DELETION_TERMS_LATIN: frozenset[str] = frozenset(
    {
        "remove",
        "removal",
    }
)

# Exclusion intents: access, correction, export/download, marketing opt-out.
# Stored normalized (Latin). Presence of any of these marks a non-deletion
# intent that (together with a keep-account signal) overrides incidental
# deletion verbs.
_EXCLUSION_TERMS_LATIN: frozenset[str] = frozenset(
    {
        # access / information requests
        "information request",
        "what personal information",
        "copy of the information",
        "tell me what personal information",
        "need help resetting",
        "resetting the login",
        "can't access",
        "cannot access",
        "cant access",
        # export / download / portability
        "download my account",
        "portable format",
        "copy of last year",
        "copy of the information",
        "invoices for my records",
        # correction / change a field
        "out of date",
        "replace it with the new",
        "is misspelled",
        "correct it",
        "change the email",
        "replace it",
        # marketing opt-out
        "stop the promotional",
        "remove me from marketing",
        "marketing lists only",
        "unsubscribe",
        "opt out",
        "opt-out",
    }
)

# "Keep the account" signals: strong indicators the user wants the account to
# stay, which pairs with exclusion intent to decisively reject deletion.
_KEEP_ACCOUNT_TERMS_LATIN: frozenset[str] = frozenset(
    {
        "leave the account active",
        "keep the account",
        "do not close the account",
        "dont close the account",
        "without removing any",
        "leave my profile",
        "still need the account",
        "still want receipts",
        "continue using the service",
        "not asking for deletion",
        "not a request to erase",
        "still use it",
        "don't delete or change",
        "dont delete or change",
        "in place",
    }
)


@runtime_checkable
class Engine(Protocol):
    """Pluggable intent-classification engine.

    Implementations take a ``request_text`` and return an :class:`IntentResult`.
    The deterministic engine does lexicon matching; a later LLM engine can
    implement the same contract for ambiguous texts (design.md, task 16.3).
    """

    def classify(self, request_text: str) -> IntentResult: ...


class DeterministicEngine:
    """Lexicon-based, zero-cost intent classifier (the default engine).

    Classification algorithm:

    1. Normalize the text (casefold + strip accents) for Latin-script matching;
       keep the original text for CJK substring matching.
    2. Detect exclusion intent (access/correction/export/opt-out) and a
       "keep the account" signal. If both are present, the request is a
       non-deletion request regardless of any incidental deletion verb.
    3. Otherwise, if any strong deletion term (or CJK deletion term) is present,
       classify as deletion-authorizing.
    4. Otherwise, fall back to the weak "remove" verb only when no exclusion
       intent is present.
    5. If nothing matches, classify as non-deletion with reason ``no_signal``.
    """

    def classify(self, request_text: str) -> IntentResult:
        original = request_text or ""
        norm = normalize_text(original)

        has_exclusion = any(term in norm for term in _EXCLUSION_TERMS_LATIN)
        has_keep_account = any(term in norm for term in _KEEP_ACCOUNT_TERMS_LATIN)

        strong_deletion = any(term in norm for term in _DELETION_TERMS_LATIN) or any(
            term in original for term in _DELETION_TERMS_CJK
        )
        weak_deletion = any(term in norm for term in _WEAK_DELETION_TERMS_LATIN)

        # Exclusion intent paired with a keep-account signal decisively wins,
        # overriding incidental deletion verbs (e.g. "without removing any").
        if has_exclusion and has_keep_account:
            return IntentResult(is_deletion=False, reason="exclusion_keep_account")

        # A strong, unambiguous deletion term authorizes deletion.
        if strong_deletion:
            return IntentResult(is_deletion=True, reason="deletion_term")

        # Exclusion intent without an explicit deletion term is non-deletion.
        if has_exclusion:
            return IntentResult(is_deletion=False, reason="exclusion_intent")

        # A keep-account signal with no deletion term is non-deletion.
        if has_keep_account:
            return IntentResult(is_deletion=False, reason="keep_account")

        # The weak "remove" verb counts only when no exclusion intent dominates.
        if weak_deletion:
            return IntentResult(is_deletion=True, reason="weak_deletion_term")

        return IntentResult(is_deletion=False, reason="no_signal")


# A shared default instance so callers can omit an explicit engine.
DEFAULT_ENGINE: Engine = DeterministicEngine()


def classify_intent(request_text: str, engine: Engine | None = None) -> IntentResult:
    """Classify whether ``request_text`` authorizes personal-data deletion.

    Delegates to ``engine`` (the deterministic lexicon engine by default). The
    same criteria apply to every language because the deterministic engine
    normalizes text before matching and keeps explicit CJK terms (Requirement
    1.3).
    """
    chosen = engine if engine is not None else DEFAULT_ENGINE
    return chosen.classify(request_text)
