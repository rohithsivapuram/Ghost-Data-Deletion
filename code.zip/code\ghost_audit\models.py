"""Core data models for the deletion-audit pipeline.

These frozen dataclasses mirror the "Data Models" section of design.md. They
are immutable (``frozen=True``) to keep pipeline state deterministic and
hashable where helpful.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

__all__ = [
    "ResourceKey",
    "Case",
    "ResolvedIdentity",
    "EvidenceFile",
    "ParsedRecord",
    "RecordState",
    "PolicyRule",
    "PolicyDecision",
    "Step",
    "CaseResult",
    "IdentitySnapshot",
    "AuditLogEntry",
    "IdentityStore",
    "ActivityRow",
]

# A relevant resource is uniquely identified by its (system_id, resource_id).
ResourceKey = tuple[str, str]


@dataclass(frozen=True)
class Case:
    """A single row of ``dataset/deletion_requests.csv``."""

    case_id: str
    email: str
    requested_at: datetime
    reported_status: str
    reported_at: datetime
    audit_at: datetime
    request_text: str


@dataclass(frozen=True)
class ResolvedIdentity:
    """The subject's stable ``user_id`` and all identifiers valid at audit_at.

    Identifier sets are stored normalized (casefolded, accent-stripped) so that
    evidence matching is a direct set membership test.
    """

    user_id: str
    emails: frozenset[str]
    email_hashes: frozenset[str]
    phones: frozenset[str]
    names: frozenset[str]


@dataclass(frozen=True)
class EvidenceFile:
    """One entry of the ``evidence_files.csv`` manifest."""

    file_id: str
    file_path: str
    origin: str
    captured_at: datetime


@dataclass(frozen=True)
class ParsedRecord:
    """A single fact extracted from an evidence file by a parser."""

    file_id: str
    system_id: str
    resource_id: str
    data_category: str | None
    observed_at: datetime
    present: bool
    identifiers: frozenset[str]  # normalized identifiers found in the record
    state_signal: str  # raw signal: FOUND/NOT_FOUND/IDENTIFIABLE/ANONYMIZED/ACTIVE/...
    raw: dict = field(default_factory=dict)


@dataclass(frozen=True)
class RecordState:
    """The reconstructed true state of a resource as of audit_at."""

    system_id: str
    resource_id: str
    data_category: str
    present: bool
    exposed_identifiers: frozenset[str]
    treatment: str  # NONE/REDACTED/ANONYMIZED/DELETED
    is_active_flow: bool
    is_restore_risk: bool
    proving_evidence_id: str  # file_id closest to and <= audit_at


@dataclass(frozen=True)
class PolicyRule:
    """One row of ``dataset/deletion_rules.csv``.

    Columns observed in the dataset are:
    ``rule_id,data_category,condition,required_action``.
    """

    rule_id: str
    data_category: str
    condition: str
    required_action: str  # DELETE/REDACT/ANONYMIZE/RETAIN


@dataclass(frozen=True)
class PolicyDecision:
    """The policy outcome for a single ``RecordState``."""

    state: RecordState
    required_action: str  # DELETE/REDACT/ANONYMIZE/RETAIN/DISABLE/BLOCK
    compliant: bool
    finding_op: str | None
    remediation_op: str | None
    verification_op: str


@dataclass(frozen=True)
class Step:
    """One element of a case's ``steps_json`` array."""

    step_no: int
    phase: str
    system_id: str
    resource_id: str
    operation: str
    state: str
    evidence_id: str


@dataclass(frozen=True)
class CaseResult:
    """The final result for a case, ready for serialization."""

    case_id: str
    deletion_status: str
    steps: tuple[Step, ...]


@dataclass(frozen=True)
class IdentitySnapshot:
    """One row of ``dataset/user_identities.csv`` (current identity snapshot)."""

    user_id: str
    name: str
    email: str
    phone: str
    email_hash: str
    updated_at: datetime


@dataclass(frozen=True)
class AuditLogEntry:
    """One row of ``dataset/user_audit_log.csv`` (historical identity change).

    ``old_value`` and ``new_value`` capture the before/after of a single
    ``field_name`` change (e.g. ``email``, ``phone``, ``name``, ``email_hash``)
    that occurred at ``event_time``.
    """

    audit_id: str
    user_id: str
    event_time: datetime
    field_name: str
    old_value: str
    new_value: str


@dataclass(frozen=True)
class IdentityStore:
    """The loaded identity dataset.

    Holds the current snapshot (``user_identities.csv`` rows) and the historical
    changes (``user_audit_log.csv`` rows). Identity resolution (implemented in a
    later task) consumes these typed structures to resolve a stable ``user_id``
    and to compile the identifier set valid at a case's ``audit_at``.
    """

    snapshots: tuple[IdentitySnapshot, ...]
    audit_log: tuple[AuditLogEntry, ...]


@dataclass(frozen=True)
class ActivityRow:
    """One row of ``dataset/system_activity.csv``.

    These rows are treated strictly as claims and never as proof of a record's
    state (Requirement 5.2); they mirror the CSV columns verbatim.
    """

    activity_id: str
    event_time: datetime
    event_type: str
    source_system: str
    target_system: str
    resource_id: str
    reported_result: str
    details: str
