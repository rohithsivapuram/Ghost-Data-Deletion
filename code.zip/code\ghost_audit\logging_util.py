"""Session logger for the deletion-audit agent (Requirements 19.1-19.5).

This module appends ``SESSION START`` and per-turn entries to ``log.txt`` at the
repository root, following the exact log format defined in ``AGENTS.md`` §5.

Guarantees
----------

- **Append-only** (Requirement 19.4): entries are only ever appended; prior
  entries are never rewritten, reordered, or deleted. The file is opened in
  append mode (``"a"``) and created if missing.
- **Encoding and line endings** (Requirement 19.5): the file is written in
  UTF-8 with ``newline="\\n"`` so line endings stay ``\\n`` on every platform.
- **Mandatory tool/model lines** (Requirement 19.3): every ``SESSION START``
  entry and every per-turn entry carries exactly one non-empty ``tool=`` line
  and one non-empty ``model=`` line. ``log_session_start`` and ``log_turn``
  reject blank ``tool``/``model`` values so a malformed entry is never written.
- **No secrets** (Requirement 19.5): :func:`redact_secrets` masks obvious secret
  values before the user prompt is written. It is intentionally conservative so
  normal prose is not over-redacted.

Timestamps
----------

Entry headers use an ISO-8601 UTC timestamp produced via ``strftime`` as e.g.
``2026-10-24T01:23:45Z``. Both log functions accept an optional ``now`` so tests
can pin a deterministic timestamp; by default they use the current UTC time.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

__all__ = [
    "TurnEntry",
    "redact_secrets",
    "format_timestamp",
    "log_session_start",
    "log_turn",
]


@dataclass(frozen=True)
class TurnEntry:
    """A single per-turn log entry (AGENTS.md §5.2).

    ``title`` is a short header title (kept to a line). ``user_prompt`` is the
    verbatim user message; :func:`log_turn` redacts secrets from it before
    writing. ``response_summary`` is a short summary of what the agent did.
    ``actions`` is a list of action lines (files edited / commands run / tools
    invoked). ``tool`` and ``model`` are the authoritative harness and model
    identifiers and must be non-empty.
    """

    title: str
    user_prompt: str
    response_summary: str
    actions: list[str]
    tool: str
    model: str
    branch: str = "unknown"
    worktree: str = "main"
    parent_agent: str = "none"


# --- timestamp helpers ------------------------------------------------------


def format_timestamp(now: datetime | None = None) -> str:
    """Return an ISO-8601 UTC timestamp like ``2026-10-24T01:23:45Z``.

    If ``now`` is ``None`` the current UTC time is used. A timezone-aware
    ``now`` is converted to UTC; a naive ``now`` is assumed to already be UTC.
    """
    if now is None:
        now = datetime.now(timezone.utc)
    elif now.tzinfo is not None:
        now = now.astimezone(timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%SZ")


# --- secret redaction -------------------------------------------------------

# Values that follow a secret-ish key (api_key, token, password, secret, ...).
# Matches ``key = value`` / ``key: value`` and masks the value portion.
_KV_SECRET_RE = re.compile(
    r"(?i)\b("
    r"api[_-]?key|apikey|access[_-]?key|secret[_-]?key|secret|token|"
    r"password|passwd|pwd|auth[_-]?token|client[_-]?secret|"
    r"private[_-]?key"
    r")\b(\s*[=:]\s*)(\"?)([^\s\"']+)(\"?)"
)

# Bearer tokens: ``Authorization: Bearer <token>`` or a bare ``Bearer <token>``.
_BEARER_RE = re.compile(r"(?i)\bbearer\b(\s+)(\S+)")

# Long opaque tokens (>=32 chars of base64/hex-looking text) that follow an
# ``=`` or ``:`` separator. Kept conservative so normal prose is untouched.
_LONG_TOKEN_RE = re.compile(r"([=:]\s*)([A-Za-z0-9+/._\-]{32,}=*)")

_REDACTED = "[REDACTED]"


def redact_secrets(text: str) -> str:
    """Mask obvious secret values in ``text`` with ``[REDACTED]``.

    Handles common key patterns (``api_key=``, ``token=``, ``password=``,
    ``secret=`` and variants), bearer tokens, and long base64/hex-looking
    tokens (>=32 chars) that follow an ``=`` or ``:``. The masking is
    conservative: it replaces only the secret value, keeping the surrounding
    key and punctuation so the log stays readable, and it does not touch
    ordinary prose (Requirement 19.5).
    """
    if not text:
        return text

    def _kv_sub(match: re.Match[str]) -> str:
        key, sep, open_q, _value, close_q = match.groups()
        return f"{key}{sep}{open_q}{_REDACTED}{close_q}"

    result = _KV_SECRET_RE.sub(_kv_sub, text)
    result = _BEARER_RE.sub(lambda m: f"Bearer{m.group(1)}{_REDACTED}", result)
    result = _LONG_TOKEN_RE.sub(lambda m: f"{m.group(1)}{_REDACTED}", result)
    return result


# --- log writing ------------------------------------------------------------


def _log_path(root: Path) -> Path:
    """Resolve ``log.txt`` relative to the repository root passed in."""
    return Path(root) / "log.txt"


def _append(root: Path, text: str) -> None:
    """Append ``text`` to ``log.txt`` as UTF-8 with ``\\n`` line endings.

    Opens the file in append mode so prior entries are never rewritten,
    reordered, or deleted (Requirement 19.4), creating it if missing
    (Requirement 19.1).
    """
    path = _log_path(root)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def _require_nonempty(name: str, value: str) -> str:
    """Return a stripped non-empty value or raise ``ValueError``.

    Enforces the mandatory ``tool=``/``model=`` rule (Requirement 19.3): an
    entry is invalid if either field is blank, so we fail fast rather than
    write a malformed entry.
    """
    if value is None or not str(value).strip():
        raise ValueError(f"{name} must be a non-empty value for the log entry")
    return str(value).strip()


def log_session_start(
    root: Path,
    tool: str,
    model: str,
    *,
    now: datetime | None = None,
    branch: str = "unknown",
    worktree: str = "main",
    parent_agent: str = "none",
    language: str = "py",
    time_remaining: str = "not configured",
) -> None:
    """Append a ``SESSION START`` entry to ``log.txt`` (AGENTS.md §5.1).

    The entry carries exactly one non-empty ``tool=`` line and one non-empty
    ``model=`` line (Requirement 19.3); blank values raise ``ValueError``. The
    file is created if missing and only appended to (Requirements 19.1, 19.4),
    written in UTF-8 with ``\\n`` line endings (Requirement 19.5).
    """
    tool = _require_nonempty("tool", tool)
    model = _require_nonempty("model", model)
    timestamp = format_timestamp(now)
    repo_root = str(Path(root))

    lines = [
        f"## [{timestamp}] SESSION START",
        "",
        f"tool={tool}",
        f"model={model}",
        f"Repo Root: {repo_root}",
        f"Branch: {branch}",
        f"Worktree: {worktree}",
        f"Parent Agent: {parent_agent}",
        f"Language: {language}",
        f"Time Remaining: {time_remaining}",
        "",
        "",
    ]
    _append(root, "\n".join(lines))


def log_turn(root: Path, entry: TurnEntry, *, now: datetime | None = None) -> None:
    """Append a per-turn entry to ``log.txt`` (AGENTS.md §5.2).

    The user prompt is passed through :func:`redact_secrets` so no secret value
    is ever written (Requirement 19.5). The entry's ``Context:`` block carries
    exactly one non-empty ``tool=`` line and one non-empty ``model=`` line
    (Requirement 19.3); blank values raise ``ValueError``. The entry is appended
    only (Requirement 19.4) as UTF-8 with ``\\n`` line endings (Requirement 19.5).
    """
    tool = _require_nonempty("tool", entry.tool)
    model = _require_nonempty("model", entry.model)
    timestamp = format_timestamp(now)
    redacted_prompt = redact_secrets(entry.user_prompt)

    action_lines = [f"* {action}" for action in entry.actions] or ["* (none)"]

    lines = [
        f"## [{timestamp}] {entry.title}",
        "",
        "User Prompt (verbatim, secrets redacted):",
        redacted_prompt,
        "",
        "Agent Response Summary:",
        entry.response_summary,
        "",
        "Actions:",
        *action_lines,
        "",
        "Context:",
        f"tool={tool}",
        f"model={model}",
        f"branch={entry.branch}",
        f"repo_root={str(Path(root))}",
        f"worktree={entry.worktree}",
        f"parent_agent={entry.parent_agent}",
        "",
        "",
    ]
    _append(root, "\n".join(lines))
