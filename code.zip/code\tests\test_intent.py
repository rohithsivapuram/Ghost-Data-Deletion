"""Unit tests for deletion-intent classification (Requirement 1).

Covers:
- deletion vs non-deletion phrasing (Requirement 1.2)
- multilingual deletion inputs classify as deletion (Requirement 1.3)
- access/correction/export/opt-out exclusions classify as non-deletion,
  including the tricky "without removing any records" case where an incidental
  deletion verb must be overridden (Requirements 1.2, 1.4)

Phrasings are grounded in real rows of ``dataset/deletion_requests.csv``.
"""

from ghost_audit.intent import (
    DeterministicEngine,
    Engine,
    IntentResult,
    classify_intent,
)


class TestEnglishDeletionPhrasing:
    def test_plain_delete(self):
        result = classify_intent(
            "Please close my account and process the associated personal-data deletion."
        )
        assert result.is_deletion is True

    def test_erase(self):
        result = classify_intent(
            "I would like the account associated with this address to be erased."
        )
        assert result.is_deletion is True

    def test_permanent_account_deletion(self):
        result = classify_intent(
            "Please process a permanent account-deletion request for this email address."
        )
        assert result.is_deletion is True

    def test_remove_my_account(self):
        result = classify_intent(
            "I am asking you to remove my account and the personal information linked to it."
        )
        assert result.is_deletion is True

    def test_permanently_deleted(self):
        result = classify_intent(
            "I no longer use this account and would like it permanently deleted."
        )
        assert result.is_deletion is True

    def test_right_to_be_forgotten(self):
        result = classify_intent(
            "I am invoking my right to be forgotten; please erase my data."
        )
        assert result.is_deletion is True


class TestMultilingualDeletion:
    """Requirement 1.3: same criteria applied across languages."""

    def test_portuguese(self):
        # case_54
        text = (
            "Solicito a exclusão permanente da conta associada a este e-mail. "
            "Verifiquem os identificadores atuais e anteriores conforme o processo."
        )
        assert classify_intent(text).is_deletion is True

    def test_spanish(self):
        # case_69
        text = (
            "Solicito la eliminación permanente de la cuenta asociada a este correo. "
            "Revisen los identificadores actuales y anteriores."
        )
        assert classify_intent(text).is_deletion is True

    def test_spanish_suprimir(self):
        text = "Por favor, deseo suprimir mi cuenta y todos mis datos personales."
        assert classify_intent(text).is_deletion is True

    def test_french(self):
        # case_84
        text = (
            "Je demande la suppression définitive du compte associé à cette adresse "
            "e-mail. Veuillez examiner les identifiants actuels et antérieurs."
        )
        assert classify_intent(text).is_deletion is True

    def test_french_supprimer(self):
        text = "Veuillez supprimer définitivement mon compte, s'il vous plaît."
        assert classify_intent(text).is_deletion is True

    def test_japanese(self):
        # case_78 / case_117
        text = (
            "このメールアドレスに関連するアカウントの完全な削除を依頼します。"
            "プライバシー手続きに従い、現在および過去の識別情報を確認してください。"
        )
        assert classify_intent(text).is_deletion is True

    def test_korean(self):
        # case_66 / case_105
        text = (
            "이 이메일 주소에 연결된 계정의 영구 삭제를 요청합니다. "
            "개인정보 처리 절차에 따라 현재 및 이전 식별자를 검토해 주세요."
        )
        assert classify_intent(text).is_deletion is True


class TestNonDeletionExclusions:
    """Requirements 1.2, 1.4: access/correction/export/opt-out are not deletion."""

    def test_correction_replace_mobile(self):
        # case_533
        text = (
            "The mobile number on my profile is out of date. Please replace it "
            "with the new one and leave the account active."
        )
        assert classify_intent(text).is_deletion is False

    def test_opt_out_promotional(self):
        # case_534
        text = (
            "Please stop the promotional emails. I still need the account and my "
            "order history, so I am not asking for deletion."
        )
        assert classify_intent(text).is_deletion is False

    def test_export_download_portable(self):
        # case_535
        text = (
            "I'd like to download my account information in a portable format. "
            "Please keep the account as it is."
        )
        assert classify_intent(text).is_deletion is False

    def test_access_reset_login(self):
        # case_536
        text = (
            "I can't access my profile and need help resetting the login. "
            "Do not close the account."
        )
        assert classify_intent(text).is_deletion is False

    def test_correction_without_removing_records(self):
        # case_537 - tricky: contains "removing" but is a correction request.
        text = (
            "My surname is misspelled on the account. Can you correct it without "
            "removing any of my records?"
        )
        result = classify_intent(text)
        assert result.is_deletion is False
        assert result.reason == "exclusion_keep_account"

    def test_marketing_opt_out_only(self):
        # case_538
        text = (
            "Please remove me from marketing lists only. I still want receipts "
            "and service messages for this account."
        )
        assert classify_intent(text).is_deletion is False

    def test_access_information_request_not_erase(self):
        # case_539 - contains "erase" but explicitly not a deletion request.
        text = (
            "Can you tell me what personal information you hold about me? This is "
            "an information request, not a request to erase it."
        )
        assert classify_intent(text).is_deletion is False

    def test_export_invoices_leave_profile(self):
        # case_540
        text = (
            "I need a copy of last year's invoices for my records. Please leave "
            "my profile and purchase history in place."
        )
        assert classify_intent(text).is_deletion is False

    def test_correction_change_email(self):
        # case_541
        text = (
            "Please change the email address used for this account. I want to "
            "continue using the service."
        )
        assert classify_intent(text).is_deletion is False

    def test_access_copy_dont_delete(self):
        # case_542 - contains "delete" but explicitly keep-account.
        text = (
            "Could you send me a copy of the information held on my account? I "
            "still use it, so please don't delete or change anything."
        )
        assert classify_intent(text).is_deletion is False


class TestIntentResultAndEngine:
    def test_returns_intent_result(self):
        result = classify_intent("Please delete my account.")
        assert isinstance(result, IntentResult)
        assert isinstance(result.is_deletion, bool)
        assert isinstance(result.reason, str)
        assert result.reason != ""

    def test_empty_text_is_non_deletion(self):
        assert classify_intent("").is_deletion is False
        assert classify_intent("").reason == "no_signal"

    def test_none_text_is_non_deletion(self):
        assert classify_intent(None).is_deletion is False

    def test_deterministic_engine_satisfies_protocol(self):
        engine = DeterministicEngine()
        assert isinstance(engine, Engine)

    def test_explicit_engine_delegation(self):
        engine = DeterministicEngine()
        result = classify_intent("Please erase my account.", engine)
        assert result.is_deletion is True

    def test_deletion_reason_tags(self):
        assert classify_intent("Please delete my account.").reason == "deletion_term"
        assert (
            classify_intent("Please remove the record I mentioned.").reason
            == "weak_deletion_term"
        )
