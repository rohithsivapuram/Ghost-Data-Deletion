"""Property-based tests for the state reconstructor.

These tests use Hypothesis to validate universal properties of
``code/ghost_audit/state.py`` across many generated inputs.

Properties covered:

- 8.2 No observation later than ``audit_at`` contributes to any
  :class:`RecordState` (**Validates: Requirement 5.3**).

The generator deliberately mixes records whose ``observed_at`` is before and
after ``audit_at`` so the time-gate is meaningfully exercised: some resources'
chosen records are eligible (``observed_at <= audit_at``) and some are not.
"""

from __future__ import annotations

from datetime import datetime, timezone

from hypothesis import given
from hypothesis import strategies as st

from ghost_audit.models import ParsedRecord, ResolvedIdentity
from ghost_audit.state import reconstruct_state

# Bounded datetime range (naive, then made tz-aware) so generated observation
# and cutoff times overlap enough to exercise the <= audit_at boundary.
_MIN_DT = datetime(2026, 1, 1)
_MAX_DT = datetime(2026, 12, 31, 23, 59, 59)


def _aware(dt: datetime) -> datetime:
    """Attach UTC so all comparisons are between tz-aware datetimes."""
    return dt.replace(tzinfo=timezone.utc)


_datetimes = st.datetimes(min_value=_MIN_DT, max_value=_MAX_DT).map(_aware)

# Small pools keep records clustered into a few ResourceKeys.
_system_ids = st.sampled_from(
    ["account_service", "integration_service", "backup_service", "support_platform"]
)
_resource_ids = st.sampled_from(["res_1", "res_2", "res_3"])
_signals = st.sampled_from(
    ["FOUND", "NOT_FOUND", "IDENTIFIABLE", "ANONYMIZED", "REDACTED", "ACTIVE", "DISABLED", "BLOCKED"]
)


@st.composite
def _parsed_records(draw) -> ParsedRecord:
    """Generate a ParsedRecord across a few ResourceKeys with varying times."""
    system_id = draw(_system_ids)
    resource_id = draw(_resource_ids)
    idx = draw(st.integers(min_value=0, max_value=1_000_000))
    return ParsedRecord(
        file_id=f"evidence_{idx}",
        system_id=system_id,
        resource_id=resource_id,
        data_category=None,
        observed_at=draw(_datetimes),
        present=draw(st.booleans()),
        identifiers=frozenset(),
        state_signal=draw(_signals),
    )


def _matched_dict(records):
    """Fold a list of records into a dict keyed by (system_id, resource_id).

    Mirrors the shape ``select_closest`` produces: one record per ResourceKey.
    The last record per key wins, which is irrelevant to the property under
    test (we assert against whatever record ends up in the dict).
    """
    matched = {}
    for r in records:
        matched[(r.system_id, r.resource_id)] = r
    return matched


_identity = ResolvedIdentity(
    user_id="user_1",
    emails=frozenset({"subject@example.com"}),
    email_hashes=frozenset(),
    phones=frozenset(),
    names=frozenset(),
)


class TestAuditAtStateGating:
    """Task 8.2 property test for :func:`reconstruct_state`."""

    @given(records=st.lists(_parsed_records(), max_size=30), audit_at=_datetimes)
    def test_no_observation_after_audit_at_contributes(self, records, audit_at):
        """Property: no observation later than audit_at contributes a RecordState.

        Validates: Requirement 5.3

        Every emitted ``RecordState`` must correspond to an input record whose
        ``observed_at <= audit_at``. We track ``(system_id, resource_id) ->
        observed_at`` from the matched input and assert that for every emitted
        state the backing record was eligible; records with ``observed_at >
        audit_at`` must be absent from the output.
        """
        matched = _matched_dict(records)
        observed_by_key = {
            key: rec.observed_at for key, rec in matched.items()
        }

        states = reconstruct_state(matched, _identity, audit_at)

        # Every emitted state is backed by an eligible (<= audit_at) record.
        for state in states:
            key = (state.system_id, state.resource_id)
            assert key in observed_by_key
            assert observed_by_key[key] <= audit_at

        # Any key whose matched record is after audit_at must not be emitted.
        emitted_keys = {(s.system_id, s.resource_id) for s in states}
        for key, observed_at in observed_by_key.items():
            if observed_at > audit_at:
                assert key not in emitted_keys
