"""Handover plain-text evidence parser (task 7.2).

The shift-handover file is a header block followed by fixed-shape bullet lines::

    - <timestamp> | <system_id> | <resource_id> | <DATA_CATEGORY> | <STATE> | <identifier>

Only lines beginning with ``- `` and containing the ``|`` field separator are
records; every other line (titles, blank lines, prose) is skipped. Each record
line is split into six fields and turned into a :class:`ParsedRecord` carrying
the raw ``STATE`` token as ``state_signal`` and the handover snapshot time as
``observed_at``.

Presence interpretation (grounded in the ``STATE`` tokens observed):

- ``NOT_FOUND`` => the resource is absent (``present=False``).
- ``FOUND`` / ``IDENTIFIABLE`` / ``ANONYMIZED`` / ``REDACTED`` / ``ACTIVE`` /
  ``BLOCKED`` / ``DISABLED`` => the resource exists in some form
  (``present=True``). ``ACTIVE``/``BLOCKED``/``DISABLED`` describe data flows
  and backups whose underlying resource still exists.

The identifier field is an email (any case), an opaque ``user_id`` such as
``user_39``, or the literal ``"no direct identifier"``. Emails are normalized
via :func:`ghost_audit.normalize.normalize_email`; opaque references are kept
verbatim; ``"no direct identifier"`` contributes nothing. Malformed lines are
skipped defensively so one bad line never aborts the file.
"""

from __future__ import annotations

from ..loaders import parse_timestamp
from ..models import ParsedRecord
from ._common import IdentifierCollector

__all__ = ["parse_handover_txt"]

# STATE tokens that mean the resource is absent. Everything else means present.
_ABSENT_STATES = {"NOT_FOUND"}

# The expected number of pipe-delimited fields on a record line.
_FIELD_COUNT = 6


def parse_handover_txt(text: str, file_id: str) -> list[ParsedRecord]:
    """Parse handover text into :class:`ParsedRecord`s.

    Args:
        text: Full UTF-8 contents of the handover ``.txt`` file.
        file_id: Manifest ``file_id`` to stamp on every extracted record.

    Returns:
        One :class:`ParsedRecord` per well-formed record line, in file order.
    """
    records: list[ParsedRecord] = []

    for line in text.splitlines():
        stripped = line.strip()
        # Record lines start with the bullet marker and contain the separator.
        if not stripped.startswith("-"):
            continue
        body = stripped[1:].strip()
        if "|" not in body:
            continue

        parts = [field.strip() for field in body.split("|")]
        if len(parts) != _FIELD_COUNT:
            # Unexpected shape; skip rather than crash (Requirement 4.5).
            continue

        ts, system_id, resource_id, data_category, state, identifier = parts
        if not system_id or not resource_id:
            continue

        try:
            observed_at = parse_timestamp(ts)
        except (ValueError, TypeError):
            # Unparseable timestamp -> skip the line defensively.
            continue

        state_signal = state.strip().upper()
        present = state_signal not in _ABSENT_STATES

        collector = IdentifierCollector()
        collector.add_token(identifier)

        records.append(
            ParsedRecord(
                file_id=file_id,
                system_id=system_id,
                resource_id=resource_id,
                data_category=data_category or None,
                observed_at=observed_at,
                present=present,
                identifiers=collector.frozen(),
                state_signal=state_signal,
                raw={
                    "identifier": identifier,
                    "data_category": data_category,
                    "state": state_signal,
                },
            )
        )

    return records
