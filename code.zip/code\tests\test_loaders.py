"""Unit tests for the input loaders.

These tests run against the real participant-facing dataset under ``dataset/``
(Requirements 11.2, 3.1). The repository root is resolved relative to this test
file: ``code/tests/test_loaders.py`` -> repo root is two parents up.
"""

from datetime import datetime, timezone
from pathlib import Path

from ghost_audit.loaders import (
    load_evidence_manifest,
    load_identities,
    load_requests,
    load_rules,
    load_system_activity,
    parse_timestamp,
)
from ghost_audit.models import (
    ActivityRow,
    Case,
    EvidenceFile,
    IdentityStore,
    PolicyRule,
)

# code/tests/test_loaders.py -> code/tests -> code -> repo root
REPO_ROOT = Path(__file__).resolve().parents[2]
DATASET = REPO_ROOT / "dataset"


def _is_aware(dt: datetime) -> bool:
    return dt.tzinfo is not None and dt.utcoffset() is not None


class TestParseTimestamp:
    def test_parses_z_suffix_as_utc(self):
        dt = parse_timestamp("2026-07-16T08:00:00Z")
        assert dt == datetime(2026, 7, 16, 8, 0, 0, tzinfo=timezone.utc)
        assert _is_aware(dt)

    def test_parses_explicit_offset(self):
        dt = parse_timestamp("2026-07-16T08:00:00+00:00")
        assert _is_aware(dt)
        assert dt.utcoffset() == timezone.utc.utcoffset(None)

    def test_naive_defaults_to_utc(self):
        dt = parse_timestamp("2026-07-16T08:00:00")
        assert _is_aware(dt)


class TestLoadRequests:
    def test_loads_518_cases(self):
        cases = load_requests(REPO_ROOT)
        assert len(cases) == 518

    def test_cases_have_expected_shape(self):
        cases = load_requests(REPO_ROOT)
        first = cases[0]
        assert isinstance(first, Case)
        assert first.case_id
        assert first.email
        assert first.request_text

    def test_case_timestamps_are_timezone_aware(self):
        cases = load_requests(REPO_ROOT)
        for case in cases:
            assert _is_aware(case.requested_at)
            assert _is_aware(case.reported_at)
            assert _is_aware(case.audit_at)

    def test_case_ids_are_unique(self):
        cases = load_requests(REPO_ROOT)
        ids = [c.case_id for c in cases]
        assert len(set(ids)) == len(ids)


class TestLoadRules:
    def test_returns_dict_keyed_by_data_category(self):
        rules = load_rules(REPO_ROOT)
        assert isinstance(rules, dict)
        for key, rule in rules.items():
            assert isinstance(rule, PolicyRule)
            assert rule.data_category == key

    def test_maps_every_data_category_row(self):
        # Every row in deletion_rules.csv must be represented. The dataset has
        # one rule per data_category, so the dict size equals the row count.
        import csv

        rules_path = DATASET / "deletion_rules.csv"
        with rules_path.open("r", encoding="utf-8-sig", newline="") as fh:
            rows = list(csv.DictReader(fh))
        categories = {row["data_category"] for row in rows}

        rules = load_rules(REPO_ROOT)
        assert set(rules.keys()) == categories
        assert len(rules) == len(rows)

    def test_known_categories_present(self):
        rules = load_rules(REPO_ROOT)
        assert "USER_PROFILE" in rules
        assert rules["USER_PROFILE"].required_action == "DELETE"
        assert rules["SECURITY_AUDIT_LOG"].required_action == "RETAIN"


class TestLoadEvidenceManifest:
    def test_maps_file_id_to_path_origin_captured_at(self):
        import csv

        manifest_path = DATASET / "evidence_files.csv"
        with manifest_path.open("r", encoding="utf-8-sig", newline="") as fh:
            rows = list(csv.DictReader(fh))
        expected = {row["file_id"]: row for row in rows}

        files = load_evidence_manifest(REPO_ROOT)
        assert len(files) == len(rows)

        by_id = {f.file_id: f for f in files}
        assert set(by_id.keys()) == set(expected.keys())

        for file_id, ev in by_id.items():
            assert isinstance(ev, EvidenceFile)
            raw = expected[file_id]
            # origin maps straight through
            assert ev.origin == raw["origin"]
            # file_path is resolved relative to dataset/ (OS-agnostic compare)
            assert Path(ev.file_path) == DATASET / Path(raw["file_path"])
            # captured_at parses to the same instant
            assert ev.captured_at == parse_timestamp(raw["captured_at"])

    def test_captured_at_is_timezone_aware(self):
        files = load_evidence_manifest(REPO_ROOT)
        assert files
        for ev in files:
            assert _is_aware(ev.captured_at)

    def test_resolved_path_is_under_dataset(self):
        files = load_evidence_manifest(REPO_ROOT)
        for ev in files:
            resolved = Path(ev.file_path)
            assert str(DATASET) in str(resolved)


class TestLoadIdentities:
    def test_returns_identity_store_with_rows(self):
        store = load_identities(REPO_ROOT)
        assert isinstance(store, IdentityStore)
        assert len(store.snapshots) > 0
        assert len(store.audit_log) > 0

    def test_snapshot_and_audit_timestamps_are_aware(self):
        store = load_identities(REPO_ROOT)
        for snap in store.snapshots:
            assert _is_aware(snap.updated_at)
        for entry in store.audit_log:
            assert _is_aware(entry.event_time)

    def test_snapshot_user_ids_are_unique(self):
        store = load_identities(REPO_ROOT)
        ids = [s.user_id for s in store.snapshots]
        assert len(set(ids)) == len(ids)


class TestLoadSystemActivity:
    def test_loads_activity_rows(self):
        rows = load_system_activity(REPO_ROOT)
        assert rows
        assert all(isinstance(r, ActivityRow) for r in rows)

    def test_activity_timestamps_are_aware(self):
        rows = load_system_activity(REPO_ROOT)
        for r in rows:
            assert _is_aware(r.event_time)
