"""Decision engine (Requirements 8.1-8.4).

The Decision_Engine assigns exactly one ``deletion_status`` to a case:
``COMPLETE``, ``INCOMPLETE``, or ``NOT_APPLICABLE``. It consumes three inputs:

- ``intent``: whether ``request_text`` authorizes personal-data deletion
  (from :mod:`ghost_audit.intent`).
- ``identity``: the resolved subject (or ``None`` when the case ``email``
  matched no subject, from :mod:`ghost_audit.identity`).
- ``decisions``: the per-record :class:`PolicyDecision` list produced by the
  Policy_Engine over the subject's reconstructed records.

Decision logic (design.md "Decision Engine" + "Error Handling"):

1. **Non-authorizing intent short-circuits.** If ``intent.is_deletion`` is
   False, the case does not authorize deletion, so the status is
   ``NOT_APPLICABLE`` regardless of any resolved identity or decisions
   (Requirements 8.3, 1.2). This is checked first.

2. **Authorizing request with no resolvable subject.** If the request is
   authorizing but ``identity is None`` (the case ``email`` matched no
   subject), there is nothing to audit -- no auditable records exist, so there
   is nothing to prove or remediate. Per the design Error Handling matrix this
   resolves to ``NOT_APPLICABLE`` rather than a silent ``INCOMPLETE``.

3. **Authorizing request with a resolved subject.** Compliance is read from the
   per-record policy decisions:

   - If **any** :class:`PolicyDecision` is non-compliant (``compliant`` is
     False), the deletion is ``INCOMPLETE`` (Requirement 8.2). Non-compliance
     already encodes every violation surface -- a remaining record, exposed
     prohibited PII, a missing required-retained record, an active data flow,
     and an unblocked restore each surface as ``compliant=False`` in their
     respective :class:`PolicyDecision`.
   - If **every** decision is compliant AND there is at least one decision, the
     deletion is ``COMPLETE`` (Requirement 8.1).
   - If there are **zero** decisions (no located records for a resolvable
     subject), see :data:`EMPTY_DECISIONS_STATUS` below.

Exactly one status is returned per case (Requirement 8.4).

Empty-decisions choice
----------------------

For an authorizing request with a resolved subject but **zero** policy
decisions (no located records), the design cautions that the absence of proof
should not fabricate a ``COMPLETE`` verdict: a ``COMPLETE`` case must cite
evidence that positively proves the required state at ``audit_at``, and there is
no such evidence here. Rather than assert compliant absence we cannot prove, we
default this case to ``NOT_APPLICABLE`` (nothing auditable was located).

This behavior is isolated in the module-level constant
:data:`EMPTY_DECISIONS_STATUS` so it can be tuned against the sample set in a
later task (task 18) without touching the core branching logic. The core
correctness properties are unaffected by this choice:

- non-authorizing intent => ``NOT_APPLICABLE``;
- any non-compliant decision => ``INCOMPLETE``;
- all decisions compliant (with at least one decision) => ``COMPLETE``.
"""

from __future__ import annotations

from .intent import IntentResult
from .models import PolicyDecision, ResolvedIdentity

__all__ = [
    "decide",
    "COMPLETE",
    "INCOMPLETE",
    "NOT_APPLICABLE",
    "EMPTY_DECISIONS_STATUS",
]

COMPLETE = "COMPLETE"
INCOMPLETE = "INCOMPLETE"
NOT_APPLICABLE = "NOT_APPLICABLE"

# Status for an authorizing request with a resolved subject but zero located
# records. The absence of positive proof keeps this out of COMPLETE; it is
# isolated here so task 18 can tune it against the sample set if needed.
EMPTY_DECISIONS_STATUS: str = NOT_APPLICABLE


def decide(
    identity: ResolvedIdentity | None,
    decisions: list[PolicyDecision],
    intent: IntentResult,
) -> str:
    """Return exactly one of ``COMPLETE`` / ``INCOMPLETE`` / ``NOT_APPLICABLE``.

    See the module docstring for the full decision matrix. The order of checks
    guarantees a single, deterministic status per case (Requirement 8.4).
    """
    # 1. Non-authorizing request short-circuits to NOT_APPLICABLE
    #    (Requirements 8.3, 1.2).
    if not intent.is_deletion:
        return NOT_APPLICABLE

    # 2. Authorizing request but no resolvable subject => nothing to audit
    #    (design Error Handling: NOT_APPLICABLE, not a silent INCOMPLETE).
    if identity is None:
        return NOT_APPLICABLE

    # 3. Authorizing request with a resolved subject.
    if not decisions:
        # No located records: absence of proof must not fabricate COMPLETE.
        return EMPTY_DECISIONS_STATUS

    # Any non-compliant record (remaining record, exposed PII, missing retained
    # record, active data flow, unblocked restore) => INCOMPLETE (Req 8.2).
    if any(not d.compliant for d in decisions):
        return INCOMPLETE

    # Every relevant copy carries its required treatment => COMPLETE (Req 8.1).
    return COMPLETE
