"""Shared helpers for the deterministic evidence parsers.

These helpers centralize two concerns that every parser needs:

1. **Identifier normalization** that matches the identity resolver exactly.
   Evidence matching is a set-membership test against the normalized identifier
   sets compiled by :mod:`ghost_audit.identity`, so parsers MUST normalize the
   identifiers they extract the same way the resolver does:

   - emails via :func:`ghost_audit.normalize.normalize_email` (accent-strip +
     casefold, whitespace removed),
   - ``email_hash`` values via strip + casefold,
   - phones via whitespace-strip only (kept verbatim otherwise),
   - names via :func:`ghost_audit.normalize.normalize_name`,
   - opaque references (``user_id``/``customer_reference``/``subject_reference``)
     kept verbatim (stripped) so a ``user_39`` reference matches as-is.

2. **Collection -> data_category mapping** shared by the JSON bundle parser and
   the SQL replica parser, which both describe records by a ``collection_name``.

Every ``add_*`` helper ignores empty / ``None`` / the literal strings ``"null"``
and ``"none"`` so that a JSON ``null`` serialized as text or an explicit null
column never becomes a spurious identifier.
"""

from __future__ import annotations

from ..normalize import normalize_email, normalize_name

__all__ = [
    "IdentifierCollector",
    "COLLECTION_CATEGORY",
    "is_nullish",
    "looks_like_email",
    "map_collection_category",
]

# Collection/table name -> policy data_category. Grounded in the real dataset
# (snapshot bundles, the ``*_read_replica`` ``collection_name`` column, and the
# SQL inventory tables). Unknown collections map to ``None`` so the state
# reconstructor can fall back to a system-based mapping.
COLLECTION_CATEGORY: dict[str, str] = {
    # Account profiles.
    "customer_profiles": "USER_PROFILE",
    # Search index documents.
    "customer_search_documents": "SEARCH_INDEX_ENTRY",
    # Analytics profiles/reports.
    "customer_analytics_reports": "ANALYTICS_PROFILE",
    "customer_analytics_profiles": "ANALYTICS_PROFILE",
    # Support conversations/messages.
    "support_conversations": "SUPPORT_MESSAGE",
    "support_records": "SUPPORT_MESSAGE",
    # Support attachments.
    "ticket_attachments": "SUPPORT_ATTACHMENT",
    # Export jobs.
    "customer_export_jobs": "USER_EXPORT",
    "customer_exports": "USER_EXPORT",
    # Integration connectors / data flows.
    "connector_configurations": "DATA_FLOW",
    "connector_subscriptions": "DATA_FLOW",
    # Backups.
    "backup_catalog": "BACKUP_ARCHIVE",
    "backup_restore_entries": "BACKUP_ARCHIVE",
    # Security audit log.
    "security_audit_events": "SECURITY_AUDIT_LOG",
    "security_audit_records": "SECURITY_AUDIT_LOG",
    # Account tombstones.
    "deleted_customer_references": "ACCOUNT_TOMBSTONE",
    # Legal holds.
    "retained_order_records": "LEGAL_HOLD_RECORD",
}

# Literal tokens that represent "no value" in the textual evidence formats.
_NULLISH = {"", "null", "none", "no direct identifier", "n/a", "nan"}


def is_nullish(value: object) -> bool:
    """Return ``True`` when ``value`` represents an absent identifier.

    Handles ``None``, empty/whitespace strings, and the literal placeholder
    tokens (``null``/``none``/``no direct identifier``) used across the logs,
    handover text, and JSON-as-text evidence.
    """
    if value is None:
        return True
    if isinstance(value, str):
        return value.strip().casefold() in _NULLISH
    return False


def looks_like_email(value: str) -> bool:
    """Heuristic: a token is an email when it contains ``@`` and a dot after it."""
    if not isinstance(value, str):
        return False
    at = value.find("@")
    return at > 0 and "." in value[at:]


def map_collection_category(collection: str | None) -> str | None:
    """Map a collection/table name to its policy ``data_category`` (or ``None``)."""
    if not collection:
        return None
    return COLLECTION_CATEGORY.get(collection.strip())


class IdentifierCollector:
    """Accumulates normalized identifiers for a single record.

    Call the ``add_*`` methods with raw values pulled from evidence; each method
    normalizes the value the same way the identity resolver does and skips
    nullish values. :meth:`frozen` returns the final ``frozenset`` to store on a
    :class:`~ghost_audit.models.ParsedRecord`.
    """

    def __init__(self) -> None:
        self._values: set[str] = set()

    def add_email(self, value: object) -> None:
        """Add an email, normalized via :func:`normalize_email`."""
        if is_nullish(value):
            return
        norm = normalize_email(str(value))
        if norm:
            self._values.add(norm)

    def add_hash(self, value: object) -> None:
        """Add an ``email_hash``, normalized by strip + casefold."""
        if is_nullish(value):
            return
        norm = str(value).strip().casefold()
        if norm:
            self._values.add(norm)

    def add_phone(self, value: object) -> None:
        """Add a phone number with surrounding whitespace stripped."""
        if is_nullish(value):
            return
        norm = str(value).strip()
        if norm:
            self._values.add(norm)

    def add_name(self, value: object) -> None:
        """Add a person's name, normalized via :func:`normalize_name`."""
        if is_nullish(value):
            return
        norm = normalize_name(str(value))
        if norm:
            self._values.add(norm)

    def add_reference(self, value: object) -> None:
        """Add an opaque reference (``user_id``/``customer_reference``) verbatim.

        References are kept as-is (only stripped) so a ``user_39`` subject
        reference matches the same token in the resolved identity. If the value
        happens to look like an email it is added in both raw-stripped and
        email-normalized forms for robustness.
        """
        if is_nullish(value):
            return
        text = str(value).strip()
        if not text:
            return
        if looks_like_email(text):
            self.add_email(text)
            return
        self._values.add(text)

    def add_token(self, value: object) -> None:
        """Add a free-form identifier token, auto-detecting emails.

        Used by the handover/log parsers where a single field may hold an email
        or an opaque reference. Emails are email-normalized; everything else is
        treated as an opaque reference.
        """
        if is_nullish(value):
            return
        text = str(value).strip()
        if not text:
            return
        if looks_like_email(text):
            self.add_email(text)
        else:
            self._values.add(text)

    def merge(self, other: "IdentifierCollector") -> None:
        """Merge already-normalized identifiers from another collector."""
        self._values.update(other._values)

    def frozen(self) -> frozenset[str]:
        """Return the accumulated identifiers as an immutable set."""
        return frozenset(self._values)
