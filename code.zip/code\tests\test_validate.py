"""Unit tests for the output validator (``code/ghost_audit/validate.py``).

These example-based tests confirm each contract violation is detected and
reported with the offending ``case_id`` (Requirement 12.8), that a fully valid
``output.csv`` yields no violations, and that ``compare_to_sample`` reports
status and step-array differences against the sample answers (Requirement 13.3).

The tests write small ``output.csv`` files to ``tmp_path`` directly with the
standard-library ``csv`` writer, and build minimal :class:`Case` fixtures (only
``case_id`` matters for validation; the remaining fields use dummy tz-aware
datetimes).
"""

from __future__ import annotations

import csv
from datetime import datetime, timezone

from ghost_audit.models import Case
from ghost_audit.validate import (
    Violation,
    compare_to_sample,
    load_output_rows,
    validate_output,
)

_DUMMY_DT = datetime(2026, 1, 1, tzinfo=timezone.utc)


def _case(case_id: str) -> Case:
    """Build a minimal :class:`Case`; only ``case_id`` matters for validation."""
    return Case(
        case_id=case_id,
        email="user@example.com",
        requested_at=_DUMMY_DT,
        reported_status="COMPLETE",
        reported_at=_DUMMY_DT,
        audit_at=_DUMMY_DT,
        request_text="please delete my data",
    )


def _write_output(tmp_path, rows, header=("case_id", "deletion_status", "steps_json")):
    """Write an ``output.csv`` to ``tmp_path`` with the given header and rows."""
    path = tmp_path / "output.csv"
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(header)
        writer.writerows(rows)
    return path


def _checks(violations: list[Violation]) -> set[str]:
    return {v.check for v in violations}


def _verification_step(step_no=1, evidence_id="evidence_1"):
    return {
        "step_no": step_no,
        "phase": "VERIFICATION",
        "system_id": "account_service",
        "resource_id": "account_001",
        "operation": "VERIFY_RECORD_ABSENT",
        "state": "ABSENT",
        "evidence_id": evidence_id,
    }


def _finding_step(step_no=1, evidence_id="evidence_1"):
    return {
        "step_no": step_no,
        "phase": "FINDING",
        "system_id": "account_service",
        "resource_id": "account_001",
        "operation": "REPORT_REMAINING_RECORD",
        "state": "PRESENT",
        "evidence_id": evidence_id,
    }


def _remediation_step(step_no=2, evidence_id=""):
    return {
        "step_no": step_no,
        "phase": "REMEDIATION",
        "system_id": "account_service",
        "resource_id": "account_001",
        "operation": "DELETE_RECORD",
        "state": "ABSENT",
        "evidence_id": evidence_id,
    }


def _json(steps):
    import json

    return json.dumps(steps)


class TestFullyValidOutput:
    def test_valid_output_returns_no_violations(self, tmp_path):
        """A contract-conforming output.csv yields an empty violation list."""
        rows = [
            ["case_01", "NOT_APPLICABLE", "[]"],
            ["case_02", "COMPLETE", _json([_verification_step()])],
            [
                "case_03",
                "INCOMPLETE",
                _json([_finding_step(1), _remediation_step(2)]),
            ],
        ]
        _write_output(tmp_path, rows)
        requests = [_case("case_01"), _case("case_02"), _case("case_03")]
        assert validate_output(tmp_path, requests) == []


class TestFileLevelViolations:
    def test_wrong_header_is_detected(self, tmp_path):
        rows = [["case_01", "NOT_APPLICABLE", "[]"]]
        _write_output(
            tmp_path, rows, header=("id", "status", "steps")
        )
        violations = validate_output(tmp_path, [_case("case_01")])
        assert "header" in _checks(violations)

    def test_wrong_row_count_is_detected(self, tmp_path):
        rows = [["case_01", "NOT_APPLICABLE", "[]"]]
        _write_output(tmp_path, rows)
        # Two requests but only one data row.
        violations = validate_output(tmp_path, [_case("case_01"), _case("case_02")])
        assert "row_count" in _checks(violations)


class TestCaseIdViolations:
    def test_duplicate_case_id_is_detected_and_reports_case_id(self, tmp_path):
        rows = [
            ["case_01", "NOT_APPLICABLE", "[]"],
            ["case_01", "NOT_APPLICABLE", "[]"],
        ]
        _write_output(tmp_path, rows)
        violations = validate_output(tmp_path, [_case("case_01"), _case("case_02")])
        dupes = [v for v in violations if v.check == "duplicate_case_id"]
        assert dupes and dupes[0].case_id == "case_01"

    def test_unknown_case_id_is_detected_and_reports_case_id(self, tmp_path):
        rows = [["case_99", "NOT_APPLICABLE", "[]"]]
        _write_output(tmp_path, rows)
        violations = validate_output(tmp_path, [_case("case_01")])
        unknown = [v for v in violations if v.check == "unknown_case_id"]
        assert unknown and unknown[0].case_id == "case_99"


class TestStatusViolations:
    def test_invalid_deletion_status_is_detected(self, tmp_path):
        rows = [["case_01", "MAYBE", "[]"]]
        _write_output(tmp_path, rows)
        violations = validate_output(tmp_path, [_case("case_01")])
        invalid = [v for v in violations if v.check == "invalid_status"]
        assert invalid and invalid[0].case_id == "case_01"


class TestStepNumberingViolations:
    def test_non_consecutive_step_no_is_detected(self, tmp_path):
        # step_no starts at 2 instead of 1.
        steps = [_finding_step(2), _remediation_step(3)]
        rows = [["case_01", "INCOMPLETE", _json(steps)]]
        _write_output(tmp_path, rows)
        violations = validate_output(tmp_path, [_case("case_01")])
        numbering = [v for v in violations if v.check == "step_numbering"]
        assert numbering and numbering[0].case_id == "case_01"

    def test_step_no_with_gap_is_detected(self, tmp_path):
        steps = [_finding_step(1), _remediation_step(3)]  # gap: 1 then 3
        rows = [["case_01", "INCOMPLETE", _json(steps)]]
        _write_output(tmp_path, rows)
        violations = validate_output(tmp_path, [_case("case_01")])
        assert "step_numbering" in _checks(violations)


class TestNotApplicableViolations:
    def test_not_applicable_with_nonempty_steps_is_detected(self, tmp_path):
        steps = [_verification_step()]
        rows = [["case_01", "NOT_APPLICABLE", _json(steps)]]
        _write_output(tmp_path, rows)
        violations = validate_output(tmp_path, [_case("case_01")])
        bad = [v for v in violations if v.check == "not_applicable_nonempty"]
        assert bad and bad[0].case_id == "case_01"


class TestCompleteViolations:
    def test_complete_with_non_verification_step_is_detected(self, tmp_path):
        # A FINDING step in a COMPLETE case is not allowed.
        steps = [_finding_step(1)]
        rows = [["case_01", "COMPLETE", _json(steps)]]
        _write_output(tmp_path, rows)
        violations = validate_output(tmp_path, [_case("case_01")])
        assert "complete_non_verification" in _checks(violations)

    def test_complete_with_empty_evidence_is_detected(self, tmp_path):
        steps = [_verification_step(evidence_id="")]
        rows = [["case_01", "COMPLETE", _json(steps)]]
        _write_output(tmp_path, rows)
        violations = validate_output(tmp_path, [_case("case_01")])
        empties = [v for v in violations if v.check == "complete_empty_evidence"]
        assert empties and empties[0].case_id == "case_01"


class TestIncompleteViolations:
    def test_incomplete_remediation_with_nonempty_evidence_is_detected(self, tmp_path):
        steps = [_finding_step(1), _remediation_step(2, evidence_id="evidence_x")]
        rows = [["case_01", "INCOMPLETE", _json(steps)]]
        _write_output(tmp_path, rows)
        violations = validate_output(tmp_path, [_case("case_01")])
        bad = [
            v for v in violations if v.check == "incomplete_future_nonempty_evidence"
        ]
        assert bad and bad[0].case_id == "case_01"

    def test_incomplete_verification_with_nonempty_evidence_is_detected(self, tmp_path):
        verification = _verification_step(step_no=2, evidence_id="evidence_x")
        steps = [_finding_step(1), verification]
        rows = [["case_01", "INCOMPLETE", _json(steps)]]
        _write_output(tmp_path, rows)
        violations = validate_output(tmp_path, [_case("case_01")])
        assert "incomplete_future_nonempty_evidence" in _checks(violations)

    def test_incomplete_finding_with_empty_evidence_is_detected(self, tmp_path):
        steps = [_finding_step(1, evidence_id=""), _remediation_step(2)]
        rows = [["case_01", "INCOMPLETE", _json(steps)]]
        _write_output(tmp_path, rows)
        violations = validate_output(tmp_path, [_case("case_01")])
        bad = [
            v for v in violations if v.check == "incomplete_finding_empty_evidence"
        ]
        assert bad and bad[0].case_id == "case_01"


class TestStepSchemaViolations:
    def test_step_missing_field_is_detected(self, tmp_path):
        step = _verification_step()
        del step["evidence_id"]  # drop a required field
        rows = [["case_01", "COMPLETE", _json([step])]]
        _write_output(tmp_path, rows)
        violations = validate_output(tmp_path, [_case("case_01")])
        assert "step_schema" in _checks(violations)


class TestCompareToSample:
    def test_identical_rows_all_match(self):
        steps = [_verification_step()]
        output = {"case_01": ("COMPLETE", steps), "case_02": ("NOT_APPLICABLE", [])}
        sample = {"case_01": ("COMPLETE", steps), "case_02": ("NOT_APPLICABLE", [])}
        report = compare_to_sample(output, sample)
        assert report.total == 2
        assert report.status_matches == 2
        assert report.status_mismatches == []
        assert report.step_mismatches == []

    def test_status_mismatch_is_reported(self):
        output = {"case_01": ("INCOMPLETE", [_verification_step()])}
        sample = {"case_01": ("COMPLETE", [_verification_step()])}
        report = compare_to_sample(output, sample)
        assert report.status_matches == 0
        assert report.status_mismatches == [("case_01", "COMPLETE", "INCOMPLETE")]

    def test_step_array_order_difference_is_reported(self):
        # Same two steps but in a different array order => step mismatch (Req 13.3).
        a = _finding_step(1)
        b = _finding_step(1)
        b["resource_id"] = "account_002"
        output = {"case_01": ("INCOMPLETE", [a, b])}
        sample = {"case_01": ("INCOMPLETE", [b, a])}
        report = compare_to_sample(output, sample)
        assert report.status_matches == 1
        assert report.step_mismatches == ["case_01"]

    def test_key_order_and_whitespace_irrelevant(self):
        # Reordering object keys does not count as a step difference (Req 13.3).
        ordered = {
            "step_no": 1,
            "phase": "VERIFICATION",
            "system_id": "account_service",
            "resource_id": "account_001",
            "operation": "VERIFY_RECORD_ABSENT",
            "state": "ABSENT",
            "evidence_id": "evidence_1",
        }
        reordered = {
            "evidence_id": "evidence_1",
            "state": "ABSENT",
            "operation": "VERIFY_RECORD_ABSENT",
            "resource_id": "account_001",
            "system_id": "account_service",
            "phase": "VERIFICATION",
            "step_no": 1,
        }
        output = {"case_01": ("COMPLETE", [ordered])}
        sample = {"case_01": ("COMPLETE", [reordered])}
        report = compare_to_sample(output, sample)
        assert report.step_mismatches == []


class TestLoadOutputRows:
    def test_round_trip_through_load_output_rows(self, tmp_path):
        steps = [_verification_step()]
        rows = [
            ["case_01", "COMPLETE", _json(steps)],
            ["case_02", "NOT_APPLICABLE", "[]"],
        ]
        _write_output(tmp_path, rows)
        loaded = load_output_rows(tmp_path / "output.csv")
        assert loaded["case_01"] == ("COMPLETE", steps)
        assert loaded["case_02"] == ("NOT_APPLICABLE", [])
