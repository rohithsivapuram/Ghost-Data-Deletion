"""Property-based tests for the evidence index / retriever.

These tests use Hypothesis to validate universal properties of
``code/ghost_audit/evidence.py`` across many generated inputs.

Properties covered:

- 5.2 No evidence with ``captured_at > audit_at`` is ever selected by
  :func:`eligible_files`, and no eligible file is dropped incorrectly
  (**Validates: Requirement 3.3**).
- 5.3 :func:`select_closest` returns, per ``ResourceKey``, the record with the
  greatest ``observed_at`` not after ``audit_at`` (**Validates: Requirements
  3.4, 5.5**).

Generators are deliberately simple: datetimes are drawn from a bounded range so
that collisions and ordering are meaningfully exercised, and ``system_id`` /
``resource_id`` are drawn from small pools so records cluster into a handful of
``ResourceKey`` groups.
"""

from __future__ import annotations

from datetime import datetime, timezone

from hypothesis import given
from hypothesis import strategies as st

from ghost_audit.evidence import eligible_files, select_closest
from ghost_audit.models import EvidenceFile, ParsedRecord

# Bounded datetime range (naive, then made tz-aware) so that generated capture
# and observation times overlap enough to exercise the <= audit_at boundary.
_MIN_DT = datetime(2026, 1, 1)
_MAX_DT = datetime(2026, 12, 31, 23, 59, 59)


def _aware(dt: datetime) -> datetime:
    """Attach UTC so all comparisons are between tz-aware datetimes."""
    return dt.replace(tzinfo=timezone.utc)


_datetimes = st.datetimes(min_value=_MIN_DT, max_value=_MAX_DT).map(_aware)

# Small pools keep records clustered into a few ResourceKeys.
_system_ids = st.sampled_from(["sys_a", "sys_b", "sys_c"])
_resource_ids = st.sampled_from(["res_1", "res_2", "res_3"])


@st.composite
def _evidence_files(draw) -> EvidenceFile:
    """Generate an EvidenceFile with a random captured_at."""
    captured_at = draw(_datetimes)
    idx = draw(st.integers(min_value=0, max_value=1_000_000))
    return EvidenceFile(
        file_id=f"evidence_{idx}",
        file_path=f"dataset/evidence/records/evidence_{idx}.json",
        origin="records",
        captured_at=captured_at,
    )


@st.composite
def _parsed_records(draw) -> ParsedRecord:
    """Generate a ParsedRecord across a few ResourceKeys with varying times.

    ``identifiers`` is an empty frozenset: subject matching is tested
    separately, and :func:`select_closest` operates purely on timestamps and
    the ``(system_id, resource_id)`` key.
    """
    observed_at = draw(_datetimes)
    system_id = draw(_system_ids)
    resource_id = draw(_resource_ids)
    idx = draw(st.integers(min_value=0, max_value=1_000_000))
    return ParsedRecord(
        file_id=f"evidence_{idx}",
        system_id=system_id,
        resource_id=resource_id,
        data_category="USER_PROFILE",
        observed_at=observed_at,
        present=draw(st.booleans()),
        identifiers=frozenset(),
        state_signal="FOUND",
    )


class TestEligibleFilesTimeGating:
    """Task 5.2 property test for :func:`eligible_files`."""

    @given(manifest=st.lists(_evidence_files(), max_size=20), audit_at=_datetimes)
    def test_no_file_after_audit_at_is_selected(self, manifest, audit_at):
        """Property: no evidence with captured_at > audit_at is ever selected.

        Validates: Requirement 3.3

        Every file returned by ``eligible_files`` has
        ``captured_at <= audit_at``, and the output is EXACTLY the set of files
        with ``captured_at <= audit_at`` (nothing eligible is dropped).
        """
        result = eligible_files(manifest, audit_at)

        # Nothing later than audit_at survives.
        assert all(f.captured_at <= audit_at for f in result)

        # Exactly the eligible files are returned, in original order.
        expected = [f for f in manifest if f.captured_at <= audit_at]
        assert result == expected


class TestSelectClosest:
    """Task 5.3 property test for :func:`select_closest`."""

    @given(records=st.lists(_parsed_records(), max_size=30), audit_at=_datetimes)
    def test_greatest_observed_at_not_after_audit_at_per_key(
        self, records, audit_at
    ):
        """Property: select_closest keeps the greatest observed_at <= audit_at per key.

        Validates: Requirements 3.4, 5.5

        For each key in the result the chosen record has the maximum
        ``observed_at`` among that key's records with ``observed_at <=
        audit_at``; and any key whose records are all after ``audit_at`` does
        not appear in the result.
        """
        result = select_closest(records, audit_at)

        # Recompute per-key eligible records (observed_at <= audit_at).
        by_key: dict[tuple[str, str], list[ParsedRecord]] = {}
        for r in records:
            if r.observed_at <= audit_at:
                by_key.setdefault((r.system_id, r.resource_id), []).append(r)

        # Keys with at least one eligible record appear exactly once.
        assert set(result.keys()) == set(by_key.keys())

        for key, chosen in result.items():
            eligible = by_key[key]
            max_observed = max(r.observed_at for r in eligible)
            # The chosen record is a genuine member of the group...
            assert chosen in eligible
            # ...carrying the greatest observed_at <= audit_at for that key.
            assert chosen.observed_at == max_observed
            assert chosen.observed_at <= audit_at

        # Keys whose records are all after audit_at never appear.
        all_keys = {(r.system_id, r.resource_id) for r in records}
        gated_out = all_keys - set(by_key.keys())
        for key in gated_out:
            assert key not in result
