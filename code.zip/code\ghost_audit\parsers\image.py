"""Optional image evidence parser (task 7.7).

Image evidence in this dataset consists of application screenshots (admin
consoles, analytics profile views, backup/restore consoles, object-storage
browsers, search-index inspectors, support-ticket consoles). The facts they
contain are pixels, not text, so recovering identifiers requires OCR or a
vision-capable LLM.

OCR / LLM extraction is the **optional** path and is wired through the Engine
abstraction (task 16.3), not implemented here. This module is the deterministic
default: with no OCR/LLM engine available it recovers no text and therefore
reports "no facts extracted" by returning ``[]`` (Requirements 4.3, 4.5). The
deterministic reconstruction pipeline does not depend on image evidence, so
returning no facts is acceptable and must never raise.

Design constraints mirror the PDF parser:

- **Zero required third-party dependencies.** No ``pytesseract``/``PIL`` import
  at module load; importing this module must always succeed so the dispatcher's
  ``from .image import parse_image`` resolves and image files stop appearing as
  parse failures.
- **Never raises.** Any failure degrades to ``[]``.
"""

from __future__ import annotations

from pathlib import Path

from ..models import ParsedRecord

__all__ = ["parse_image"]


def parse_image(path: Path, file_id: str) -> list[ParsedRecord]:
    """Parse an image into :class:`ParsedRecord`s (deterministic default).

    Without an OCR/LLM engine there is no dependency-free way to read text out
    of a screenshot, so this deterministic default returns ``[]`` ("no facts
    extracted"). The optional OCR/LLM extraction path is provided through the
    Engine abstraction (task 16.3); when that engine is available it, not this
    function, performs vision extraction.

    This function is deterministic and never raises; any error degrades to
    ``[]`` so the dispatcher treats an image as "no facts" rather than a parse
    failure (Requirements 4.3, 4.5).

    Args:
        path: Filesystem path to the image evidence file (unused on the
            deterministic default path; kept for signature parity with the
            other parsers and for the optional OCR/LLM wiring).
        file_id: Manifest ``file_id`` that would be stamped on any record.

    Returns:
        An empty list on the deterministic default path.
    """
    # Reference the arguments so the signature is explicit and future OCR/LLM
    # wiring has a clear seam; no deterministic facts are produced here.
    _ = (Path(path) if path is not None else None, file_id)
    return []
