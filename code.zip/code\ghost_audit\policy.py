"""Policy engine (Requirements 6.1-6.6).

Maps each :class:`RecordState` to the required treatment from
``deletion_rules.csv`` and decides whether the record is compliant at
``audit_at``, emitting the finding / remediation / verification operations for
the step plan.

The mapping follows the "Policy Engine" table in ``design.md``:

====================  ===============  ====================  =================  =======================
data_category         required_action  finding (if !ok)      remediation        verification
====================  ===============  ====================  =================  =======================
USER_PROFILE          DELETE           REPORT_REMAINING_...  DELETE_RECORD      VERIFY_RECORD_ABSENT
SECONDARY_IDENTIFIER  DELETE           REPORT_REMAINING_...  DELETE_RECORD      VERIFY_RECORD_ABSENT
SEARCH_INDEX_ENTRY    DELETE           REPORT_REMAINING_...  DELETE_RECORD      VERIFY_RECORD_ABSENT
CACHE_ENTRY           DELETE           REPORT_REMAINING_...  DELETE_RECORD      VERIFY_RECORD_ABSENT
USER_EXPORT           DELETE           REPORT_REMAINING_...  DELETE_RECORD      VERIFY_RECORD_ABSENT
MARKETING_PROFILE     DELETE           REPORT_REMAINING_...  DELETE_RECORD      VERIFY_RECORD_ABSENT
SUPPORT_ATTACHMENT    DELETE           REPORT_REMAINING_...  DELETE_RECORD      VERIFY_RECORD_ABSENT
SUPPORT_MESSAGE       REDACT           REPORT_EXPOSED_PII    REDACT_RECORD      VERIFY_RECORD_REDACTED
EMAIL_DELIVERY_LOG    REDACT           REPORT_EXPOSED_PII    REDACT_RECORD      VERIFY_RECORD_REDACTED
ACCOUNT_TOMBSTONE     REDACT           REPORT_EXPOSED_PII    REDACT_RECORD      VERIFY_RECORD_REDACTED
ANALYTICS_PROFILE     ANONYMIZE        REPORT_EXPOSED_PII    ANONYMIZE_RECORD   VERIFY_RECORD_ANONYMIZED
PRODUCT_TELEMETRY     ANONYMIZE        REPORT_EXPOSED_PII    ANONYMIZE_RECORD   VERIFY_RECORD_ANONYMIZED
SECURITY_AUDIT_LOG    RETAIN           (none; must stay)     (none)             VERIFY_RECORD_PRESENT
LEGAL_HOLD_RECORD     RETAIN           (none; must stay)     (none)             VERIFY_RECORD_PRESENT
BACKUP_ARCHIVE        RETAIN           REPORT_RESTORE_RISK   BLOCK_RESTORE      VERIFY_RESTORE_BLOCKED
DATA_FLOW (active)    DISABLE          REPORT_ACTIVE_...     DISABLE_DATA_FLOW  VERIFY_DATA_FLOW_DISABLED
====================  ===============  ====================  =================  =======================

Design contract for the returned :class:`PolicyDecision`:

- ``verification_op`` is ALWAYS set -- it is the check that proves the record's
  compliant final state (e.g. ``VERIFY_RECORD_ABSENT`` for a deleted profile,
  ``VERIFY_RECORD_PRESENT`` for a retained record).
- ``finding_op`` and ``remediation_op`` are populated ONLY when the record is
  NOT compliant; a compliant record emits ``None`` for both.
- ``RETAIN`` records are never assigned a delete/redact/anonymize remediation
  (Requirement 6.2); ``SECURITY_AUDIT_LOG``/``LEGAL_HOLD_RECORD`` never produce
  a removal op, and ``BACKUP_ARCHIVE`` is only ever blocked, never deleted.
"""

from __future__ import annotations

from .models import PolicyDecision, PolicyRule, RecordState

__all__ = ["apply_policy"]

# Data categories whose required_action resolves to each treatment, keyed by the
# value found in ``deletion_rules.csv``. The required_action column drives the
# op selection; the category is used for the special cases (tombstone, backup).
_DELETE_FINDING = "REPORT_REMAINING_RECORD"
_DELETE_REMEDIATION = "DELETE_RECORD"
_DELETE_VERIFY = "VERIFY_RECORD_ABSENT"

_REDACT_FINDING = "REPORT_EXPOSED_PII"
_REDACT_REMEDIATION = "REDACT_RECORD"
_REDACT_VERIFY = "VERIFY_RECORD_REDACTED"

_ANON_FINDING = "REPORT_EXPOSED_PII"
_ANON_REMEDIATION = "ANONYMIZE_RECORD"
_ANON_VERIFY = "VERIFY_RECORD_ANONYMIZED"

_RETAIN_VERIFY = "VERIFY_RECORD_PRESENT"

_RESTORE_FINDING = "REPORT_RESTORE_RISK"
_RESTORE_REMEDIATION = "BLOCK_RESTORE"
_RESTORE_VERIFY = "VERIFY_RESTORE_BLOCKED"

_FLOW_FINDING = "REPORT_ACTIVE_DATA_FLOW"
_FLOW_REMEDIATION = "DISABLE_DATA_FLOW"
_FLOW_VERIFY = "VERIFY_DATA_FLOW_DISABLED"


def _decision(
    state: RecordState,
    required_action: str,
    compliant: bool,
    finding_op: str | None,
    remediation_op: str | None,
    verification_op: str,
) -> PolicyDecision:
    """Build a :class:`PolicyDecision`, nulling finding/remediation when compliant.

    Per the design contract, a compliant record needs no finding or remediation,
    so those ops are forced to ``None`` regardless of the caller's intent, while
    ``verification_op`` is always retained as the check that proves the state.
    """
    if compliant:
        finding_op = None
        remediation_op = None
    return PolicyDecision(
        state=state,
        required_action=required_action,
        compliant=compliant,
        finding_op=finding_op,
        remediation_op=remediation_op,
        verification_op=verification_op,
    )


def apply_policy(state: RecordState, rules: dict[str, PolicyRule]) -> PolicyDecision:
    """Return the :class:`PolicyDecision` for a single :class:`RecordState`.

    ``rules`` maps ``data_category`` to its :class:`PolicyRule` (from
    ``deletion_rules.csv``). ``DATA_FLOW`` is synthetic and never present in
    ``rules``; it is handled specially below.
    """
    category = state.data_category

    # --- DATA_FLOW: synthetic category, not in deletion_rules.csv. ---------
    # A connector/data-flow resource that is still active can recreate data and
    # must be DISABLED (Requirement 6.4 recreation paths).
    if category == "DATA_FLOW" or state.is_active_flow:
        compliant = not state.is_active_flow
        return _decision(
            state,
            required_action="DISABLE",
            compliant=compliant,
            finding_op=_FLOW_FINDING,
            remediation_op=_FLOW_REMEDIATION,
            verification_op=_FLOW_VERIFY,
        )

    rule = rules.get(category)
    required_action = rule.required_action if rule is not None else ""

    # --- ACCOUNT_TOMBSTONE: REDACT but keep the stable user_id. ------------
    # ``state.exposed_identifiers`` already excludes the bare user_id, so a
    # correctly redacted tombstone (only user_id retained) reports no exposed
    # PII and is compliant; any remaining direct identifier is exposed PII
    # (Requirements 6.5, 6.6).
    if category == "ACCOUNT_TOMBSTONE":
        compliant = len(state.exposed_identifiers) == 0
        return _decision(
            state,
            required_action="REDACT",
            compliant=compliant,
            finding_op=_REDACT_FINDING,
            remediation_op=_REDACT_REMEDIATION,
            verification_op=_REDACT_VERIFY,
        )

    # --- BACKUP_ARCHIVE: RETAIN but block restore; never delete. -----------
    # An unblocked/active restore path is a recreation risk; a blocked backup is
    # compliant. The backup record is never DELETEd (Requirement 6.2).
    if category == "BACKUP_ARCHIVE":
        compliant = not state.is_restore_risk
        return _decision(
            state,
            required_action="RETAIN",
            compliant=compliant,
            finding_op=_RESTORE_FINDING,
            remediation_op=_RESTORE_REMEDIATION,
            verification_op=_RESTORE_VERIFY,
        )

    # --- RETAIN (SECURITY_AUDIT_LOG, LEGAL_HOLD_RECORD): never remove. -----
    # The record must stay present; compliance means the record is present as
    # required. No removal op is ever emitted (Requirement 6.2).
    if required_action == "RETAIN":
        compliant = state.present
        return _decision(
            state,
            required_action="RETAIN",
            compliant=compliant,
            finding_op=None,
            remediation_op=None,
            verification_op=_RETAIN_VERIFY,
        )

    # --- DELETE categories: compliant only when the record is absent. ------
    if required_action == "DELETE":
        compliant = not state.present
        return _decision(
            state,
            required_action="DELETE",
            compliant=compliant,
            finding_op=_DELETE_FINDING,
            remediation_op=_DELETE_REMEDIATION,
            verification_op=_DELETE_VERIFY,
        )

    # --- REDACT categories (SUPPORT_MESSAGE, EMAIL_DELIVERY_LOG). ----------
    # Compliant when the record is absent, or present with no exposed direct
    # identifiers and a REDACTED treatment. Non-compliant when any identifier is
    # still exposed, or the record is still identifiable (not redacted).
    if required_action == "REDACT":
        if not state.present:
            compliant = True
        else:
            compliant = (
                len(state.exposed_identifiers) == 0
                and state.treatment == "REDACTED"
            )
        return _decision(
            state,
            required_action="REDACT",
            compliant=compliant,
            finding_op=_REDACT_FINDING,
            remediation_op=_REDACT_REMEDIATION,
            verification_op=_REDACT_VERIFY,
        )

    # --- ANONYMIZE categories (ANALYTICS_PROFILE, PRODUCT_TELEMETRY). -------
    # Compliant when the record is absent, or present with no exposed direct
    # identifiers and an ANONYMIZED treatment.
    if required_action == "ANONYMIZE":
        if not state.present:
            compliant = True
        else:
            compliant = (
                len(state.exposed_identifiers) == 0
                and state.treatment == "ANONYMIZED"
            )
        return _decision(
            state,
            required_action="ANONYMIZE",
            compliant=compliant,
            finding_op=_ANON_FINDING,
            remediation_op=_ANON_REMEDIATION,
            verification_op=_ANON_VERIFY,
        )

    # --- Unknown category / no rule: treat as DELETE-style absence check. ---
    # Grounded categories always have a rule; this is a defensive default so a
    # record with an unmapped category still yields a deterministic decision
    # without inventing a removal op for data that may need to be retained.
    compliant = not state.present
    return _decision(
        state,
        required_action=required_action or "DELETE",
        compliant=compliant,
        finding_op=_DELETE_FINDING,
        remediation_op=_DELETE_REMEDIATION,
        verification_op=_DELETE_VERIFY,
    )
