"""Sample-set conformance harness (Requirements 13.1, 13.2, 13.3).

This module runs the full deterministic pipeline over the 32 public cases in
``dataset/sample_deletion_requests.csv`` and compares the result against the
supplied correct answers in ``dataset/sample_output.csv``. It is the format and
correctness check that confirms the agent matches a known reference before the
full 518-case run.

What it does
------------

:func:`run_sample` reuses :func:`ghost_audit.pipeline.run` with
``requests_filename="sample_deletion_requests.csv"`` so the exact same
load-identities / parse-evidence-once / state / policy / decision / steps path
is exercised (Requirement 13.1). Every one of the 32 sample cases is processed
and turned into the same ``{case_id: (deletion_status, steps_list)}`` shape used
by :func:`ghost_audit.validate.compare_to_sample`.

How it compares
---------------

:func:`compare_sample` loads ``sample_output.csv`` via
:func:`ghost_audit.validate.load_output_rows` and delegates to
:func:`ghost_audit.validate.compare_to_sample`, which treats JSON object-key
order and whitespace as equivalent while treating array order as significant
(Requirement 13.3). The returned :class:`SampleRunReport` carries the
case-level status matches/mismatches and the step-array differences, and
:func:`format_report` renders a human-readable summary reporting each violating
``case_id`` along with the specific status and step/field/sequence differences
(Requirement 13.2).

Determinism
-----------

The harness performs no I/O beyond reading participant-facing files under
``dataset/`` and makes zero model calls on the default deterministic engine, so
repeated sample runs produce identical reports.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from . import pipeline, serialize
from .intent import Engine
from .models import CaseResult
from .validate import SampleReport, compare_to_sample, load_output_rows

__all__ = [
    "SampleRunReport",
    "run_sample",
    "results_to_rows",
    "compare_sample",
    "format_report",
]

# The participant-facing sample files under ``dataset/`` (AGENTS.md §6.1).
SAMPLE_REQUESTS_FILENAME = "sample_deletion_requests.csv"
SAMPLE_OUTPUT_FILENAME = "sample_output.csv"


@dataclass(frozen=True)
class SampleRunReport:
    """The outcome of a sample-set conformance run (Requirements 13.2, 13.3).

    ``report`` is the underlying :class:`~ghost_audit.validate.SampleReport`
    produced by :func:`~ghost_audit.validate.compare_to_sample`.
    """

    report: SampleReport

    @property
    def passed(self) -> bool:
        """True when every sample case matches on both status and step array."""
        return (
            not self.report.status_mismatches and not self.report.step_mismatches
        )


def results_to_rows(
    results: dict[str, CaseResult],
) -> dict[str, tuple[str, list[dict]]]:
    """Convert pipeline results to the compare-to-sample row shape.

    Each :class:`CaseResult` is serialized through
    :func:`ghost_audit.serialize.steps_to_json` and re-parsed via
    :func:`ghost_audit.serialize.json_to_steps`, so the comparison runs on the
    exact canonical step objects that would be written to ``output.csv`` -- the
    same seven contract fields, with array order preserved (Requirement 13.3).
    """
    rows: dict[str, tuple[str, list[dict]]] = {}
    for case_id, result in results.items():
        steps_json = serialize.steps_to_json(list(result.steps))
        parsed = serialize.json_to_steps(steps_json)
        steps_list = [
            {
                "step_no": step.step_no,
                "phase": step.phase,
                "system_id": step.system_id,
                "resource_id": step.resource_id,
                "operation": step.operation,
                "state": step.state,
                "evidence_id": step.evidence_id,
            }
            for step in parsed
        ]
        rows[case_id] = (result.deletion_status, steps_list)
    return rows


def run_sample(
    root: Path, engine: Engine | None = None
) -> dict[str, tuple[str, list[dict]]]:
    """Run the pipeline over the 32 sample cases and return comparable rows.

    Delegates to :func:`ghost_audit.pipeline.run` with the sample request file
    so identity resolution, evidence parsing, state reconstruction, policy,
    decision, and step generation all follow the production path (Req 13.1).
    """
    results = pipeline.run(
        root,
        engine=engine,
        requests_filename=SAMPLE_REQUESTS_FILENAME,
    )
    return results_to_rows(results)


def compare_sample(root: Path, engine: Engine | None = None) -> SampleRunReport:
    """Run the sample set and compare it to ``sample_output.csv`` (Req 13.2, 13.3).

    Returns a :class:`SampleRunReport` wrapping the
    :class:`~ghost_audit.validate.SampleReport` of status and step-array
    differences keyed on the sample ``case_id`` set.
    """
    root = Path(root)
    output_rows = run_sample(root, engine=engine)
    sample_path = root / "dataset" / SAMPLE_OUTPUT_FILENAME
    sample_rows = load_output_rows(sample_path)
    report = compare_to_sample(output_rows, sample_rows)
    return SampleRunReport(report=report)


def format_report(run_report: SampleRunReport) -> str:
    """Render a human-readable summary of a sample conformance run.

    Reports the overall status-match count, then each violating ``case_id`` with
    its expected-vs-got status and any step-array (step/field/sequence)
    difference (Requirement 13.2).
    """
    report = run_report.report
    lines: list[str] = []
    lines.append("Sample-set conformance report")
    lines.append("=" * 29)
    lines.append(report.summary())

    if report.status_mismatches:
        lines.append("")
        lines.append("Status mismatches (case_id: expected -> got):")
        for case_id, expected, got in sorted(report.status_mismatches):
            lines.append(f"  - {case_id}: {expected} -> {got}")

    if report.step_mismatches:
        lines.append("")
        lines.append("Step-array mismatches (case_id):")
        for case_id in sorted(report.step_mismatches):
            lines.append(f"  - {case_id}")

    if run_report.passed:
        lines.append("")
        lines.append("All sample cases match on status and step arrays.")

    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    """CLI entry point: run the sample harness and print the report.

    Returns ``0`` when every sample case conforms, ``1`` otherwise, so it can be
    used as a conformance gate.
    """
    import argparse

    parser = argparse.ArgumentParser(
        prog="ghost-audit-sample",
        description="Run the sample set and compare to sample_output.csv.",
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parent.parent.parent,
        help="Repository root containing dataset/ (default: repo root).",
    )
    args = parser.parse_args(argv)

    run_report = compare_sample(Path(args.root).resolve())
    print(format_report(run_report))
    return 0 if run_report.passed else 1


if __name__ == "__main__":  # pragma: no cover - thin CLI wrapper
    raise SystemExit(main())
