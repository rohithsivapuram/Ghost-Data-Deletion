"""Tests for the sample-set conformance harness (Requirements 13.1, 13.2, 13.3).

These tests confirm the harness runs the pipeline over all 32 public sample
cases, produces one comparable row per case, and reports case-level status and
step-array (step/field/sequence) differences against ``sample_output.csv``.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from ghost_audit import sample_harness
from ghost_audit.validate import SampleReport, compare_to_sample

# Repository root = parent of the ``code/`` directory (two levels up from here).
_ROOT = Path(__file__).resolve().parent.parent.parent


def test_run_sample_covers_all_32_cases():
    """run_sample processes every public sample case (Requirement 13.1)."""
    rows = sample_harness.run_sample(_ROOT)
    assert len(rows) == 32
    for case_id, (status, steps) in rows.items():
        assert case_id.startswith("case_")
        assert status in {"COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"}
        assert isinstance(steps, list)


def test_run_sample_rows_have_contract_fields():
    """Each produced step carries exactly the seven contract fields."""
    rows = sample_harness.run_sample(_ROOT)
    contract_fields = {
        "step_no",
        "phase",
        "system_id",
        "resource_id",
        "operation",
        "state",
        "evidence_id",
    }
    for _status, steps in rows.values():
        for step in steps:
            assert set(step.keys()) == contract_fields


def test_compare_sample_returns_report_over_32_cases():
    """compare_sample compares against sample_output.csv for all 32 cases."""
    run_report = sample_harness.compare_sample(_ROOT)
    assert run_report.report.total == 32
    # status_matches + status_mismatches accounts for every sample case.
    accounted = run_report.report.status_matches + len(
        run_report.report.status_mismatches
    )
    assert accounted == 32


def test_run_sample_is_deterministic():
    """Two sample runs produce identical comparable rows (Requirement 16.1)."""
    first = sample_harness.run_sample(_ROOT)
    second = sample_harness.run_sample(_ROOT)
    assert first == second


def test_format_report_lists_differences():
    """format_report names each mismatching case_id (Requirement 13.2)."""
    report = SampleReport(
        total=2,
        status_matches=1,
        status_mismatches=[("case_99", "COMPLETE", "INCOMPLETE")],
        step_mismatches=["case_99"],
    )
    text = sample_harness.format_report(sample_harness.SampleRunReport(report))
    assert "case_99" in text
    assert "COMPLETE -> INCOMPLETE" in text
    assert "1/2 status matches" in text


def test_format_report_passed_message():
    """A fully matching report renders the all-match confirmation."""
    report = SampleReport(total=1, status_matches=1)
    run_report = sample_harness.SampleRunReport(report)
    assert run_report.passed is True
    assert "All sample cases match" in sample_harness.format_report(run_report)


def test_compare_to_sample_array_order_significant():
    """Array order is significant while key order/whitespace is not (Req 13.3)."""
    step_a = {
        "step_no": 1,
        "phase": "FINDING",
        "system_id": "s1",
        "resource_id": "r1",
        "operation": "REPORT_REMAINING_RECORD",
        "state": "PRESENT",
        "evidence_id": "e1",
    }
    step_b = {
        "step_no": 2,
        "phase": "FINDING",
        "system_id": "s2",
        "resource_id": "r2",
        "operation": "REPORT_REMAINING_RECORD",
        "state": "PRESENT",
        "evidence_id": "e2",
    }
    sample = {"case_x": ("INCOMPLETE", [step_a, step_b])}
    reordered = {"case_x": ("INCOMPLETE", [step_b, step_a])}
    report = compare_to_sample(reordered, sample)
    assert report.step_mismatches == ["case_x"]
