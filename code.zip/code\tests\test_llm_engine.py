"""Unit tests for the optional LLM-assisted intent engine (Requirements 4.3, 1.1).

These tests are strictly offline and deterministic: they never require a
network connection or any LLM SDK. They verify that in the default,
no-credentials environment the :class:`LLMEngine` behaves identically to the
deterministic lexicon engine and makes ZERO model calls (usage stays at zero).
"""

import os

from ghost_audit.engines.llm import LLMEngine, build_engine
from ghost_audit.intent import Engine, IntentResult
from ghost_audit.usage import UsageReporter


def _clear_credentials(monkeypatch):
    """Ensure no provider API keys are present in the environment."""
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)


class TestBuildEngine:
    def test_build_engine_returns_engine_protocol(self):
        engine = build_engine(provider="openai", model="gpt-4o-mini")
        # Satisfies the runtime_checkable Engine protocol via a classify method.
        assert isinstance(engine, Engine)
        assert hasattr(engine, "classify")

    def test_build_engine_returns_llm_engine(self):
        engine = build_engine(provider="anthropic", model="claude-3-5-sonnet")
        assert isinstance(engine, LLMEngine)


class TestNoCredentialsDeterministicDelegation:
    def test_clear_deletion_delegates_to_deterministic_zero_calls(self, monkeypatch):
        _clear_credentials(monkeypatch)
        usage = UsageReporter()
        engine = build_engine(
            provider="openai", model="gpt-4o-mini", usage=usage
        )

        result = engine.classify(
            "Please close my account and process the associated "
            "personal-data deletion."
        )

        # Delegates to the deterministic engine's confident result.
        assert isinstance(result, IntentResult)
        assert result.is_deletion is True
        # A clear deletion is never ambiguous, so no escalation is attempted
        # and no usage is recorded.
        assert usage.total_calls == 0
        assert usage.total_tokens == 0

    def test_ambiguous_no_signal_returns_deterministic_zero_calls(self, monkeypatch):
        _clear_credentials(monkeypatch)
        usage = UsageReporter()
        engine = build_engine(
            provider="openai", model="gpt-4o-mini", usage=usage
        )

        # Text with no deletion/exclusion/keep-account signal -> "no_signal".
        result = engine.classify("Hello, I have a question about my order status.")

        assert isinstance(result, IntentResult)
        assert result.is_deletion is False
        assert result.reason == "no_signal"
        # No SDK/credentials -> no model call even for the ambiguous case.
        assert usage.total_calls == 0
        assert usage.total_tokens == 0


class TestSafety:
    def test_classify_never_raises_with_unknown_provider(self, monkeypatch):
        _clear_credentials(monkeypatch)
        usage = UsageReporter()
        engine = LLMEngine(provider="mystery", model="x", usage=usage)

        # Unknown provider must still return a deterministic result, no calls.
        result = engine.classify("Hi there, just checking in.")
        assert result.is_deletion is False
        assert usage.total_calls == 0

    def test_present_key_but_no_sdk_falls_back(self, monkeypatch):
        # Even with a credential set, if the SDK is not installed the engine
        # must fall back to the deterministic result and record zero usage.
        # Use anthropic (not installed in this environment) so the no-SDK
        # branch is exercised deterministically and offline.
        monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-real-key")
        usage = UsageReporter()
        engine = LLMEngine(
            provider="anthropic", model="claude-3-5-sonnet", usage=usage
        )

        result = engine.classify("Hello, just a general question.")
        assert result.is_deletion is False
        assert result.reason == "no_signal"
        assert usage.total_calls == 0
