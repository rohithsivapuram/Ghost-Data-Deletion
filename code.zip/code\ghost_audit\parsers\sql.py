"""SQLite-compatible ``.sql`` snapshot parser (task 7.5).

Two grounded SQL shapes exist in the dataset, both loadable by executing the
dump into an in-memory SQLite database:

(1) **Inventory dumps** (``customer_data_inventory_*.sql``): typed per-category
    tables (``customer_profiles``, ``customer_search_documents``,
    ``customer_analytics_profiles``, ``support_records``, ``customer_exports``,
    ``connector_subscriptions``, ``backup_restore_entries``,
    ``security_audit_records``) plus a ``snapshot_scope`` table mapping each
    ``origin_system`` to its ``captured_at``. Each table maps to a fixed
    ``system_id`` / ``data_category``.

(2) **Replica dumps** (``*_read_replica``/``*_regional_replica``/
    ``*_reporting_replica``/``*_failover_replica``): a ``customer_data_primary``
    table and one replica table, both with columns ``resource_id``,
    ``origin_system``, ``collection_name``, ``record_json`` (a JSON string), and
    ``updated_at``. Each row's ``record_json`` is decoded to recover the inner
    record; ``collection_name`` maps to the ``data_category`` (same mapping as
    the JSON bundle parser), and the source table name is recorded in ``raw`` so
    replication drift between primary and replica can be analyzed downstream.

The dump is loaded with ``sqlite3.connect(":memory:")`` and
``con.executescript(...)``. A dump that cannot load at all raises, so the
dispatcher records a file-level parse failure; individual bad rows are caught
and skipped so one malformed row never aborts the whole file.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from ..loaders import parse_timestamp
from ..models import ParsedRecord
from ._common import IdentifierCollector, is_nullish, map_collection_category

__all__ = ["parse_sql_snapshot"]

# Replica/primary tables carrying ``record_json`` blobs.
_RECORD_JSON_TABLES_SUFFIX = ("_primary", "_replica")

# Inventory table -> (system_id, data_category). Grounded in the real dumps.
_INVENTORY_TABLES: dict[str, tuple[str, str]] = {
    "customer_profiles": ("account_service", "USER_PROFILE"),
    "customer_search_documents": ("search_service", "SEARCH_INDEX_ENTRY"),
    "customer_analytics_profiles": ("analytics_platform", "ANALYTICS_PROFILE"),
    "support_records": ("support_platform", "SUPPORT_MESSAGE"),
    "customer_exports": ("export_service", "USER_EXPORT"),
    "connector_subscriptions": ("integration_service", "DATA_FLOW"),
    "backup_restore_entries": ("backup_service", "BACKUP_ARCHIVE"),
    "security_audit_records": ("security_service", "SECURITY_AUDIT_LOG"),
}


def _list_tables(con: sqlite3.Connection) -> list[str]:
    """Return the names of all user tables in the database."""
    cur = con.execute("SELECT name FROM sqlite_master WHERE type='table'")
    return [row[0] for row in cur.fetchall()]


def _load_snapshot_scope(con: sqlite3.Connection, tables: list[str]) -> dict[str, Any]:
    """Build ``{origin_system: captured_at datetime}`` from ``snapshot_scope``."""
    scope: dict[str, Any] = {}
    if "snapshot_scope" not in tables:
        return scope
    for row in con.execute("SELECT origin_system, captured_at FROM snapshot_scope"):
        try:
            scope[row["origin_system"]] = parse_timestamp(str(row["captured_at"]))
        except (ValueError, TypeError):
            continue
    return scope


def _collect_row_identifiers(row: dict[str, Any]) -> IdentifierCollector:
    """Collect identifiers from an inventory row or decoded ``record_json``."""
    collector = IdentifierCollector()
    for key in ("email", "customer_email", "requester_email", "owner_email"):
        collector.add_email(row.get(key))
    for key in ("full_name", "display_name", "name", "requester_name"):
        collector.add_name(row.get(key))
    for key in ("phone", "customer_phone", "requester_phone", "owner_phone"):
        collector.add_phone(row.get(key))
    collector.add_hash(row.get("email_hash"))
    for key in (
        "customer_reference",
        "subject_reference",
        "user_id",
        "subject_selector",
        "uploaded_by",
    ):
        collector.add_reference(row.get(key))
    document = row.get("document")
    if isinstance(document, dict):
        collector.merge(_collect_row_identifiers(document))
    return collector


def _inventory_state(table: str, row: dict[str, Any]) -> str:
    """Derive the ``state_signal`` for an inventory-table row."""
    if table == "connector_subscriptions":
        return "ACTIVE" if _int_true(row.get("enabled")) else "DISABLED"
    if table == "backup_restore_entries":
        return "ACTIVE" if _int_true(row.get("restore_allowed")) else "BLOCKED"
    if table == "customer_analytics_profiles":
        exposed = any(
            not is_nullish(row.get(f)) for f in ("email", "phone", "email_hash")
        )
        return "IDENTIFIABLE" if exposed else "ANONYMIZED"
    return "FOUND"


def _int_true(value: Any) -> bool:
    """Interpret a SQLite INTEGER/bool flag as truthy."""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes"}
    return False


def _parse_inventory_table(
    con: sqlite3.Connection,
    table: str,
    system_id: str,
    category: str,
    scope: dict[str, Any],
    file_id: str,
) -> list[ParsedRecord]:
    """Parse one typed inventory table into records."""
    out: list[ParsedRecord] = []
    for raw_row in con.execute(f"SELECT * FROM '{table}'"):
        try:
            row = dict(raw_row)
            resource_id = row.get("resource_id")
            if not resource_id:
                continue
            updated_at = row.get("updated_at")
            observed_at = None
            if not is_nullish(updated_at):
                try:
                    observed_at = parse_timestamp(str(updated_at))
                except (ValueError, TypeError):
                    observed_at = None
            if observed_at is None:
                observed_at = scope.get(system_id)
            if observed_at is None:
                continue

            state_signal = _inventory_state(table, row)
            collector = _collect_row_identifiers(row)
            out.append(
                ParsedRecord(
                    file_id=file_id,
                    system_id=system_id,
                    resource_id=str(resource_id),
                    data_category=category,
                    observed_at=observed_at,
                    present=True,
                    identifiers=collector.frozen(),
                    state_signal=state_signal,
                    raw={"table": table, **row},
                )
            )
        except Exception:
            # Skip a single malformed row (Requirement 4.5), keep parsing.
            continue
    return out


def _replica_state(inner: dict[str, Any], collection: str | None) -> str:
    """Derive a ``state_signal`` from a decoded replica ``record_json`` record."""
    if collection in ("connector_configurations", "connector_subscriptions"):
        return "ACTIVE" if _int_true(inner.get("enabled")) else "DISABLED"
    if collection in ("backup_catalog", "backup_restore_entries"):
        return "ACTIVE" if _int_true(inner.get("restore_allowed")) else "BLOCKED"
    if collection in ("customer_analytics_reports", "customer_analytics_profiles"):
        exposed = any(
            not is_nullish(inner.get(f)) for f in ("email", "phone", "email_hash")
        )
        return "IDENTIFIABLE" if exposed else "ANONYMIZED"
    if collection == "deleted_customer_references":
        exposed = any(
            not is_nullish(inner.get(f))
            for f in ("name", "email", "phone", "email_hash")
        )
        return "IDENTIFIABLE" if exposed else "ANONYMIZED"
    return "FOUND"


def _parse_record_json_table(
    con: sqlite3.Connection, table: str, file_id: str
) -> list[ParsedRecord]:
    """Parse a ``customer_data_primary``/replica table carrying ``record_json``."""
    out: list[ParsedRecord] = []
    for raw_row in con.execute(f"SELECT * FROM '{table}'"):
        try:
            row = dict(raw_row)
            resource_id = row.get("resource_id")
            origin_system = row.get("origin_system")
            if not resource_id or not origin_system:
                continue
            try:
                inner = json.loads(row.get("record_json") or "{}")
            except (ValueError, TypeError):
                inner = {}
            if not isinstance(inner, dict):
                inner = {}

            collection = row.get("collection_name")
            category = map_collection_category(collection)
            try:
                observed_at = parse_timestamp(str(row.get("updated_at")))
            except (ValueError, TypeError):
                continue

            state_signal = _replica_state(inner, collection)
            collector = _collect_row_identifiers(inner)
            out.append(
                ParsedRecord(
                    file_id=file_id,
                    system_id=str(origin_system),
                    resource_id=str(resource_id),
                    data_category=category,
                    observed_at=observed_at,
                    present=True,
                    identifiers=collector.frozen(),
                    state_signal=state_signal,
                    raw={
                        "table": table,
                        "origin_system": origin_system,
                        "collection_name": collection,
                        "record": inner,
                    },
                )
            )
        except Exception:
            # Skip a single malformed row, keep parsing the rest.
            continue
    return out


def _is_record_json_table(con: sqlite3.Connection, table: str) -> bool:
    """Return ``True`` when ``table`` has a ``record_json`` column."""
    cols = {c[1] for c in con.execute(f"PRAGMA table_info('{table}')")}
    return "record_json" in cols and "origin_system" in cols


def parse_sql_snapshot(path: Path, file_id: str) -> list[ParsedRecord]:
    """Parse a ``.sql`` snapshot into :class:`ParsedRecord`s.

    Args:
        path: Filesystem path to the ``.sql`` dump.
        file_id: Manifest ``file_id`` to stamp on every extracted record.

    Returns:
        All records extracted from the recognized tables, in table order.

    Raises:
        Exception: If the dump cannot be loaded into SQLite at all; the
            dispatcher converts this into a recorded parse failure.
    """
    con = sqlite3.connect(":memory:")
    try:
        con.executescript(Path(path).read_text(encoding="utf-8"))
        con.row_factory = sqlite3.Row

        tables = _list_tables(con)
        scope = _load_snapshot_scope(con, tables)

        records: list[ParsedRecord] = []
        for table in tables:
            if table == "snapshot_scope":
                continue
            if table in _INVENTORY_TABLES:
                system_id, category = _INVENTORY_TABLES[table]
                records.extend(
                    _parse_inventory_table(
                        con, table, system_id, category, scope, file_id
                    )
                )
            elif _is_record_json_table(con, table):
                records.extend(_parse_record_json_table(con, table, file_id))
            # Unknown tables are ignored.
        return records
    finally:
        con.close()
