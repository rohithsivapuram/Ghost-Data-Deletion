"""Unit tests for the session logger and usage reporter.

Covers:

- ``log_session_start`` creates ``log.txt`` with a ``SESSION START`` entry
  containing non-empty ``tool=`` and ``model=`` lines (Requirements 19.1, 19.3).
- ``log_turn`` appends (does not truncate) a per-turn entry with ``tool=`` /
  ``model=`` (Requirements 19.2, 19.3, 19.4).
- ``redact_secrets`` masks an ``api_key=`` value and leaves prose alone
  (Requirement 19.5).
- ``UsageReporter.write_report`` with zero calls reports zero calls and
  ``$0.00`` (Requirement 18.1); with recorded calls it reports totals
  (Requirements 18.3-18.6).

Tests write to a ``tmp_path`` log file, never the real repo-root ``log.txt``.
"""

from __future__ import annotations

from datetime import datetime, timezone

from ghost_audit.logging_util import (
    TurnEntry,
    format_timestamp,
    log_session_start,
    log_turn,
    redact_secrets,
)
from ghost_audit.usage import UsageReporter

FIXED_NOW = datetime(2026, 10, 24, 1, 23, 45, tzinfo=timezone.utc)


def _read(path):
    return path.read_text(encoding="utf-8")


class TestSessionStart:
    def test_creates_log_with_session_start_and_tool_model(self, tmp_path):
        log_session_start(tmp_path, tool="kiro", model="test-model-1", now=FIXED_NOW)

        log_file = tmp_path / "log.txt"
        assert log_file.exists()
        content = _read(log_file)
        assert "## [2026-10-24T01:23:45Z] SESSION START" in content
        assert "tool=kiro" in content
        assert "model=test-model-1" in content
        # Exactly one non-empty tool= and model= line in the entry.
        assert content.count("tool=kiro") == 1
        assert content.count("model=test-model-1") == 1

    def test_blank_tool_or_model_raises(self, tmp_path):
        import pytest

        with pytest.raises(ValueError):
            log_session_start(tmp_path, tool="  ", model="m", now=FIXED_NOW)
        with pytest.raises(ValueError):
            log_session_start(tmp_path, tool="kiro", model="", now=FIXED_NOW)


class TestLogTurnAppends:
    def test_appends_without_truncating_prior_entry(self, tmp_path):
        log_session_start(tmp_path, tool="kiro", model="m1", now=FIXED_NOW)
        before = _read(tmp_path / "log.txt")

        entry = TurnEntry(
            title="Do a thing",
            user_prompt="please implement X",
            response_summary="Implemented X.",
            actions=["edited a.py", "ran pytest"],
            tool="kiro",
            model="m1",
        )
        log_turn(tmp_path, entry, now=FIXED_NOW)

        after = _read(tmp_path / "log.txt")
        # Append-only: the session-start text is still present at the start.
        assert after.startswith(before)
        assert "## [2026-10-24T01:23:45Z] Do a thing" in after
        assert "please implement X" in after
        assert "* edited a.py" in after
        assert "tool=kiro" in after
        assert "model=m1" in after

    def test_redacts_secret_in_user_prompt(self, tmp_path):
        entry = TurnEntry(
            title="secret turn",
            user_prompt="use api_key=sk-SUPERSECRETVALUE123 to call it",
            response_summary="noted",
            actions=[],
            tool="kiro",
            model="m1",
        )
        log_turn(tmp_path, entry, now=FIXED_NOW)
        content = _read(tmp_path / "log.txt")
        assert "sk-SUPERSECRETVALUE123" not in content
        assert "[REDACTED]" in content
        # Empty actions still produce a valid bullet line.
        assert "* (none)" in content


class TestRedactSecrets:
    def test_masks_api_key_value(self):
        out = redact_secrets("api_key=sk-abcdef123456")
        assert "sk-abcdef123456" not in out
        assert "[REDACTED]" in out
        assert out.startswith("api_key=")

    def test_masks_common_patterns(self):
        for text in [
            "token: abcdef1234567890",
            "password=hunter2",
            "secret = topsecretvalue",
            "Authorization: Bearer abc.def.ghi",
        ]:
            assert "[REDACTED]" in redact_secrets(text)

    def test_does_not_over_redact_prose(self):
        prose = "Please delete the user record and verify it is absent."
        assert redact_secrets(prose) == prose


class TestFormatTimestamp:
    def test_fixed_utc_timestamp(self):
        assert format_timestamp(FIXED_NOW) == "2026-10-24T01:23:45Z"


class TestUsageReporterZeroCalls:
    def test_zero_calls_reports_zero_and_zero_cost(self, tmp_path):
        reporter = UsageReporter()
        reporter.set_case_count(518)
        out = tmp_path / "usage_report.md"
        reporter.write_report(out)

        content = _read(out)
        assert "none (deterministic run)" in content
        assert "Model calls: 0" in content
        assert "Total tokens: 0" in content
        assert "$0.00" in content


class TestUsageReporterWithCalls:
    def test_reports_totals(self, tmp_path):
        reporter = UsageReporter(
            cost_per_1k={"gpt-x": (1.0, 2.0)}
        )
        reporter.set_case_count(2)
        reporter.record_call("openai", "gpt-x", in_tok=1000, out_tok=500)
        reporter.record_call("openai", "gpt-x", in_tok=1000, out_tok=500)

        assert reporter.total_calls == 2
        assert reporter.total_input_tokens == 2000
        assert reporter.total_output_tokens == 1000
        assert reporter.total_tokens == 3000
        # cost = 2000/1000*1.0 + 1000/1000*2.0 = 2.0 + 2.0 = 4.0
        assert abs(reporter.total_cost - 4.0) < 1e-9

        out = tmp_path / "usage_report.md"
        reporter.write_report(out)
        content = _read(out)
        assert "openai" in content
        assert "gpt-x" in content
        assert "Model calls: 2" in content
        assert "Total tokens: 3000" in content
        assert "$4.00" in content

    def test_multi_model_per_model_totals(self, tmp_path):
        reporter = UsageReporter()
        reporter.record_call("openai", "gpt-x", 100, 50)
        reporter.record_call("anthropic", "claude-y", 200, 100)
        out = tmp_path / "usage_report.md"
        reporter.write_report(out)
        content = _read(out)
        assert "Per-Model Totals" in content
        assert "gpt-x" in content
        assert "claude-y" in content
