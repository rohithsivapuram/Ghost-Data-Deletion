"""Unit tests for normalization helpers.

Covers casefold and accent-stripping for emails and names across languages
(Requirements 1.3, 2.4).
"""

from ghost_audit.normalize import (
    normalize_email,
    normalize_name,
    normalize_text,
    strip_accents,
)


class TestStripAccents:
    def test_strips_common_latin_accents(self):
        assert strip_accents("José") == "Jose"
        assert strip_accents("Müller") == "Muller"
        assert strip_accents("Renée") == "Renee"
        assert strip_accents("Łódź") == "Łodz"  # only combining marks removed

    def test_leaves_unaccented_text_unchanged(self):
        assert strip_accents("Alice") == "Alice"

    def test_handles_multiple_scripts(self):
        # Cyrillic/Greek characters have no decomposition to latin; left intact.
        assert strip_accents("Ångström") == "Angstrom"


class TestNormalizeText:
    def test_casefolds_and_strips_accents(self):
        assert normalize_text("José") == "jose"
        assert normalize_text("  MÜLLER  ") == "muller"

    def test_none_and_empty(self):
        assert normalize_text("") == ""
        assert normalize_text(None) == ""


class TestNormalizeEmail:
    def test_mixed_case_normalized_consistently(self):
        assert normalize_email("Alice@Example.COM") == "alice@example.com"
        assert normalize_email("ALICE@EXAMPLE.COM") == "alice@example.com"
        assert normalize_email("Alice@Example.COM") == normalize_email(
            "alice@example.com"
        )

    def test_accented_email_local_part(self):
        assert normalize_email("José@example.com") == "jose@example.com"

    def test_surrounding_and_interior_whitespace_removed(self):
        assert normalize_email("  alice @ example.com  ") == "alice@example.com"

    def test_none_and_empty(self):
        assert normalize_email("") == ""
        assert normalize_email(None) == ""


class TestNormalizeName:
    def test_accent_and_case_across_languages(self):
        assert normalize_name("José") == "jose"
        assert normalize_name("MÜLLER") == "muller"
        assert normalize_name("Renée García") == "renee garcia"

    def test_collapses_interior_whitespace(self):
        assert normalize_name("  José   Pérez ") == "jose perez"
        assert normalize_name("José Pérez") == normalize_name("  jose   perez ")

    def test_equivalence_of_accented_and_plain(self):
        assert normalize_name("José Pérez") == normalize_name("Jose Perez")

    def test_none_and_empty(self):
        assert normalize_name("") == ""
        assert normalize_name(None) == ""
