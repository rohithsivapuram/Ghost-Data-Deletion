"""Pipeline orchestrator (Requirements 8.4, 14.1, 15.1, 15.3, 15.4, 16.1).

This module wires the full deletion-audit pipeline together:

    loaders -> intent -> identity -> evidence -> parsers -> state -> policy
            -> decision -> steps -> (CaseResult for the serializer)

It exposes three entry points:

- :func:`process_case` audits a single :class:`Case` given the shared,
  pre-parsed evidence and returns one :class:`CaseResult`.
- :func:`run` loads every input, parses all evidence ONCE, and processes every
  case, returning ``{case_id: CaseResult}``.
- :func:`select_engine` chooses the intent engine from the environment,
  defaulting to the deterministic engine.

Performance / determinism
--------------------------

All 94 evidence files are parsed exactly once in :func:`run` via
:func:`ghost_audit.parsers.dispatch.parse_all`, producing a single master list
of :class:`ParsedRecord`. That master list is reused across all 518 cases,
which keeps the run fast and fully deterministic (Requirement 16.1): no case
re-reads a file off disk, and parse order is fixed by manifest order.

Two-level ``audit_at`` gating
-----------------------------

``audit_at`` gates evidence at two independent levels for every case:

1. **File-level** (Requirement 3.3): a record may only contribute if the
   ``captured_at`` of its *source evidence file* is at or before the case's
   ``audit_at``. :func:`run` builds a ``{file_id: captured_at}`` map from the
   manifest and :func:`process_case` filters the master record list by it first.
2. **Observation-level** (Requirements 3.4, 5.3, 5.5): among the file-eligible
   records, :func:`ghost_audit.evidence.select_closest` keeps, per resource, the
   observation with the greatest ``observed_at`` that is not after ``audit_at``.

Config / secrets
----------------

Engine selection and any LLM configuration are read ONLY from ``os.environ``
(Requirements 15.3, 15.4): ``ENGINE`` (default ``"deterministic"``),
``LLM_PROVIDER``, ``LLM_MODEL``. Secrets are never read from anywhere but the
environment, and :func:`select_engine` always falls back to the deterministic
engine (which makes zero model calls) on any problem.

Per-case isolation
-------------------

:func:`run` wraps each case in ``try/except`` so a single failing case defaults
to ``CaseResult(case_id, "NOT_APPLICABLE", ())`` and is logged, guaranteeing a
result for every case so the serializer always emits a full set of rows
(Requirements 11.2, 15.2).
"""

from __future__ import annotations

import logging
import os
from datetime import datetime
from pathlib import Path

from . import decision, intent, loaders
from .decision import decide
from .evidence import match_records_to_subject, select_closest
from .identity import resolve_identity
from .intent import Engine, classify_intent
from .models import Case, CaseResult, ParsedRecord, PolicyRule
from .parsers import dispatch
from .policy import apply_policy
from .state import reconstruct_state
from .steps import generate_steps
from .usage import UsageReporter

__all__ = ["process_case", "run", "select_engine"]

_LOG = logging.getLogger("ghost_audit.pipeline")

# Environment variable names (read from os.environ only; Requirements 15.3/15.4).
_ENV_ENGINE = "ENGINE"
_ENV_LLM_PROVIDER = "LLM_PROVIDER"
_ENV_LLM_MODEL = "LLM_MODEL"


def select_engine(env: dict[str, str] = os.environ) -> Engine:
    """Return the intent :class:`Engine` chosen from the environment.

    The deterministic engine (``intent.DEFAULT_ENGINE``) is the default and the
    only one required; it makes zero model calls. Only when ``ENGINE`` is set to
    ``"llm_assisted"`` AND an optional LLM engine is importable is an LLM engine
    constructed from ``LLM_PROVIDER``/``LLM_MODEL``. On any problem -- unset or
    unknown ``ENGINE``, a missing optional module, or a construction error -- we
    fall back to the deterministic engine so a run never breaks on config
    (Requirements 15.3, 15.4).
    """
    engine_name = (env.get(_ENV_ENGINE) or "deterministic").strip().lower()
    if engine_name != "llm_assisted":
        return intent.DEFAULT_ENGINE

    # Optional LLM engine: import lazily and tolerate any failure.
    try:  # pragma: no cover - optional path, deterministic is the default
        from .engines.llm import build_engine  # type: ignore[import-not-found]

        provider = (env.get(_ENV_LLM_PROVIDER) or "").strip()
        model = (env.get(_ENV_LLM_MODEL) or "").strip()
        return build_engine(provider=provider, model=model)
    except Exception as exc:  # pragma: no cover - defensive fallback
        _LOG.warning(
            "LLM engine unavailable (%s); falling back to deterministic engine",
            exc,
        )
        return intent.DEFAULT_ENGINE


def _file_eligible_records(
    all_records: list[ParsedRecord],
    file_captured_at: dict[str, datetime],
    audit_at: datetime,
) -> list[ParsedRecord]:
    """Keep records whose source file's ``captured_at`` is ``<= audit_at``.

    This is the file-level ``audit_at`` gate (Requirement 3.3): a record is
    only admissible when the evidence file it came from was captured at or
    before the case cutoff. A record whose ``file_id`` is absent from the
    manifest map is conservatively excluded.
    """
    kept: list[ParsedRecord] = []
    for record in all_records:
        captured_at = file_captured_at.get(record.file_id)
        if captured_at is not None and captured_at <= audit_at:
            kept.append(record)
    return kept


def process_case(
    case: Case,
    store,
    rules: dict[str, PolicyRule],
    all_records: list[ParsedRecord],
    file_captured_at: dict[str, datetime],
    engine: Engine,
    usage: UsageReporter | None = None,
) -> CaseResult:
    """Audit a single :class:`Case` and return its :class:`CaseResult`.

    Steps (design "Pipeline Flow"):

    1. Classify intent from ``request_text``; a non-deletion request is
       ``NOT_APPLICABLE`` with an empty plan (Requirements 1.2, 8.3).
    2. Resolve the subject identity; an unresolved subject yields
       ``NOT_APPLICABLE`` via the decision engine (design Error Handling).
    3. File-level ``audit_at`` gate (Requirement 3.3).
    4. Match the subject's records by exact normalized identifier (Req 3.5).
    5. Select the closest observation per resource not after ``audit_at``
       (Requirements 3.4, 5.5).
    6. Reconstruct per-resource :class:`RecordState` at ``audit_at``.
    7. Apply policy to each state.
    8. Decide the single ``deletion_status`` (Requirement 8.4).
    9. Generate the ordered step plan for that status.

    ``usage`` is accepted for parity with the LLM-assisted path; the
    deterministic engine records no calls.
    """
    # 1. Intent: short-circuit non-deletion requests to NOT_APPLICABLE.
    intent_result = classify_intent(case.request_text, engine)
    if not intent_result.is_deletion:
        return CaseResult(case.case_id, decision.NOT_APPLICABLE, ())

    # 2. Identity: an unresolved subject has nothing auditable.
    identity = resolve_identity(case, store)
    if identity is None:
        status = decide(None, [], intent_result)
        return CaseResult(case.case_id, status, ())

    # 3. File-level audit_at gate (Requirement 3.3).
    eligible = _file_eligible_records(all_records, file_captured_at, case.audit_at)

    # 4. Subject matching by exact normalized identifier (Requirement 3.5).
    matched_records = match_records_to_subject(eligible, identity)

    # 5. Closest observation per resource not after audit_at (Req 3.4, 5.5).
    closest = select_closest(matched_records, case.audit_at)

    # 6. Reconstruct state at audit_at.
    states = reconstruct_state(closest, identity, case.audit_at)

    # 7. Apply policy per state.
    decisions = [apply_policy(state, rules) for state in states]

    # 8. Single deletion_status (Requirement 8.4).
    status = decide(identity, decisions, intent_result)

    # 9. Ordered step plan.
    steps = generate_steps(status, decisions)

    return CaseResult(case.case_id, status, tuple(steps))


def run(
    root: Path,
    engine: Engine | None = None,
    usage: UsageReporter | None = None,
    requests_filename: str = "deletion_requests.csv",
) -> dict[str, CaseResult]:
    """Run the full pipeline over every case under ``root`` and return results.

    Loads all inputs, parses all evidence ONCE (Requirement 16.1), then
    processes every case, returning ``{case_id: CaseResult}``. The deterministic
    engine is used by default (Requirement 15.4). Each case is isolated in a
    ``try/except`` so a single failing case defaults to
    ``NOT_APPLICABLE`` / ``()`` and is logged, guaranteeing a result for every
    case (Requirements 11.2, 15.2).

    ``requests_filename`` selects which participant-facing request file under
    ``dataset/`` to audit; it defaults to the full ``deletion_requests.csv`` but
    the sample-set harness passes ``sample_deletion_requests.csv`` so the same
    load-identities / parse-evidence-once path is reused (Requirement 13.1).
    """
    root = Path(root)
    chosen_engine = engine if engine is not None else select_engine()

    # 1. Load inputs. system_activity is loaded for completeness but is only a
    #    set of claims and is never used as proof (Requirement 5.2).
    cases = loaders.load_requests(root, requests_filename)
    store = loaders.load_identities(root)
    rules = loaders.load_rules(root)
    manifest = loaders.load_evidence_manifest(root)
    loaders.load_system_activity(root)

    # 2. Parse ALL evidence once; keep the master record list and failures.
    all_records, failures = dispatch.parse_all(manifest)
    if failures:
        for file_id, error in failures.items():
            _LOG.warning("evidence parse failure for %s: %s", file_id, error)

    # 3. Build the file-level captured_at map for the Requirement 3.3 gate.
    file_captured_at: dict[str, datetime] = {
        evidence_file.file_id: evidence_file.captured_at for evidence_file in manifest
    }

    # 4. Process every case, isolating failures to a safe default.
    results: dict[str, CaseResult] = {}
    for case in cases:
        try:
            results[case.case_id] = process_case(
                case,
                store,
                rules,
                all_records,
                file_captured_at,
                chosen_engine,
                usage,
            )
        except Exception as exc:  # defensive: guarantee a row for every case
            _LOG.exception("case %s failed: %s", case.case_id, exc)
            results[case.case_id] = CaseResult(
                case.case_id, decision.NOT_APPLICABLE, ()
            )

    return results
