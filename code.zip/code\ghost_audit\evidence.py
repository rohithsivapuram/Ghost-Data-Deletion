"""Evidence index / retriever (Requirements 3.2-3.5, 5.5).

This module connects parsed evidence to a resolved subject and gates it against
the case's ``audit_at`` cutoff. It provides three pure functions used by the
pipeline:

- :func:`eligible_files` drops any manifest file captured after ``audit_at``
  (Requirement 3.3).
- :func:`match_records_to_subject` keeps only records that share at least one
  exact, normalized identifier with the subject (Requirement 3.5). Matching is
  exact normalized equality only; a near-but-not-equal identifier is excluded.
- :func:`select_closest` groups matched records by ``ResourceKey`` and keeps,
  per key, the observation with the greatest ``observed_at`` that is not after
  ``audit_at`` (Requirements 3.4, 5.5).

All functions are pure and side-effect free so the pipeline stays deterministic
(Requirement 16.1). ``ParsedRecord.identifiers`` are already normalized by the
parsers, and ``ResolvedIdentity`` identifier sets are normalized by the identity
resolver, so matching reduces to a direct set-membership test.
"""

from __future__ import annotations

from datetime import datetime

from .models import (
    EvidenceFile,
    ParsedRecord,
    ResolvedIdentity,
    ResourceKey,
)

__all__ = [
    "eligible_files",
    "match_records_to_subject",
    "select_closest",
]


def eligible_files(
    manifest: list[EvidenceFile], audit_at: datetime
) -> list[EvidenceFile]:
    """Return the manifest files eligible for a case at ``audit_at``.

    Any file whose ``captured_at`` is strictly after ``audit_at`` is dropped so
    that evidence created later than the cutoff cannot influence the decision
    (Requirement 3.3). Relative order of the surviving files is preserved.
    """
    return [f for f in manifest if f.captured_at <= audit_at]


def _subject_identifiers(identity: ResolvedIdentity) -> frozenset[str]:
    """Build the full set of normalized identifiers for a subject.

    Combines emails, email hashes, phones, and names with the stable
    ``user_id``. These are the values any evidence record must share (exactly,
    after normalization) to be attributed to the subject.
    """
    return (
        identity.emails
        | identity.email_hashes
        | identity.phones
        | identity.names
        | {identity.user_id}
    )


def match_records_to_subject(
    records: list[ParsedRecord], identity: ResolvedIdentity
) -> list[ParsedRecord]:
    """Keep only records tied to ``identity`` by an exact normalized identifier.

    A record is kept when its ``identifiers`` frozenset shares at least one
    value with the subject's identifier set (emails, email_hashes, phones,
    names, plus ``user_id``). Matching is exact, normalized equality ONLY: a
    near-but-not-equal identifier does not match and the record is excluded
    (Requirement 3.5). Input order is preserved.
    """
    subject_ids = _subject_identifiers(identity)
    return [r for r in records if not r.identifiers.isdisjoint(subject_ids)]


def select_closest(
    records: list[ParsedRecord], audit_at: datetime
) -> dict[ResourceKey, ParsedRecord]:
    """Pick the closest-to-``audit_at`` observation per resource.

    Records are grouped by ``ResourceKey = (system_id, resource_id)``. For each
    key, the chosen record is the one with the greatest ``observed_at`` that is
    not after ``audit_at`` (Requirements 3.4, 5.5). Records whose ``observed_at``
    is strictly after ``audit_at`` are ignored as defense in depth, even though
    :func:`eligible_files` already gates evidence at the file level. A resource
    whose records are all after ``audit_at`` does not appear in the result.
    """
    best: dict[ResourceKey, ParsedRecord] = {}
    for record in records:
        if record.observed_at > audit_at:
            continue
        key: ResourceKey = (record.system_id, record.resource_id)
        current = best.get(key)
        if current is None or record.observed_at > current.observed_at:
            best[key] = record
    return best
