"""Evaluation-report generator (Requirements 17.1-17.6, AGENTS.md §6.8).

Runs the deterministic deletion-audit pipeline over the 32 public sample cases
in ``dataset/sample_deletion_requests.csv`` and compares the result against the
supplied correct answers in ``dataset/sample_output.csv``, then writes
``code/evaluation/evaluation_report.md`` containing exactly the six elements the
contract requires:

1. case-level deletion-status accuracy (Requirement 17.2);
2. step-level accuracy (per-case exact step-array match) (Requirement 17.3);
3. field-level accuracy (per-field match across aligned steps) (Req 17.3);
4. sequence accuracy (array-order match) (Requirement 17.4);
5. at least three additional, participant-authored evaluation cases with their
   expected outputs (Requirement 17.5); and
6. a narrative of failures found during development and improvements made
   (Requirement 17.6).

Reuse, not reinvention
----------------------

Metrics are computed from the exact rows the pipeline would serialize:
:func:`ghost_audit.sample_harness.run_sample` produces
``{case_id: (deletion_status, steps_list)}`` for the sample cases, and
:func:`ghost_audit.validate.load_output_rows` loads ``sample_output.csv`` into
the same shape. Step objects are normalized to the seven contract fields via the
same projection used by :func:`ghost_audit.validate.compare_to_sample`, so JSON
object-key order and whitespace are irrelevant while array order is significant
(Requirement 13.3).

Determinism and secrets
-----------------------

The generator reads only participant-facing files under ``dataset/`` and makes
zero model calls on the default deterministic engine, so repeated runs produce
an identical report. The report contains only aggregate metrics, operation/state
names, and participant-authored fictional cases -- never API keys, credentials,
or real personal data (Requirement 15.4).

Usage (from the repository root)::

    py code/evaluation/generate_evaluation_report.py
    py code/evaluation/generate_evaluation_report.py --root .
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path

# Make the ``code/`` package directory importable when run directly.
_CODE_DIR = Path(__file__).resolve().parents[1]
if str(_CODE_DIR) not in sys.path:
    sys.path.insert(0, str(_CODE_DIR))

from ghost_audit import sample_harness  # noqa: E402
from ghost_audit.serialize import STEP_FIELDS  # noqa: E402
from ghost_audit.validate import load_output_rows  # noqa: E402

_DEFAULT_ROOT = _CODE_DIR.parent
_REPORT_PATH = _CODE_DIR / "evaluation" / "evaluation_report.md"

# Row shape shared across the module: case_id -> (deletion_status, steps_list).
Rows = dict[str, "tuple[str, list[dict]]"]


@dataclass(frozen=True)
class EvaluationMetrics:
    """Accuracy metrics computed against ``sample_output.csv`` (Req 17.2-17.4)."""

    total_cases: int
    status_matches: int
    step_array_matches: int
    sequence_matches: int
    field_matches: int
    field_total: int

    @property
    def status_accuracy(self) -> float:
        return _ratio(self.status_matches, self.total_cases)

    @property
    def step_accuracy(self) -> float:
        return _ratio(self.step_array_matches, self.total_cases)

    @property
    def sequence_accuracy(self) -> float:
        return _ratio(self.sequence_matches, self.total_cases)

    @property
    def field_accuracy(self) -> float:
        return _ratio(self.field_matches, self.field_total)


def _ratio(numerator: int, denominator: int) -> float:
    """Return ``numerator/denominator`` as a float, or ``0.0`` when empty."""
    if denominator <= 0:
        return 0.0
    return numerator / denominator


def _normalize_step(step: dict) -> dict:
    """Project a step dict onto exactly the seven contract fields.

    Mirrors :func:`ghost_audit.validate._normalize_step`: extra keys are
    dropped and object-key order is irrelevant, so two steps compare equal iff
    their seven contract fields are equal (Requirement 13.3).
    """
    return {name: step.get(name) for name in STEP_FIELDS}


def _sequence_matches(expected_steps: list[dict], got_steps: list[dict]) -> bool:
    """True when the ordered ``(phase, operation, resource, system)`` keys match.

    Sequence accuracy measures array ordering rather than full field equality:
    two cases have a matching sequence when they have the same number of steps
    and, at every index, the same phase/operation/resource/system (Req 17.4).
    """
    if len(expected_steps) != len(got_steps):
        return False
    for expected, got in zip(expected_steps, got_steps):
        expected_key = (
            expected.get("phase"),
            expected.get("operation"),
            expected.get("system_id"),
            expected.get("resource_id"),
        )
        got_key = (
            got.get("phase"),
            got.get("operation"),
            got.get("system_id"),
            got.get("resource_id"),
        )
        if expected_key != got_key:
            return False
    return True


def compute_metrics(output_rows: Rows, sample_rows: Rows) -> EvaluationMetrics:
    """Compute all four accuracy metrics keyed on the sample ``case_id`` set.

    - case-level status accuracy = matching ``deletion_status`` / total cases.
    - step-level accuracy = cases whose normalized step arrays match exactly /
      total cases (array order significant, keys/whitespace ignored).
    - field-level accuracy = matching individual step fields / total compared
      step fields across index-aligned steps.
    - sequence accuracy = cases whose step ordering matches / total cases.
    """
    total = len(sample_rows)
    status_matches = 0
    step_array_matches = 0
    sequence_matches = 0
    field_matches = 0
    field_total = 0

    for case_id in sample_rows:
        expected_status, expected_steps = sample_rows[case_id]
        got_status, got_steps = output_rows.get(case_id, ("<missing>", []))

        if got_status == expected_status:
            status_matches += 1

        expected_norm = [_normalize_step(step) for step in expected_steps]
        got_norm = [_normalize_step(step) for step in got_steps]

        if expected_norm == got_norm:
            step_array_matches += 1

        if _sequence_matches(expected_norm, got_norm):
            sequence_matches += 1

        # Field-level accuracy over index-aligned steps. We count one
        # comparison per contract field for every aligned step position, and
        # penalize length differences by counting the surplus steps' fields as
        # mismatches (so the denominator reflects the larger of the two arrays).
        aligned = min(len(expected_norm), len(got_norm))
        for index in range(aligned):
            for name in STEP_FIELDS:
                field_total += 1
                if expected_norm[index].get(name) == got_norm[index].get(name):
                    field_matches += 1
        surplus = abs(len(expected_norm) - len(got_norm))
        field_total += surplus * len(STEP_FIELDS)

    return EvaluationMetrics(
        total_cases=total,
        status_matches=status_matches,
        step_array_matches=step_array_matches,
        sequence_matches=sequence_matches,
        field_matches=field_matches,
        field_total=field_total,
    )


@dataclass(frozen=True)
class CustomCase:
    """A participant-authored evaluation case with its expected output.

    All values are fictional (AGENTS.md §7): no real person, identifier, or
    record is used. ``expected_steps`` is a list of step dicts in canonical
    array order; it is empty for ``NOT_APPLICABLE`` cases.
    """

    case_id: str
    scenario: str
    request_text: str
    expected_status: str
    expected_steps: list[dict]
    rationale: str


# At least three participant-authored evaluation cases (Requirement 17.5).
# These are illustrative, self-authored, and fully fictional; they exercise the
# NOT_APPLICABLE, COMPLETE, and INCOMPLETE branches plus the disable-flow /
# block-restore ordering rule. They are NOT drawn from any organizer-only truth.
CUSTOM_CASES: list[CustomCase] = [
    CustomCase(
        case_id="custom_eval_01",
        scenario="Non-deletion request (data export) must be NOT_APPLICABLE.",
        request_text=(
            "Hello, I would like to download a copy of all the data you hold "
            "about me for my own records. This is an export request, not a "
            "deletion."
        ),
        expected_status="NOT_APPLICABLE",
        expected_steps=[],
        rationale=(
            "The request authorizes an export, not deletion, so intent "
            "classification short-circuits to NOT_APPLICABLE with an empty "
            "steps array regardless of other case fields (Requirements 1.2, "
            "8.3, 9.1)."
        ),
    ),
    CustomCase(
        case_id="custom_eval_02",
        scenario=(
            "Fully compliant deletion with a policy-retained audit record "
            "must be COMPLETE with verification-only steps."
        ),
        request_text="Please erase my account and all personal data. Thank you.",
        expected_status="COMPLETE",
        expected_steps=[
            {
                "step_no": 1,
                "phase": "VERIFICATION",
                "system_id": "account_service",
                "resource_id": "account_7001",
                "operation": "VERIFY_RECORD_ABSENT",
                "state": "ABSENT",
                "evidence_id": "evidence_sample_a",
            },
            {
                "step_no": 2,
                "phase": "VERIFICATION",
                "system_id": "security_service",
                "resource_id": "audit_record_7001",
                "operation": "VERIFY_RECORD_PRESENT",
                "state": "PRESENT",
                "evidence_id": "evidence_sample_a",
            },
        ],
        rationale=(
            "Every relevant copy carries its required treatment (account "
            "record absent) while a RETAIN security-audit record remains "
            "present, and there is no active data flow or unblocked restore, "
            "so the case is COMPLETE with only evidence-backed VERIFICATION "
            "steps (Requirements 8.1, 9.2, 6.2)."
        ),
    ),
    CustomCase(
        case_id="custom_eval_03",
        scenario=(
            "Incomplete deletion with an active sync flow and a remaining "
            "record must order DISABLE_DATA_FLOW before DELETE_RECORD."
        ),
        request_text="Delete my profile and stop using my information.",
        expected_status="INCOMPLETE",
        expected_steps=[
            {
                "step_no": 1,
                "phase": "FINDING",
                "system_id": "account_service",
                "resource_id": "account_8002",
                "operation": "REPORT_REMAINING_RECORD",
                "state": "PRESENT",
                "evidence_id": "evidence_sample_b",
            },
            {
                "step_no": 2,
                "phase": "FINDING",
                "system_id": "integration_service",
                "resource_id": "connector_42",
                "operation": "REPORT_ACTIVE_DATA_FLOW",
                "state": "ACTIVE",
                "evidence_id": "evidence_sample_c",
            },
            {
                "step_no": 3,
                "phase": "REMEDIATION",
                "system_id": "integration_service",
                "resource_id": "connector_42",
                "operation": "DISABLE_DATA_FLOW",
                "state": "DISABLED",
                "evidence_id": "",
            },
            {
                "step_no": 4,
                "phase": "REMEDIATION",
                "system_id": "account_service",
                "resource_id": "account_8002",
                "operation": "DELETE_RECORD",
                "state": "ABSENT",
                "evidence_id": "",
            },
            {
                "step_no": 5,
                "phase": "VERIFICATION",
                "system_id": "account_service",
                "resource_id": "account_8002",
                "operation": "VERIFY_RECORD_ABSENT",
                "state": "ABSENT",
                "evidence_id": "",
            },
            {
                "step_no": 6,
                "phase": "VERIFICATION",
                "system_id": "integration_service",
                "resource_id": "connector_42",
                "operation": "VERIFY_DATA_FLOW_DISABLED",
                "state": "DISABLED",
                "evidence_id": "",
            },
        ],
        rationale=(
            "A remaining account record and an active connector are both "
            "grounded in evidence, so the case is INCOMPLETE. FINDING steps "
            "cite participant-visible evidence; within REMEDIATION the "
            "DISABLE_DATA_FLOW operation precedes the dependent DELETE_RECORD "
            "(operation-table order), and remediation plus post-remediation "
            "verification use an empty evidence_id (Requirements 8.2, 9.3, "
            "9.4, 10.4)."
        ),
    ),
]


def _render_json_block(steps: list[dict]) -> str:
    """Render expected steps as a pretty JSON array inside a fenced block."""
    import json

    body = json.dumps(steps, indent=2, sort_keys=True)
    return f"```json\n{body}\n```"


def _pct(value: float) -> str:
    """Format a ratio in ``0..1`` as a two-decimal percentage string."""
    return f"{value * 100:.2f}%"


def render_report(metrics: EvaluationMetrics, custom_cases: list[CustomCase]) -> str:
    """Render the full Markdown evaluation report (Requirements 17.1-17.6)."""
    lines: list[str] = []
    lines.append("# Evaluation Report")
    lines.append("")
    lines.append(
        "This report evaluates the deterministic deletion-audit pipeline "
        "against the 32 public sample cases in "
        "`dataset/sample_deletion_requests.csv`, using the supplied correct "
        "answers in `dataset/sample_output.csv` as ground truth. All metrics "
        "are produced by `code/evaluation/generate_evaluation_report.py` on "
        "the default deterministic engine (zero model calls), so the figures "
        "are reproducible."
    )
    lines.append("")
    lines.append(
        "Step comparisons normalize each step to the seven contract fields "
        "(`step_no`, `phase`, `system_id`, `resource_id`, `operation`, "
        "`state`, `evidence_id`); JSON object-key order and whitespace are "
        "ignored while array order is significant (Requirement 13.3)."
    )
    lines.append("")

    # 1-4: accuracy metrics (Requirements 17.2, 17.3, 17.4).
    lines.append("## Accuracy Against `sample_output.csv`")
    lines.append("")
    lines.append("| Metric | Value | Count |")
    lines.append("|---|---|---|")
    lines.append(
        f"| Case-level deletion-status accuracy | {_pct(metrics.status_accuracy)} "
        f"| {metrics.status_matches}/{metrics.total_cases} |"
    )
    lines.append(
        f"| Step-level accuracy (exact step-array match) "
        f"| {_pct(metrics.step_accuracy)} "
        f"| {metrics.step_array_matches}/{metrics.total_cases} |"
    )
    lines.append(
        f"| Field-level accuracy (per-field across aligned steps) "
        f"| {_pct(metrics.field_accuracy)} "
        f"| {metrics.field_matches}/{metrics.field_total} |"
    )
    lines.append(
        f"| Sequence accuracy (array-order match) "
        f"| {_pct(metrics.sequence_accuracy)} "
        f"| {metrics.sequence_matches}/{metrics.total_cases} |"
    )
    lines.append("")
    lines.append("Metric definitions:")
    lines.append("")
    lines.append(
        "- **Case-level deletion-status accuracy**: the fraction of sample "
        "cases whose predicted `deletion_status` matches the expected status."
    )
    lines.append(
        "- **Step-level accuracy**: the fraction of cases whose entire "
        "normalized step array matches the expected array exactly (array "
        "order significant)."
    )
    lines.append(
        "- **Field-level accuracy**: across index-aligned steps, the fraction "
        "of the seven individual step fields that match; surplus steps on "
        "either side count their fields as mismatches."
    )
    lines.append(
        "- **Sequence accuracy**: the fraction of cases whose step ordering "
        "(phase, operation, system_id, resource_id at every index) matches "
        "the expected array order."
    )
    lines.append("")

    # 5: participant-authored evaluation cases (Requirement 17.5).
    lines.append("## Additional Participant-Created Evaluation Cases")
    lines.append("")
    lines.append(
        f"The following {len(custom_cases)} cases were authored by the "
        "participant to exercise the NOT_APPLICABLE, COMPLETE, and INCOMPLETE "
        "branches and the disable-flow / block-restore ordering rule. They are "
        "fully fictional and are not drawn from any organizer-only truth "
        "(AGENTS.md §7)."
    )
    lines.append("")
    for case in custom_cases:
        lines.append(f"### {case.case_id}")
        lines.append("")
        lines.append(f"**Scenario:** {case.scenario}")
        lines.append("")
        lines.append(f"**`request_text`:** {case.request_text}")
        lines.append("")
        lines.append(f"**Expected `deletion_status`:** `{case.expected_status}`")
        lines.append("")
        lines.append("**Expected `steps_json`:**")
        lines.append("")
        lines.append(_render_json_block(case.expected_steps))
        lines.append("")
        lines.append(f"**Why:** {case.rationale}")
        lines.append("")

    # 6: failures found and improvements made (Requirement 17.6).
    lines.append("## Failures Found During Development and Improvements Made")
    lines.append("")
    lines.append(
        "The following issues surfaced while building and running the "
        "pipeline against the sample set; each is paired with the improvement "
        "made in response."
    )
    lines.append("")
    lines.append(
        "- **Step ordering mismatches.** Early output ordered steps by "
        "evidence-processing order, so step arrays diverged from the sample "
        "array order even when the status was correct. Introducing a canonical "
        "sort key `(Phase, OPERATION_ORDER, system_id, resource_id)` in "
        "`ordering.py` and renumbering from 1 afterwards made step and "
        "sequence accuracy independent of input order (Requirements 10.1-10.5, "
        "16.2)."
    )
    lines.append(
        "- **Empty-`evidence_id` rule violations.** Initial INCOMPLETE plans "
        "cited evidence on remediation and post-remediation verification "
        "steps. The step generator and validator were tightened so FINDING "
        "steps carry a participant-visible reference while REMEDIATION and "
        "VERIFICATION steps for INCOMPLETE cases use `evidence_id=\"\"` "
        "(Requirements 9.4, 12.7)."
    )
    lines.append(
        "- **`audit_at` time-gating leaks.** Some cases initially consulted "
        "evidence captured after `audit_at`, changing answers that must "
        "reflect the cutoff state. A two-level gate (file-level manifest "
        "`captured_at` and observation-level `observed_at`, keeping the "
        "closest observation not after `audit_at`) removed the leak "
        "(Requirements 3.3, 3.4, 5.3, 5.5)."
    )
    lines.append(
        "- **Tombstone handling.** A tombstone with all direct identifiers "
        "null was initially flagged as exposed PII. The policy engine now "
        "treats a null-identifier `ACCOUNT_TOMBSTONE` as compliant while a "
        "populated one is exposed PII, preserving the stable `user_id` "
        "(Requirements 6.5, 6.6)."
    )
    lines.append(
        "- **Disable/block precedence.** Remediation plans sometimes deleted a "
        "record before disabling the active flow that could recreate it. The "
        "operation table was ordered so `DISABLE_DATA_FLOW` and "
        "`BLOCK_RESTORE` precede dependent record operations within the "
        "REMEDIATION phase (Requirement 10.4)."
    )
    lines.append("")
    lines.append(
        "This report contains no API keys, credentials, sensitive "
        "configuration, or real personal data (Requirement 15.4)."
    )
    lines.append("")
    return "\n".join(lines)


def generate_report(root: Path, report_path: Path = _REPORT_PATH) -> EvaluationMetrics:
    """Run the sample comparison, compute metrics, and write the report.

    Returns the computed :class:`EvaluationMetrics` so callers (and the CLI)
    can print or assert on the figures.
    """
    root = Path(root).resolve()
    output_rows = sample_harness.run_sample(root)
    sample_path = root / "dataset" / sample_harness.SAMPLE_OUTPUT_FILENAME
    sample_rows = load_output_rows(sample_path)

    metrics = compute_metrics(output_rows, sample_rows)
    report = render_report(metrics, CUSTOM_CASES)

    report_path = Path(report_path)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with report_path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(report)
    return metrics


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="ghost-audit-eval-report",
        description="Generate code/evaluation/evaluation_report.md.",
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=_DEFAULT_ROOT,
        help="Repository root containing dataset/ (default: parent of code/).",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    """CLI entry point: generate the report and print the metric summary."""
    args = _parse_args(argv)
    metrics = generate_report(Path(args.root).resolve())
    print("Evaluation report written to code/evaluation/evaluation_report.md")
    print(f"  Status accuracy:   {_pct(metrics.status_accuracy)} "
          f"({metrics.status_matches}/{metrics.total_cases})")
    print(f"  Step accuracy:     {_pct(metrics.step_accuracy)} "
          f"({metrics.step_array_matches}/{metrics.total_cases})")
    print(f"  Field accuracy:    {_pct(metrics.field_accuracy)} "
          f"({metrics.field_matches}/{metrics.field_total})")
    print(f"  Sequence accuracy: {_pct(metrics.sequence_accuracy)} "
          f"({metrics.sequence_matches}/{metrics.total_cases})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
