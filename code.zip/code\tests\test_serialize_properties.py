"""Property-based + unit tests for the serializer (``code/ghost_audit/serialize.py``).

Properties covered:

- 13.2 serializing the same steps twice yields byte-identical ``steps_json``
  (**Validates: Requirements 16.3**).
- 13.3 ``json_to_steps(steps_to_json(x))`` preserves array order and fields
  (**Validates: Requirements 11.5, 11.6**).

A few focused unit assertions also verify the ``output.csv`` contract: the exact
header line, rows sorted by ``case_id``, and that a ``NOT_APPLICABLE`` case
serializes its ``steps_json`` column as ``[]``.

Step generator strategy
-----------------------

Steps are drawn from the real field space: ``step_no`` is a small positive int
(ints survive JSON round-trips exactly), ``phase`` is one of the three allowed
phases, ``operation``/``state`` are drawn from the allowed operation/state map,
and the id/evidence strings are small (possibly empty for ``evidence_id``).
"""

from __future__ import annotations

import csv

from hypothesis import given
from hypothesis import strategies as st

from ghost_audit.models import CaseResult, Step
from ghost_audit.serialize import (
    OUTPUT_HEADER,
    json_to_steps,
    steps_to_json,
    write_output,
)
from ghost_audit.steps import OPERATION_STATE

# Allowed phases (AGENTS.md §6.4).
_PHASES = ["FINDING", "REMEDIATION", "VERIFICATION"]

# Allowed (operation, state) pairs taken directly from the step generator's map
# so generated steps only ever use contract-legal pairs.
_OP_STATE_PAIRS = sorted(OPERATION_STATE.items())

_small_text = st.text(
    alphabet=st.characters(min_codepoint=32, max_codepoint=126),
    min_size=1,
    max_size=12,
)
# evidence_id may be empty (remediation / post-remediation verification).
_evidence_text = st.text(
    alphabet=st.characters(min_codepoint=32, max_codepoint=126),
    min_size=0,
    max_size=12,
)


@st.composite
def _steps(draw) -> Step:
    """Generate a single contract-shaped :class:`Step`."""
    operation, state = draw(st.sampled_from(_OP_STATE_PAIRS))
    phase = draw(st.sampled_from(_PHASES))
    return Step(
        step_no=draw(st.integers(min_value=1, max_value=10_000)),
        phase=phase,
        system_id=draw(_small_text),
        resource_id=draw(_small_text),
        operation=operation,
        state=state,
        evidence_id=draw(_evidence_text),
    )


_step_lists = st.lists(_steps(), min_size=0, max_size=8)


class TestIdempotentSerialization:
    """Task 13.2 property test."""

    @given(steps=_step_lists)
    def test_serializing_twice_is_byte_identical(self, steps):
        """Property: serializing the same steps twice yields byte-identical JSON.

        Validates: Requirements 16.3
        """
        first = steps_to_json(steps)
        second = steps_to_json(steps)
        assert first == second


class TestRoundTrip:
    """Task 13.3 property test."""

    @given(steps=_step_lists)
    def test_round_trip_preserves_order_and_fields(self, steps):
        """Property: json_to_steps(steps_to_json(x)) preserves order and fields.

        Validates: Requirements 11.5, 11.6
        """
        assert json_to_steps(steps_to_json(steps)) == steps


class TestOutputCsvUnit:
    """Focused unit assertions for the ``output.csv`` contract."""

    def test_header_is_exact(self, tmp_path):
        """``write_output`` writes exactly ``case_id,deletion_status,steps_json``."""
        write_output([], tmp_path)
        out = tmp_path / "output.csv"
        with out.open("r", encoding="utf-8", newline="") as handle:
            header = handle.readline().rstrip("\r\n")
        assert header == "case_id,deletion_status,steps_json"
        assert OUTPUT_HEADER == ("case_id", "deletion_status", "steps_json")

    def test_not_applicable_row_serializes_empty_array(self, tmp_path):
        """A NOT_APPLICABLE case serializes its steps_json column as ``[]``."""
        rows = [CaseResult(case_id="case_01", deletion_status="NOT_APPLICABLE", steps=())]
        write_output(rows, tmp_path)
        out = tmp_path / "output.csv"
        with out.open("r", encoding="utf-8", newline="") as handle:
            reader = list(csv.reader(handle))
        # reader[0] is the header; reader[1] is the single data row.
        assert reader[1] == ["case_01", "NOT_APPLICABLE", "[]"]

    def test_rows_sorted_by_case_id(self, tmp_path):
        """Rows are written sorted by ``case_id`` ascending (Requirement 11.3)."""
        rows = [
            CaseResult(case_id="case_03", deletion_status="NOT_APPLICABLE", steps=()),
            CaseResult(case_id="case_01", deletion_status="NOT_APPLICABLE", steps=()),
            CaseResult(case_id="case_02", deletion_status="NOT_APPLICABLE", steps=()),
        ]
        write_output(rows, tmp_path)
        out = tmp_path / "output.csv"
        with out.open("r", encoding="utf-8", newline="") as handle:
            reader = list(csv.reader(handle))
        case_ids = [r[0] for r in reader[1:]]
        assert case_ids == ["case_01", "case_02", "case_03"]
