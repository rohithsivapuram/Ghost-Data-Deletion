"""Unit tests for the policy engine (``code/ghost_audit/policy.py``).

Covers tombstone handling (Requirements 6.5, 6.6) plus representative examples
of each required action: DELETE presence/absence, RETAIN present, BACKUP_ARCHIVE
restore risk, and DATA_FLOW active-flow detection.
"""

from __future__ import annotations

import pytest

from ghost_audit.models import PolicyRule, RecordState
from ghost_audit.policy import apply_policy

# A small rules fixture keyed by data_category, mirroring deletion_rules.csv.
# DATA_FLOW is intentionally absent (it is synthetic, not in the CSV).
_RULES: dict[str, PolicyRule] = {
    "USER_PROFILE": PolicyRule("rule_01", "USER_PROFILE", "Always", "DELETE"),
    "SUPPORT_MESSAGE": PolicyRule("rule_05", "SUPPORT_MESSAGE", "...", "REDACT"),
    "ANALYTICS_PROFILE": PolicyRule("rule_07", "ANALYTICS_PROFILE", "...", "ANONYMIZE"),
    "SECURITY_AUDIT_LOG": PolicyRule("rule_12", "SECURITY_AUDIT_LOG", "...", "RETAIN"),
    "LEGAL_HOLD_RECORD": PolicyRule("rule_13", "LEGAL_HOLD_RECORD", "...", "RETAIN"),
    "BACKUP_ARCHIVE": PolicyRule("rule_14", "BACKUP_ARCHIVE", "...", "RETAIN"),
    "ACCOUNT_TOMBSTONE": PolicyRule("rule_15", "ACCOUNT_TOMBSTONE", "...", "REDACT"),
}


def _state(
    data_category: str,
    *,
    present: bool = True,
    exposed: frozenset[str] = frozenset(),
    treatment: str = "NONE",
    is_active_flow: bool = False,
    is_restore_risk: bool = False,
    system_id: str = "sys",
    resource_id: str = "res_1",
    proving_evidence_id: str = "evidence_01",
) -> RecordState:
    """Build a RecordState fixture with sensible defaults."""
    return RecordState(
        system_id=system_id,
        resource_id=resource_id,
        data_category=data_category,
        present=present,
        exposed_identifiers=exposed,
        treatment=treatment,
        is_active_flow=is_active_flow,
        is_restore_risk=is_restore_risk,
        proving_evidence_id=proving_evidence_id,
    )


class TestTombstoneHandling:
    """Requirements 6.5, 6.6: tombstone keeps user_id, flags exposed PII."""

    def test_tombstone_null_identifiers_compliant(self):
        """A tombstone with no exposed direct identifiers is compliant.

        exposed_identifiers already excludes the stable user_id, so an empty
        set means only the user_id remains => compliant, no finding, and the
        verification op proving the redacted state.
        """
        decision = apply_policy(_state("ACCOUNT_TOMBSTONE", exposed=frozenset()), _RULES)

        assert decision.required_action == "REDACT"
        assert decision.compliant is True
        assert decision.finding_op is None
        assert decision.remediation_op is None
        assert decision.verification_op == "VERIFY_RECORD_REDACTED"

    def test_tombstone_populated_identifiers_exposed_pii(self):
        """A tombstone still carrying direct identifiers is exposed PII."""
        decision = apply_policy(
            _state("ACCOUNT_TOMBSTONE", exposed=frozenset({"ada@example.com"})),
            _RULES,
        )

        assert decision.required_action == "REDACT"
        assert decision.compliant is False
        assert decision.finding_op == "REPORT_EXPOSED_PII"
        assert decision.remediation_op == "REDACT_RECORD"
        assert decision.verification_op == "VERIFY_RECORD_REDACTED"


class TestDeleteAction:
    """USER_PROFILE DELETE: present => finding, absent => compliant."""

    def test_present_record_is_finding(self):
        decision = apply_policy(_state("USER_PROFILE", present=True), _RULES)

        assert decision.required_action == "DELETE"
        assert decision.compliant is False
        assert decision.finding_op == "REPORT_REMAINING_RECORD"
        assert decision.remediation_op == "DELETE_RECORD"
        assert decision.verification_op == "VERIFY_RECORD_ABSENT"

    def test_absent_record_is_compliant(self):
        decision = apply_policy(_state("USER_PROFILE", present=False), _RULES)

        assert decision.compliant is True
        assert decision.finding_op is None
        assert decision.remediation_op is None
        assert decision.verification_op == "VERIFY_RECORD_ABSENT"


class TestRetainAction:
    """SECURITY_AUDIT_LOG RETAIN: present => compliant, never a removal op."""

    def test_present_retained_record_compliant_no_removal(self):
        decision = apply_policy(_state("SECURITY_AUDIT_LOG", present=True), _RULES)

        assert decision.required_action == "RETAIN"
        assert decision.compliant is True
        assert decision.finding_op is None
        assert decision.remediation_op is None
        assert decision.verification_op == "VERIFY_RECORD_PRESENT"

    def test_retain_never_emits_removal_op_even_when_absent(self):
        """An absent retained record is non-compliant but still has no removal op."""
        decision = apply_policy(_state("LEGAL_HOLD_RECORD", present=False), _RULES)

        assert decision.required_action == "RETAIN"
        assert decision.compliant is False
        assert decision.remediation_op not in {
            "DELETE_RECORD",
            "REDACT_RECORD",
            "ANONYMIZE_RECORD",
        }
        assert decision.verification_op == "VERIFY_RECORD_PRESENT"


class TestBackupArchive:
    """BACKUP_ARCHIVE: active restore => finding, never a delete op."""

    def test_active_restore_is_finding(self):
        decision = apply_policy(
            _state("BACKUP_ARCHIVE", is_restore_risk=True, system_id="backup_service"),
            _RULES,
        )

        assert decision.required_action == "RETAIN"
        assert decision.compliant is False
        assert decision.finding_op == "REPORT_RESTORE_RISK"
        assert decision.remediation_op == "BLOCK_RESTORE"
        assert decision.verification_op == "VERIFY_RESTORE_BLOCKED"

    def test_blocked_restore_is_compliant(self):
        decision = apply_policy(
            _state("BACKUP_ARCHIVE", is_restore_risk=False, system_id="backup_service"),
            _RULES,
        )

        assert decision.compliant is True
        assert decision.finding_op is None
        assert decision.remediation_op is None
        assert decision.verification_op == "VERIFY_RESTORE_BLOCKED"


class TestDataFlow:
    """DATA_FLOW: active flow => finding REPORT_ACTIVE_DATA_FLOW."""

    def test_active_data_flow_is_finding(self):
        decision = apply_policy(
            _state("DATA_FLOW", is_active_flow=True, system_id="integration_service"),
            _RULES,
        )

        assert decision.required_action == "DISABLE"
        assert decision.compliant is False
        assert decision.finding_op == "REPORT_ACTIVE_DATA_FLOW"
        assert decision.remediation_op == "DISABLE_DATA_FLOW"
        assert decision.verification_op == "VERIFY_DATA_FLOW_DISABLED"

    def test_disabled_data_flow_is_compliant(self):
        decision = apply_policy(
            _state("DATA_FLOW", is_active_flow=False, system_id="integration_service"),
            _RULES,
        )

        assert decision.required_action == "DISABLE"
        assert decision.compliant is True
        assert decision.finding_op is None
        assert decision.remediation_op is None
        assert decision.verification_op == "VERIFY_DATA_FLOW_DISABLED"


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(pytest.main([__file__, "-v"]))
