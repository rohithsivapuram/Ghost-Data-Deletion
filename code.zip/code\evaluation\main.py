"""Evaluation harness entry point (minimal; refined by task 19).

Runs the deletion-audit pipeline over the public sample set
(``sample_deletion_requests.csv``) and compares the produced statuses and step
arrays against ``sample_output.csv`` via
:func:`ghost_audit.validate.compare_to_sample`, printing a one-line summary.

This is intentionally minimal and non-breaking: task 19 fleshes out the full
evaluation report. The full-dataset run lives in ``code/main.py``.

Usage (from the repository root)::

    py code/evaluation/main.py
    py code/evaluation/main.py --root .
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

# Make the ``code/`` package directory importable when run directly.
_CODE_DIR = Path(__file__).resolve().parents[1]
if str(_CODE_DIR) not in sys.path:
    sys.path.insert(0, str(_CODE_DIR))

from ghost_audit import loaders, pipeline, serialize, validate  # noqa: E402
from ghost_audit.models import Case  # noqa: E402

_DEFAULT_ROOT = _CODE_DIR.parent


def _load_sample_cases(root: Path) -> list[Case]:
    """Load ``dataset/sample_deletion_requests.csv`` into :class:`Case` rows.

    Mirrors :func:`ghost_audit.loaders.load_requests` but reads the 32-row
    public sample file instead of the full 518-row request set.
    """
    path = Path(root) / loaders.DATASET_DIR / "sample_deletion_requests.csv"
    cases: list[Case] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            cases.append(
                Case(
                    case_id=row["case_id"],
                    email=row["email"],
                    requested_at=loaders.parse_timestamp(row["requested_at"]),
                    reported_status=row["reported_status"],
                    reported_at=loaders.parse_timestamp(row["reported_at"]),
                    audit_at=loaders.parse_timestamp(row["audit_at"]),
                    request_text=row["request_text"],
                )
            )
    return cases


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="ghost-audit-eval",
        description="Compare sample-set output to sample_output.csv.",
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=_DEFAULT_ROOT,
        help="Repository root containing dataset/ (default: parent of code/).",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    """Run the sample-set comparison and print a summary."""
    args = _parse_args(argv)
    root = Path(args.root).resolve()

    sample_path = root / loaders.DATASET_DIR / "sample_deletion_requests.csv"
    expected_path = root / loaders.DATASET_DIR / "sample_output.csv"
    if not sample_path.exists() or not expected_path.exists():
        print("Sample files not found; nothing to evaluate.")
        print(f"  expected: {sample_path}")
        print(f"  expected: {expected_path}")
        return 0

    cases = _load_sample_cases(root)

    # Reuse the shared pipeline: parse all evidence once, then process the
    # sample cases with the deterministic engine.
    store = loaders.load_identities(root)
    rules = loaders.load_rules(root)
    manifest = loaders.load_evidence_manifest(root)
    all_records, _failures = pipeline.dispatch.parse_all(manifest)
    file_captured_at = {ef.file_id: ef.captured_at for ef in manifest}
    engine = pipeline.select_engine()

    output_rows: dict[str, tuple[str, list[dict]]] = {}
    for case in cases:
        result = pipeline.process_case(
            case, store, rules, all_records, file_captured_at, engine
        )
        steps = [
            {
                "step_no": s.step_no,
                "phase": s.phase,
                "system_id": s.system_id,
                "resource_id": s.resource_id,
                "operation": s.operation,
                "state": s.state,
                "evidence_id": s.evidence_id,
            }
            for s in result.steps
        ]
        output_rows[case.case_id] = (result.deletion_status, steps)

    sample_rows = validate.load_output_rows(expected_path)
    report = validate.compare_to_sample(output_rows, sample_rows)
    print("Sample-set comparison:")
    print(f"  {report.summary()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
