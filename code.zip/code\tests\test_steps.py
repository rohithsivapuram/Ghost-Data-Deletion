"""Unit tests for the step generator (``code/ghost_audit/steps.py``).

Covers the ``evidence_id`` rules (Requirements 9.2, 9.4) and the
``NOT_APPLICABLE`` empty-plan rule (Requirement 9.1):

- FINDING steps cite non-empty participant-visible evidence.
- REMEDIATION and post-remediation VERIFICATION steps use ``evidence_id=""``.
- ``COMPLETE`` VERIFICATION steps cite non-empty proving evidence.
- ``NOT_APPLICABLE`` yields ``[]``.
"""

from __future__ import annotations

import pytest

from ghost_audit.models import PolicyDecision, RecordState
from ghost_audit.steps import OPERATION_STATE, generate_steps


def _state(
    *,
    system_id: str = "account_service",
    resource_id: str = "account_005",
    data_category: str = "USER_PROFILE",
    proving_evidence_id: str = "evidence_01",
    present: bool = True,
) -> RecordState:
    return RecordState(
        system_id=system_id,
        resource_id=resource_id,
        data_category=data_category,
        present=present,
        exposed_identifiers=frozenset(),
        treatment="NONE",
        is_active_flow=False,
        is_restore_risk=False,
        proving_evidence_id=proving_evidence_id,
    )


def _decision(
    *,
    compliant: bool,
    finding_op: str | None,
    remediation_op: str | None,
    verification_op: str,
    state: RecordState | None = None,
) -> PolicyDecision:
    return PolicyDecision(
        state=state if state is not None else _state(),
        required_action="X",
        compliant=compliant,
        finding_op=finding_op,
        remediation_op=remediation_op,
        verification_op=verification_op,
    )


# A compliant DELETE decision (record absent) for COMPLETE cases.
_COMPLIANT_DELETE = _decision(
    compliant=True,
    finding_op=None,
    remediation_op=None,
    verification_op="VERIFY_RECORD_ABSENT",
    state=_state(present=False, proving_evidence_id="evidence_42"),
)

# A non-compliant DELETE decision (record present) for INCOMPLETE cases.
_NONCOMPLIANT_DELETE = _decision(
    compliant=False,
    finding_op="REPORT_REMAINING_RECORD",
    remediation_op="DELETE_RECORD",
    verification_op="VERIFY_RECORD_ABSENT",
    state=_state(present=True, proving_evidence_id="evidence_07"),
)


class TestNotApplicable:
    """Requirement 9.1."""

    def test_not_applicable_returns_empty(self):
        assert generate_steps("NOT_APPLICABLE", [_NONCOMPLIANT_DELETE]) == []

    def test_not_applicable_ignores_decisions(self):
        assert generate_steps("NOT_APPLICABLE", []) == []


class TestCompleteEvidence:
    """Requirement 9.2: COMPLETE verifications cite non-empty evidence."""

    def test_complete_emits_verification_only_with_evidence(self):
        steps = generate_steps("COMPLETE", [_COMPLIANT_DELETE])

        assert len(steps) == 1
        step = steps[0]
        assert step.phase == "VERIFICATION"
        assert step.operation == "VERIFY_RECORD_ABSENT"
        assert step.state == OPERATION_STATE["VERIFY_RECORD_ABSENT"]
        assert step.evidence_id == "evidence_42"
        assert step.evidence_id != ""

    def test_complete_has_no_finding_or_remediation(self):
        steps = generate_steps("COMPLETE", [_COMPLIANT_DELETE])
        assert all(s.phase == "VERIFICATION" for s in steps)


class TestIncompleteEvidenceRules:
    """Requirements 9.3, 9.4: finding cites evidence; remediation/verification empty."""

    def test_finding_cites_non_empty_evidence(self):
        steps = generate_steps("INCOMPLETE", [_NONCOMPLIANT_DELETE])
        findings = [s for s in steps if s.phase == "FINDING"]

        assert len(findings) == 1
        assert findings[0].operation == "REPORT_REMAINING_RECORD"
        assert findings[0].evidence_id == "evidence_07"
        assert findings[0].evidence_id != ""

    def test_remediation_uses_empty_evidence(self):
        steps = generate_steps("INCOMPLETE", [_NONCOMPLIANT_DELETE])
        remediation = [s for s in steps if s.phase == "REMEDIATION"]

        assert len(remediation) == 1
        assert remediation[0].operation == "DELETE_RECORD"
        assert remediation[0].evidence_id == ""

    def test_post_remediation_verification_uses_empty_evidence(self):
        steps = generate_steps("INCOMPLETE", [_NONCOMPLIANT_DELETE])
        verification = [s for s in steps if s.phase == "VERIFICATION"]

        assert len(verification) == 1
        assert verification[0].operation == "VERIFY_RECORD_ABSENT"
        assert verification[0].evidence_id == ""

    def test_incomplete_full_plan_order_and_numbering(self):
        """FINDING -> REMEDIATION -> VERIFICATION, numbered 1..3."""
        steps = generate_steps("INCOMPLETE", [_NONCOMPLIANT_DELETE])

        assert [s.phase for s in steps] == ["FINDING", "REMEDIATION", "VERIFICATION"]
        assert [s.step_no for s in steps] == [1, 2, 3]

    def test_incomplete_skips_compliant_decisions(self):
        """Already-compliant decisions contribute no steps in an INCOMPLETE case."""
        steps = generate_steps("INCOMPLETE", [_NONCOMPLIANT_DELETE, _COMPLIANT_DELETE])

        # Only the non-compliant decision is remediated/verified.
        assert [s.phase for s in steps] == ["FINDING", "REMEDIATION", "VERIFICATION"]
        assert all(s.evidence_id in ("", "evidence_07") for s in steps)


class TestRetainFindingOmitted:
    """A RETAIN record that is non-compliant (absent) has no finding op, so no
    FINDING step is emitted, but a VERIFY_RECORD_PRESENT step still appears."""

    def test_retain_absent_emits_verification_no_finding(self):
        retain = _decision(
            compliant=False,
            finding_op=None,
            remediation_op=None,
            verification_op="VERIFY_RECORD_PRESENT",
            state=_state(
                system_id="security_service",
                resource_id="audit_1",
                data_category="SECURITY_AUDIT_LOG",
                present=False,
            ),
        )
        steps = generate_steps("INCOMPLETE", [retain])

        assert [s.phase for s in steps] == ["VERIFICATION"]
        assert steps[0].operation == "VERIFY_RECORD_PRESENT"
        assert steps[0].evidence_id == ""


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(pytest.main([__file__, "-v"]))
