"""Determinism check tests (Requirements 16.1, 16.2, 16.3).

These tests confirm the pipeline is reproducible: running the full pipeline
twice over the same inputs and configuration yields ``output.csv`` artifacts
that are equivalent in row order, statuses, and step arrays.

The end-to-end two-run assertion uses the 32-case sample request file so the
test is fast while still exercising the real load -> parse-once -> state ->
policy -> decision -> steps -> serialize path. The comparison logic itself is
also unit-tested with crafted row lists so each divergence kind (row count,
row order, status, step array) is detected and reported.
"""

from __future__ import annotations

from pathlib import Path

from ghost_audit import determinism

# Repository root = parent of the ``code/`` directory (two levels up from here).
_ROOT = Path(__file__).resolve().parent.parent.parent

_SAMPLE = "sample_deletion_requests.csv"


class TestEndToEnd:
    def test_two_full_runs_are_identical(self):
        """Two pipeline runs produce byte-identical output rows (Req 16.1-16.3)."""
        report = determinism.check_determinism(_ROOT, requests_filename=_SAMPLE)
        assert report.deterministic is True, report.summary()
        assert report.row_count_first == report.row_count_second
        assert report.row_count_first == 32
        assert report.differing_case_id is None
        assert report.differences == []

    def test_run_twice_returns_equal_row_lists(self):
        """run_twice yields two equal serialized row lists for the same inputs."""
        first, second = determinism.run_twice(_ROOT, requests_filename=_SAMPLE)
        assert first == second
        # Rows are sorted by case_id ascending (Requirement 11.3).
        assert first == sorted(first, key=lambda row: row[0])

    def test_rows_carry_contract_triple(self):
        """Each serialized row is (case_id, status, steps_json)."""
        first, _ = determinism.run_twice(_ROOT, requests_filename=_SAMPLE)
        for case_id, status, steps_json in first:
            assert case_id.startswith("case_")
            assert status in {"COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"}
            assert steps_json.startswith("[")


class TestCompareRows:
    def test_identical_rows_are_deterministic(self):
        rows = [
            ("case_001", "NOT_APPLICABLE", "[]"),
            ("case_002", "COMPLETE", '[{"step_no":1}]'),
        ]
        report = determinism.compare_rows(list(rows), list(rows))
        assert report.deterministic is True
        assert report.reason == ""
        assert "2 rows identical" in report.summary()

    def test_row_count_difference_detected(self):
        first = [("case_001", "NOT_APPLICABLE", "[]")]
        second: list[determinism.OutputRow] = []
        report = determinism.compare_rows(first, second)
        assert report.deterministic is False
        assert report.differing_case_id is None
        assert "row count differs" in report.reason

    def test_row_order_difference_detected(self):
        first = [
            ("case_001", "COMPLETE", "[]"),
            ("case_002", "COMPLETE", "[]"),
        ]
        second = [
            ("case_002", "COMPLETE", "[]"),
            ("case_001", "COMPLETE", "[]"),
        ]
        report = determinism.compare_rows(first, second)
        assert report.deterministic is False
        assert "row order differs" in report.reason

    def test_status_difference_detected(self):
        first = [("case_001", "COMPLETE", "[]")]
        second = [("case_001", "INCOMPLETE", "[]")]
        report = determinism.compare_rows(first, second)
        assert report.deterministic is False
        assert report.differing_case_id == "case_001"
        assert "status differs" in report.reason

    def test_steps_json_difference_detected(self):
        first = [("case_001", "COMPLETE", '[{"step_no":1}]')]
        second = [("case_001", "COMPLETE", '[{"step_no":2}]')]
        report = determinism.compare_rows(first, second)
        assert report.deterministic is False
        assert report.differing_case_id == "case_001"
        assert "steps_json differs" in report.reason


class TestCli:
    def test_main_returns_zero_on_deterministic_run(self):
        rc = determinism.main(["--root", str(_ROOT), "--requests", _SAMPLE])
        assert rc == 0
