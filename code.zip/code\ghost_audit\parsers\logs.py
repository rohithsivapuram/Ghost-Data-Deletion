"""Lookup-trace log evidence parser (task 7.3).

Resource-lookup trace logs are whitespace-separated lines whose first token is
an ISO-8601 timestamp followed by ``key=value`` pairs, e.g.::

    2026-03-10T06:18:01Z level=INFO service=account_service \
        event=profile_lookup_completed resource_id=account_6523 rows=0 http_status=404

Only ``*_completed`` events carry a resolved state (``profile_lookup_completed``,
``index_query_completed``, ``connector_config_read_completed``,
``restore_policy_read_completed``, ``audit_record_read_completed``,
``support_ticket_read_completed``, ``analytics_profile_read_completed``). The
``*_started`` and export-collector lines are skipped.

State derivation per completed event (grounded in the dataset):

- ``http_status=404`` -> absent (``NOT_FOUND``); ``200`` -> present (``FOUND``).
- ``result=hit`` -> present (``FOUND``); ``result=miss`` -> absent
  (``NOT_FOUND``) for search index queries.
- ``enabled=true`` -> present/``ACTIVE``; ``enabled=false`` -> present/
  ``DISABLED`` for connector/data-flow reads.
- ``restore_allowed=true`` (restore risk) -> present/``ACTIVE``;
  ``restore_allowed=false`` -> present/``BLOCKED`` for backup restore policy.
- otherwise, a line carrying an email/subject reference -> present/``FOUND``.

``data_category`` is left ``None`` on log records; the state reconstructor maps
category by system. Identifiers are collected from ``lookup_key``, ``email``,
``customer_email``, ``requester_email``, ``subject_reference``,
``customer_reference``, ``email_hash``, ``phone``, and ``requester_phone`` /
``requester_name`` when present. The parsed key/value dict is stored in
``raw`` for debugging. Lines that do not parse are skipped defensively.
"""

from __future__ import annotations

from ..loaders import parse_timestamp
from ..models import ParsedRecord
from ._common import IdentifierCollector, is_nullish

__all__ = ["parse_lookup_log"]

# key=value keys that carry email identifiers.
_EMAIL_KEYS = ("email", "customer_email", "requester_email", "owner_email")
# keys that carry opaque references.
_REFERENCE_KEYS = ("subject_reference", "customer_reference")
# keys that carry phone identifiers.
_PHONE_KEYS = ("phone", "requester_phone", "owner_phone")
# keys that carry person names.
_NAME_KEYS = ("requester_name", "full_name", "display_name")


def _parse_kv(tokens: list[str]) -> dict[str, str]:
    """Parse ``key=value`` tokens into a dict, splitting on the first ``=``.

    Tokens without an ``=`` (rare malformed fragments) are ignored.
    """
    pairs: dict[str, str] = {}
    for token in tokens:
        if "=" not in token:
            continue
        key, value = token.split("=", 1)
        key = key.strip()
        if key:
            pairs[key] = value.strip()
    return pairs


def _derive_state(kv: dict[str, str]) -> tuple[bool, str] | None:
    """Derive ``(present, state_signal)`` from a completed event's fields.

    Returns ``None`` when the line carries no resolvable state signal, in which
    case the caller skips it.
    """
    http_status = kv.get("http_status")
    if http_status == "404":
        return False, "NOT_FOUND"
    if http_status == "200":
        return True, "FOUND"

    result = kv.get("result")
    if result == "hit":
        return True, "FOUND"
    if result == "miss":
        return False, "NOT_FOUND"

    enabled = kv.get("enabled")
    if enabled is not None:
        return (True, "ACTIVE") if enabled.lower() == "true" else (True, "DISABLED")

    restore_allowed = kv.get("restore_allowed")
    if restore_allowed is not None:
        if restore_allowed.lower() == "true":
            return True, "ACTIVE"
        return True, "BLOCKED"

    # Read-completed lines (support/analytics/security) with no boolean flag:
    # treat a line that resolved a record as present. Analytics lines with all
    # identifiers null still describe a present-but-anonymized record.
    has_identifier = any(
        not is_nullish(kv.get(key))
        for key in (*_EMAIL_KEYS, *_REFERENCE_KEYS, *_PHONE_KEYS, *_NAME_KEYS)
    )
    if has_identifier:
        return True, "FOUND"
    if "subject_reference" in kv or "audience_cohort" in kv:
        # A resolved read with no direct identifier (e.g. anonymized analytics
        # profile or a security audit record keyed by subject_reference).
        return True, "ANONYMIZED" if "audience_cohort" in kv else "FOUND"
    return None


def _collect_identifiers(kv: dict[str, str]) -> IdentifierCollector:
    """Collect every identifier present in a parsed log line."""
    collector = IdentifierCollector()
    # lookup_key may be an email or an opaque reference.
    collector.add_token(kv.get("lookup_key"))
    for key in _EMAIL_KEYS:
        collector.add_email(kv.get(key))
    for key in _REFERENCE_KEYS:
        collector.add_reference(kv.get(key))
    for key in _PHONE_KEYS:
        collector.add_phone(kv.get(key))
    for key in _NAME_KEYS:
        collector.add_name(kv.get(key))
    collector.add_hash(kv.get("email_hash"))
    return collector


def parse_lookup_log(text: str, file_id: str) -> list[ParsedRecord]:
    """Parse ``key=value`` lookup-trace log lines into :class:`ParsedRecord`s.

    Args:
        text: Full UTF-8 contents of the ``.log`` file.
        file_id: Manifest ``file_id`` to stamp on every extracted record.

    Returns:
        One :class:`ParsedRecord` per ``*_completed`` line that resolves to a
        state and carries a ``resource_id``, in file order.
    """
    records: list[ParsedRecord] = []

    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        tokens = stripped.split()
        if len(tokens) < 2:
            continue

        # First token is the timestamp.
        try:
            observed_at = parse_timestamp(tokens[0])
        except (ValueError, TypeError):
            continue

        kv = _parse_kv(tokens[1:])

        event = kv.get("event", "")
        if not event.endswith("_completed"):
            continue
        # The readback-collector export summary lines also end with
        # ``_completed`` (``export_completed``) but carry no resource.
        resource_id = kv.get("resource_id")
        if not resource_id:
            continue

        derived = _derive_state(kv)
        if derived is None:
            continue
        present, state_signal = derived

        system_id = kv.get("service")
        if not system_id:
            continue

        collector = _collect_identifiers(kv)

        records.append(
            ParsedRecord(
                file_id=file_id,
                system_id=system_id,
                resource_id=resource_id,
                data_category=None,
                observed_at=observed_at,
                present=present,
                identifiers=collector.frozen(),
                state_signal=state_signal,
                raw=dict(kv),
            )
        )

    return records
