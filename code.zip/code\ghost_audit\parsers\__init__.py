"""Multimodal evidence parsers for the deletion-audit pipeline.

Each parser reads one evidence format and returns ``list[ParsedRecord]``
(see :mod:`ghost_audit.models`). The :mod:`ghost_audit.parsers.dispatch`
module selects the appropriate parser for an :class:`EvidenceFile` based on
its file extension and filename, records parse failures by ``file_id``, and
continues processing remaining evidence (Requirement 4.5).

The individual format parsers live in sibling modules:

- :mod:`ghost_audit.parsers.handover` -- plain-text handover records
- :mod:`ghost_audit.parsers.logs` -- ``key=value`` lookup-trace logs
- :mod:`ghost_audit.parsers.json_records` -- JSON snapshot bundles/exports
- :mod:`ghost_audit.parsers.sql` -- SQLite-compatible ``.sql`` snapshots
- ``ghost_audit.parsers.pdf`` / ``ghost_audit.parsers.image`` (optional)
"""

from __future__ import annotations

from .dispatch import dispatch_parse, parse_all

__all__ = ["dispatch_parse", "parse_all"]
