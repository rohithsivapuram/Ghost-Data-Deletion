# Usage and Cost Report

Providers/models used: none (deterministic run)

This run made no model calls; all decisions were produced by the deterministic pipeline.

## Overall Totals

- Model calls: 0
- Input tokens: 0
- Output tokens: 0
- Total tokens: 0
- Cases: 518
- Average tokens per case: 0
- Estimated total cost: $0.00
- Estimated per-case cost: $0.00
