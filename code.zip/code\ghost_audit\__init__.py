"""Ghost Data Deletion-Audit Agent package.

A deterministic-first, LLM-optional pipeline that audits deletion requests
and emits an ordered steps plan per case. See design.md for architecture.
"""
