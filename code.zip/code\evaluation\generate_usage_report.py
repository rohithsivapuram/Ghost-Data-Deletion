"""Usage-report generator for the final full-dataset run (Requirements 18.1-18.7).

Runs the deterministic deletion-audit pipeline over every case in
``dataset/deletion_requests.csv`` and writes ``code/evaluation/usage_report.md``
so the figures reflect the same final run that produces ``output.csv`` -- never
hand-edited numbers.

Reuse, not reinvention
----------------------

This helper does not re-implement any report rendering. It constructs a single
:class:`ghost_audit.usage.UsageReporter`, sets the case count to the number of
loaded requests (518 for the full set), runs
:func:`ghost_audit.pipeline.run` with that reporter so any model calls are
recorded, and then calls :meth:`UsageReporter.write_report`. On the default
deterministic engine the pipeline makes zero model calls, so the report states
zero calls, zero tokens, ``$0.00`` total/per-case cost, and
``none (deterministic run)`` for providers/models (Requirement 18.1), while
still reporting the case count and per-case averages (Requirements 18.3-18.6).

This mirrors the wiring already present in ``code/main.py`` so the usage report
can be regenerated independently of a full output write, consistent with task
19.1's ``generate_evaluation_report.py``.

Secrets
-------

Engine/config and any credentials are read only from the environment by the
pipeline (Requirements 15.3, 15.4). The report contains only aggregate counts,
token totals, cost, provider/model names, and the case count -- never API keys,
credentials, or sensitive configuration (Requirement 18.7).

Usage (from the repository root)::

    py code/evaluation/generate_usage_report.py
    py code/evaluation/generate_usage_report.py --root .
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Make the ``code/`` package directory importable when run directly.
_CODE_DIR = Path(__file__).resolve().parents[1]
if str(_CODE_DIR) not in sys.path:
    sys.path.insert(0, str(_CODE_DIR))

from ghost_audit import loaders, pipeline  # noqa: E402
from ghost_audit.usage import UsageReporter  # noqa: E402

_DEFAULT_ROOT = _CODE_DIR.parent
_REPORT_PATH = _CODE_DIR / "evaluation" / "usage_report.md"


def generate_report(root: Path, report_path: Path = _REPORT_PATH) -> UsageReporter:
    """Run the final pipeline and write ``usage_report.md``; return the reporter.

    Loads every request under ``root`` to set the authoritative case count,
    runs the full pipeline with a shared :class:`UsageReporter` so any model
    calls are recorded, then writes the Markdown report. Returns the reporter so
    callers (and the CLI) can print or assert on the measured figures.
    """
    root = Path(root).resolve()

    # Load the full request list to set the authoritative case count (518 for
    # the full set) used for per-case averages (Requirements 18.4-18.6).
    requests = loaders.load_requests(root)

    usage = UsageReporter()
    usage.set_case_count(len(requests))

    # Run the full pipeline with the shared reporter. The deterministic engine
    # (default) records zero calls; an LLM-assisted engine would record real
    # calls here via UsageReporter.record_call.
    engine = pipeline.select_engine()
    pipeline.run(root, engine=engine, usage=usage)

    usage.write_report(Path(report_path))
    return usage


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="ghost-audit-usage-report",
        description="Generate code/evaluation/usage_report.md for the final run.",
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=_DEFAULT_ROOT,
        help="Repository root containing dataset/ (default: parent of code/).",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    """CLI entry point: regenerate the report and print a short summary."""
    args = _parse_args(argv)
    usage = generate_report(Path(args.root).resolve())
    print("Usage report written to code/evaluation/usage_report.md")
    print(f"  Model calls:  {usage.total_calls}")
    print(f"  Total tokens: {usage.total_tokens}")
    print(f"  Est. cost:    ${usage.total_cost:.2f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
