"""State reconstructor (Requirements 5.1-5.4, 7.1, 7.2).

This module turns the closest-to-``audit_at`` :class:`ParsedRecord` selected per
resource (the output of :func:`ghost_audit.evidence.select_closest`) into one
immutable :class:`RecordState` per relevant resource. Each ``RecordState``
captures the resource's true state at ``audit_at``: whether it is present, which
of the subject's direct identifiers are still exposed, the observed treatment,
whether an active data flow or an unblocked restore path can recreate data, and
the ``proving_evidence_id`` that established the state.

Claims are never treated as proof (Requirement 5.2): this function consumes only
``ParsedRecord`` instances derived from *evidence*. The case's
``reported_status`` and every ``system_activity.csv`` ``reported_result`` are
excluded here by construction -- they are never passed into ``matched`` -- so a
record's state is only ever grounded in parsed evidence files.

Time-gating (Requirement 5.3): ``matched`` already comes from
:func:`ghost_audit.evidence.select_closest`, which keeps only observations with
``observed_at <= audit_at``. As defense in depth this function additionally skips
any record whose ``observed_at`` is strictly after ``audit_at`` so that no
observation later than ``audit_at`` can ever contribute a ``RecordState``.
"""

from __future__ import annotations

from datetime import datetime

from .models import ParsedRecord, RecordState, ResolvedIdentity, ResourceKey

__all__ = [
    "SYSTEM_CATEGORY",
    "reconstruct_state",
]

# Fallback mapping from ``system_id`` to a policy ``data_category`` used only
# when a parsed record does not carry its own ``data_category``. Grounded in the
# systems represented across the dataset's evidence (Requirement 5.4).
SYSTEM_CATEGORY: dict[str, str] = {
    "account_service": "USER_PROFILE",
    "search_service": "SEARCH_INDEX_ENTRY",
    "analytics_platform": "ANALYTICS_PROFILE",
    "support_platform": "SUPPORT_MESSAGE",
    "export_service": "USER_EXPORT",
    "integration_service": "DATA_FLOW",
    "backup_service": "BACKUP_ARCHIVE",
    "security_service": "SECURITY_AUDIT_LOG",
    "identity_service": "ACCOUNT_TOMBSTONE",
}

# Raw state signals that map to an observed treatment on the record. Any other
# signal (FOUND, IDENTIFIABLE, ACTIVE, DISABLED, BLOCKED, ...) leaves the record
# untreated ("NONE").
_TREATMENT_BY_SIGNAL: dict[str, str] = {
    "ANONYMIZED": "ANONYMIZED",
    "REDACTED": "REDACTED",
    "NOT_FOUND": "DELETED",
}


def _subject_direct_identifiers(identity: ResolvedIdentity) -> frozenset[str]:
    """Return the subject's DIRECT identifiers, EXCLUDING the bare ``user_id``.

    Direct identifiers are the values policy requires to be removed from a
    redacted/anonymized record or an account tombstone: emails, email hashes,
    phones, and names. The stable ``user_id`` is intentionally excluded because
    a correctly redacted tombstone legitimately keeps the ``user_id`` and must
    not be reported as exposed PII (Requirements 6.5, 7.2).
    """
    return (
        identity.emails
        | identity.email_hashes
        | identity.phones
        | identity.names
    )


def _data_category(record: ParsedRecord) -> str:
    """Resolve a record's data category, falling back to a system-based map.

    Prefers the record's own ``data_category`` when set; otherwise maps by
    ``system_id`` via :data:`SYSTEM_CATEGORY`. Unknown systems leave the category
    empty rather than guessing.
    """
    if record.data_category:
        return record.data_category
    return SYSTEM_CATEGORY.get(record.system_id, "")


def _is_data_flow(record: ParsedRecord, category: str) -> bool:
    """True when the record describes a connector/data-flow resource."""
    return record.system_id == "integration_service" or category == "DATA_FLOW"


def _is_backup_archive(record: ParsedRecord, category: str) -> bool:
    """True when the record describes a backup archive / restore path."""
    return record.system_id == "backup_service" or category == "BACKUP_ARCHIVE"


def reconstruct_state(
    matched: dict[ResourceKey, ParsedRecord],
    identity: ResolvedIdentity,
    audit_at: datetime,
) -> list[RecordState]:
    """Reconstruct one :class:`RecordState` per relevant resource at ``audit_at``.

    ``matched`` maps each :class:`ResourceKey` to the single closest-to-
    ``audit_at`` :class:`ParsedRecord` for that resource (the output of
    :func:`ghost_audit.evidence.select_closest`). For each such record this
    produces a ``RecordState`` capturing the resource's true state at
    ``audit_at``.

    Only evidence-derived records are consumed here; ``reported_status`` and
    ``system_activity.csv`` ``reported_result`` are excluded by construction and
    never establish state (Requirement 5.2). Any record whose ``observed_at`` is
    strictly after ``audit_at`` is skipped as defense in depth so no later
    observation contributes to the result (Requirement 5.3).

    The returned list is sorted by ``(system_id, resource_id)`` for stable,
    order-independent downstream processing.
    """
    subject_ids = _subject_direct_identifiers(identity)
    states: list[RecordState] = []

    for record in matched.values():
        # Defensive audit_at gate (Requirement 5.3): never let a later
        # observation contribute a RecordState, even though select_closest
        # should already have excluded it.
        if record.observed_at > audit_at:
            continue

        category = _data_category(record)

        # Exposed direct identifiers: the subject's email/hash/phone/name values
        # that still appear on the record. The bare user_id is excluded so a
        # compliant tombstone (user_id only) reports no exposed PII.
        exposed = record.identifiers & subject_ids

        # Observed treatment derived from the raw state signal.
        treatment = _TREATMENT_BY_SIGNAL.get(record.state_signal, "NONE")

        # Active data flow: an integration/connector resource reporting ACTIVE
        # at audit_at can recreate data (Requirement 7.1). Backups are tracked
        # by is_restore_risk instead, not here.
        is_active_flow = (
            record.state_signal == "ACTIVE" and _is_data_flow(record, category)
        )

        # Unblocked restore: a backup archive reporting ACTIVE at audit_at can
        # restore deleted data (Requirement 7.2). A BLOCKED backup is not a risk.
        is_restore_risk = (
            record.state_signal == "ACTIVE"
            and _is_backup_archive(record, category)
        )

        states.append(
            RecordState(
                system_id=record.system_id,
                resource_id=record.resource_id,
                data_category=category,
                present=record.present,
                exposed_identifiers=exposed,
                treatment=treatment,
                is_active_flow=is_active_flow,
                is_restore_risk=is_restore_risk,
                proving_evidence_id=record.file_id,
            )
        )

    states.sort(key=lambda s: (s.system_id, s.resource_id))
    return states
