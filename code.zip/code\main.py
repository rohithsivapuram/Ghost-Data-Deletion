"""Terminal entry point for the Ghost Data deletion-audit agent.

Runs the full deterministic pipeline over ``dataset/deletion_requests.csv``,
writes ``output.csv`` at the repository root, validates the output against the
contract, writes a usage report, and logs the run to ``log.txt`` per AGENTS.md
(Requirements 15.1, 15.2, 15.5, 19.1, 19.2).

Usage
-----

From the repository root::

    py code/main.py            # full run over all 518 cases
    py code/main.py --root .   # explicit repo root

Configuration and secrets are read only from environment variables
(Requirement 15.3): ``ENGINE`` (default ``deterministic``), ``LLM_PROVIDER``,
``LLM_MODEL``, plus ``KIRO_TOOL`` for the log ``tool=`` value. No secret value
is ever printed or written to any artifact (Requirement 15.4).

Paths are resolved relative to the repository root -- by default the parent of
this ``code/`` directory -- so the agent runs identically on macOS, Linux, and
Windows (Requirement 15.5).
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# Ensure the package directory (this file's directory) is importable when the
# script is run directly as ``py code/main.py`` from the repo root.
_CODE_DIR = Path(__file__).resolve().parent
if str(_CODE_DIR) not in sys.path:
    sys.path.insert(0, str(_CODE_DIR))

from ghost_audit import loaders, pipeline, serialize, validate  # noqa: E402
from ghost_audit.logging_util import TurnEntry, log_session_start, log_turn  # noqa: E402
from ghost_audit.usage import UsageReporter  # noqa: E402

# Default repository root: the parent of the ``code/`` directory.
_DEFAULT_ROOT = _CODE_DIR.parent

# Where the usage report for this run is written (refined further by task 19.2).
_USAGE_REPORT_PATH = _CODE_DIR / "evaluation" / "usage_report.md"


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse command-line arguments for the entry point."""
    parser = argparse.ArgumentParser(
        prog="ghost-audit",
        description="Audit deletion requests and write output.csv at the repo root.",
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=_DEFAULT_ROOT,
        help="Repository root containing dataset/ (default: parent of code/).",
    )
    parser.add_argument(
        "--sample",
        action="store_true",
        help="Optional: run over sample_deletion_requests.csv instead of the full set.",
    )
    return parser.parse_args(argv)


def _resolve_tool_and_model() -> tuple[str, str]:
    """Resolve non-empty ``tool`` and ``model`` identifiers for logging.

    Both are read from the environment with safe, non-empty defaults so the log
    entry always carries a populated ``tool=`` and ``model=`` line
    (Requirement 19.3). The deterministic engine uses the model name
    ``deterministic`` when ``LLM_MODEL`` is unset.
    """
    tool = (os.environ.get("KIRO_TOOL") or "ghost-audit").strip() or "ghost-audit"
    model = (os.environ.get("LLM_MODEL") or "deterministic").strip() or "deterministic"
    return tool, model


def main(argv: list[str] | None = None) -> int:
    """Run the pipeline end to end and return a process exit code."""
    args = _parse_args(argv)
    root = Path(args.root).resolve()
    tool, model = _resolve_tool_and_model()

    # Log the start of this runtime session (Requirement 19.1).
    log_session_start(root, tool=tool, model=model)

    # Load the full request list up front so we can guarantee one row per case
    # and set the usage case count.
    requests = loaders.load_requests(root)
    case_ids = [case.case_id for case in requests]

    usage = UsageReporter()
    usage.set_case_count(len(requests))

    # Select the engine from the environment (deterministic by default).
    engine = pipeline.select_engine()

    # Run the full pipeline (parses evidence once, processes every case).
    results = pipeline.run(root, engine=engine, usage=usage)

    # Guarantee exactly one row per case_id, filling any gap with a safe default
    # (Requirements 11.2, 15.2), then write output.csv at the repo root.
    rows = serialize.build_rows(results, case_ids)
    serialize.write_output(rows, root)
    output_path = root / "output.csv"

    # Validate the produced output against the contract (Requirement 12.*).
    violations = validate.validate_output(root, requests)

    # Write the usage report for this run (deterministic => zero calls).
    usage.write_report(_USAGE_REPORT_PATH)

    # Summarize status distribution for the operator.
    status_counts: dict[str, int] = {}
    for row in rows:
        status_counts[row.deletion_status] = (
            status_counts.get(row.deletion_status, 0) + 1
        )

    print(f"Processed {len(rows)} cases.")
    print(f"Wrote {output_path}")
    print(
        "Status distribution: "
        + ", ".join(f"{k}={status_counts.get(k, 0)}" for k in sorted(status_counts))
    )
    print(f"Usage report: {_USAGE_REPORT_PATH}")
    if violations:
        print(f"Validation: {len(violations)} violation(s) found:")
        for violation in violations[:20]:
            print(
                f"  - case={violation.case_id or '<file>'} "
                f"check={violation.check}: {violation.detail}"
            )
        if len(violations) > 20:
            print(f"  ... and {len(violations) - 20} more")
    else:
        print("Validation: OK (0 violations)")

    # Append a per-turn log entry summarizing the run (Requirement 19.2).
    summary = (
        f"Ran the deletion-audit pipeline over {len(rows)} cases and wrote "
        f"output.csv at the repo root. Validator reported {len(violations)} "
        f"violation(s)."
    )
    actions = [
        f"ran pipeline.run over {len(rows)} cases",
        f"wrote {output_path}",
        f"validated output ({len(violations)} violations)",
        f"wrote usage report {_USAGE_REPORT_PATH}",
    ]
    log_turn(
        root,
        TurnEntry(
            title="Full deletion-audit run",
            user_prompt="(automated run) py code/main.py",
            response_summary=summary,
            actions=actions,
            tool=tool,
            model=model,
        ),
    )

    # A clean run always produces valid rows; surface validation failures via a
    # non-zero exit code so CI can catch a broken contract.
    return 0 if not violations else 1


if __name__ == "__main__":
    raise SystemExit(main())
