"""Optional PDF evidence parser (task 7.7).

PDF documents in this dataset are ordinary business artifacts (invoices,
account-history reports, handover documents, legal-retention registers,
screenshots exported as PDF). They do not carry an explicit deletion verdict,
and the deterministic reconstruction pipeline does not depend on them, so this
parser is intentionally best-effort (Requirement 4.3): it extracts any
identifiers it can recover from the raw PDF bytes and otherwise degrades to
"no facts extracted" by returning ``[]`` (Requirement 4.5).

Design constraints:

- **Zero required third-party dependencies.** The default deterministic path
  must keep working with a plain CPython install, so this module performs a
  best-effort text recovery directly from the raw PDF bytes without importing
  any PDF library at module load.
- **Optional library fallback.** If ``pypdf`` happens to be importable it is
  used inside a guarded ``try``/``except`` for better extraction; it is never
  hard-imported, so a missing library is not an error.
- **Optional OCR / LLM fallback.** True rendering/OCR of scanned PDFs is wired
  through the Engine abstraction (task 16.3), not here. When neither the raw
  text recovery nor an optional library yields usable text, this parser returns
  ``[]`` rather than raising.
- **Never raises.** All extraction work is wrapped so a malformed or encrypted
  PDF produces ``[]`` and is treated by the dispatcher as "no facts", never as
  a hard parse failure.

Facts are modeled as :class:`~ghost_audit.models.ParsedRecord`s only when a
usable identifier (email / email-hash / opaque reference) is recovered; a
document that yields no identifiers produces no records. The records are
grounded: ``present=True`` with ``state_signal="FOUND"`` means "an identifier
of this subject appears in a retained business document", which is exactly the
kind of lingering copy the audit cares about. ``resource_id`` is derived from
the document filename so every record from one file shares a stable key.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path

from ..models import ParsedRecord
from ._common import IdentifierCollector, looks_like_email

__all__ = ["parse_pdf"]

# A PDF ``system_id`` so document-sourced findings are attributable but never
# collide with the live-system identifiers used by the structured parsers.
_PDF_SYSTEM_ID = "document_store"
_PDF_DATA_CATEGORY = "BUSINESS_DOCUMENT"

# Email / email-hash token patterns recovered from decoded PDF text.
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
# 32+ hex chars -> likely an email_hash (sha-256 style) used across the dataset.
_HASH_RE = re.compile(r"\b[0-9a-fA-F]{32,}\b")
# Opaque subject references such as ``user_39`` / ``customer_204``.
_REFERENCE_RE = re.compile(r"\b(?:user|customer|account)_[0-9]+\b")

# A ``YYYYMMDD`` date embedded in the document filename (e.g.
# ``account_history_report_20260718.pdf``). Document files are not timestamped
# internally, so the filename date is used as the observation time.
_FILENAME_DATE_RE = re.compile(r"(20\d{2})(\d{2})(\d{2})")

# Parenthesized string tokens in a raw (uncompressed) PDF content stream, e.g.
# ``(jane.doe@example.com) Tj``. This recovers text from simple PDFs whose
# streams are not Flate-compressed, with no third-party dependency.
_PDF_PAREN_TOKEN_RE = re.compile(rb"\(((?:\\.|[^\\()])*)\)")


def _recover_text_from_bytes(data: bytes) -> str:
    """Best-effort recover latin text from raw PDF bytes, dependency-free.

    Extracts parenthesized string tokens from uncompressed content streams and
    joins them. Flate-compressed streams will not yield readable text here; that
    is acceptable because the deterministic pipeline does not rely on PDF text
    and this parser degrades to "no facts extracted".
    """
    pieces: list[str] = []
    for match in _PDF_PAREN_TOKEN_RE.finditer(data):
        token = match.group(1)
        # Unescape the common PDF string escapes, then decode leniently.
        token = token.replace(rb"\(", b"(").replace(rb"\)", b")")
        token = token.replace(rb"\\", b"\\")
        try:
            pieces.append(token.decode("latin-1"))
        except (UnicodeDecodeError, ValueError):
            continue
    return " ".join(pieces)


def _recover_text_optional_lib(path: Path) -> str:
    """Try an optional ``pypdf`` extraction; return ``""`` if unavailable.

    ``pypdf`` is imported lazily inside this function so the module never hard-
    depends on it. Any import or extraction failure yields ``""``.
    """
    try:
        import pypdf  # type: ignore[import-not-found]
    except Exception:
        return ""
    try:
        reader = pypdf.PdfReader(str(path))
        return "\n".join((page.extract_text() or "") for page in reader.pages)
    except Exception:
        return ""


def _observed_at_from_filename(path: Path) -> datetime | None:
    """Recover an observation time from a ``YYYYMMDD`` date in the filename.

    Returns a timezone-aware UTC ``datetime`` at midnight, or ``None`` when the
    filename carries no parseable date. Document PDFs are not timestamped
    internally, so the filename date is the only grounded observation time.
    """
    match = _FILENAME_DATE_RE.search(path.name)
    if not match:
        return None
    year, month, day = (int(g) for g in match.groups())
    try:
        return datetime(year, month, day, tzinfo=timezone.utc)
    except ValueError:
        return None


def _collect_identifiers(text: str) -> IdentifierCollector:
    """Pull emails, hashes, and opaque references out of recovered text."""
    collector = IdentifierCollector()
    for email in _EMAIL_RE.findall(text):
        collector.add_email(email)
    for token in _HASH_RE.findall(text):
        # Skip hex tokens that are actually part of an email local/domain part.
        if looks_like_email(token):
            continue
        collector.add_hash(token)
    for ref in _REFERENCE_RE.findall(text):
        collector.add_reference(ref)
    return collector


def parse_pdf(path: Path, file_id: str) -> list[ParsedRecord]:
    """Parse a PDF document into :class:`ParsedRecord`s (best-effort).

    Attempts a dependency-free text recovery from the raw PDF bytes, then falls
    back to an optional ``pypdf`` extraction if that library is installed. Any
    recovered emails / email-hashes / opaque references become a single
    ``FOUND`` record keyed by the document filename. If no usable text or
    identifiers can be recovered, returns ``[]`` ("no facts extracted").

    This function is deterministic and never raises; every failure path degrades
    to ``[]`` so the dispatcher treats an unreadable PDF as "no facts" rather
    than a parse failure (Requirements 4.3, 4.5).

    Args:
        path: Filesystem path to the ``.pdf`` evidence file.
        file_id: Manifest ``file_id`` to stamp on any extracted record.

    Returns:
        A list with at most one :class:`ParsedRecord` (empty when no identifier
        is recovered).
    """
    try:
        path = Path(path)
        try:
            data = path.read_bytes()
        except OSError:
            return []

        text = _recover_text_from_bytes(data)
        collector = _collect_identifiers(text)
        if not collector.frozen():
            # Fall back to an optional library only when the cheap path found
            # nothing usable.
            lib_text = _recover_text_optional_lib(path)
            if lib_text:
                collector = _collect_identifiers(lib_text)

        identifiers = collector.frozen()
        if not identifiers:
            # No facts extracted; degrade gracefully (Requirement 4.5).
            return []

        observed_at = _observed_at_from_filename(path)
        if observed_at is None:
            # Without a grounded observation time the fact cannot be placed on
            # the audit timeline; treat as "no facts extracted" rather than
            # emitting an untimed record that downstream gating cannot compare.
            return []

        resource_id = path.stem or file_id
        return [
            ParsedRecord(
                file_id=file_id,
                system_id=_PDF_SYSTEM_ID,
                resource_id=resource_id,
                data_category=_PDF_DATA_CATEGORY,
                observed_at=observed_at,
                present=True,
                identifiers=identifiers,
                state_signal="FOUND",
                raw={"source": "pdf", "filename": path.name},
            )
        ]
    except Exception:
        # Never raise: a malformed/encrypted PDF yields "no facts extracted".
        return []
