"""Normalization helpers shared across the pipeline.

Identifiers such as emails and names are compared after a language-agnostic
normalization so that matching applies the same criteria regardless of the
original casing or accents (Requirements 1.3, 2.4).

The normalization is intentionally simple and deterministic:

- Unicode-normalize to NFKD, then strip combining marks (accent removal).
- Casefold for aggressive, locale-independent lowercasing.
- Collapse surrounding/interior whitespace for names.

These helpers are pure functions with no side effects so they are safe to use
anywhere identifiers need a canonical form.
"""

from __future__ import annotations

import unicodedata

__all__ = [
    "strip_accents",
    "normalize_text",
    "normalize_email",
    "normalize_name",
]


def strip_accents(value: str) -> str:
    """Remove accent/diacritic marks from ``value``.

    Decomposes characters to NFKD form and drops the combining marks, so
    ``"José"`` becomes ``"Jose"`` and ``"Müller"`` becomes ``"Muller"``.
    """
    decomposed = unicodedata.normalize("NFKD", value)
    return "".join(ch for ch in decomposed if not unicodedata.combining(ch))


def normalize_text(value: str) -> str:
    """Casefold and strip accents from arbitrary text.

    Leading/trailing whitespace is removed. This is the base routine used by
    the more specific email/name normalizers.
    """
    if value is None:
        return ""
    return strip_accents(value).casefold().strip()


def normalize_email(value: str) -> str:
    """Normalize an email address for case-insensitive comparison.

    Emails are compared case-insensitively (Requirement 2 identity matching).
    Accents are stripped and the whole value is casefolded. Surrounding
    whitespace is removed; interior whitespace is removed as well since valid
    email addresses never contain spaces.
    """
    if value is None:
        return ""
    normalized = normalize_text(value)
    return "".join(normalized.split())


def normalize_name(value: str) -> str:
    """Normalize a person's name for matching.

    Accents are stripped, the value is casefolded, and runs of interior
    whitespace are collapsed to a single space so that ``"  José   Pérez "``
    and ``"Jose Perez"`` compare equal.
    """
    if value is None:
        return ""
    normalized = normalize_text(value)
    return " ".join(normalized.split())
