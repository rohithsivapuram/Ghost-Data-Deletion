"""Unit tests for identity resolution (Requirement 2).

Covers:
- current-email match resolves the correct ``user_id`` (Requirement 2.1)
- historical-email match (email present only in ``user_audit_log.csv``
  ``old_value``) resolves the SAME ``user_id`` the current snapshot assigns
  (Requirements 2.1, 2.3)
- audit_at identifier gating: an identifier changed after ``audit_at`` is
  excluded; one changed at/before ``audit_at`` is included (Requirement 2.4)
- no-match case returns ``None`` (Requirement 2.5)

Fixtures are built in-memory from the typed models so the tests exercise the
resolver's logic precisely without depending on the full dataset.
"""

from datetime import datetime, timezone

from ghost_audit.identity import resolve_identity
from ghost_audit.models import (
    AuditLogEntry,
    Case,
    IdentitySnapshot,
    IdentityStore,
)
from ghost_audit.normalize import normalize_email


def _ts(year: int, month: int, day: int) -> datetime:
    """Build a timezone-aware UTC timestamp."""
    return datetime(year, month, day, tzinfo=timezone.utc)


def _case(email: str, audit_at: datetime) -> Case:
    """Build a minimal Case with only the fields the resolver reads."""
    return Case(
        case_id="case_1",
        email=email,
        requested_at=_ts(2026, 1, 1),
        reported_status="COMPLETE",
        reported_at=_ts(2026, 1, 1),
        audit_at=audit_at,
        request_text="Please delete my account.",
    )


def _snapshot(
    user_id: str,
    name: str = "Jane Doe",
    email: str = "jane@example.com",
    phone: str = "+100000000",
    email_hash: str = "hashjane",
    updated_at: datetime | None = None,
) -> IdentitySnapshot:
    return IdentitySnapshot(
        user_id=user_id,
        name=name,
        email=email,
        phone=phone,
        email_hash=email_hash,
        updated_at=updated_at or _ts(2026, 1, 1),
    )


class TestCurrentEmailMatch:
    """Requirement 2.1: match the Case email against the current snapshot."""

    def test_current_email_resolves_correct_user_id(self):
        store = IdentityStore(
            snapshots=(
                _snapshot("user_1", email="jane@example.com"),
                _snapshot("user_2", email="bob@example.com", email_hash="hashbob"),
            ),
            audit_log=(),
        )
        case = _case("jane@example.com", _ts(2026, 6, 1))

        resolved = resolve_identity(case, store)

        assert resolved is not None
        assert resolved.user_id == "user_1"
        assert "jane@example.com" in resolved.emails

    def test_current_email_match_is_case_insensitive(self):
        store = IdentityStore(
            snapshots=(_snapshot("user_1", email="Jane@Example.com"),),
            audit_log=(),
        )
        case = _case("JANE@EXAMPLE.COM", _ts(2026, 6, 1))

        resolved = resolve_identity(case, store)

        assert resolved is not None
        assert resolved.user_id == "user_1"

    def test_email_hash_match_resolves_user_id(self):
        store = IdentityStore(
            snapshots=(
                _snapshot("user_1", email="jane@example.com", email_hash="ABC123"),
            ),
            audit_log=(),
        )
        # The Case "email" value is actually the hash; it still resolves.
        case = _case("abc123", _ts(2026, 6, 1))

        resolved = resolve_identity(case, store)

        assert resolved is not None
        assert resolved.user_id == "user_1"
        assert "abc123" in resolved.email_hashes


class TestHistoricalEmailMatch:
    """Requirements 2.1, 2.3: historical match resolves the same user_id."""

    def test_historical_old_value_resolves_same_user_id(self):
        # Current snapshot email is 'new@example.com'; the subject previously
        # used 'old@example.com', recorded as an audit-log old_value.
        snapshot = _snapshot("user_42", email="new@example.com")
        audit = AuditLogEntry(
            audit_id="audit_1",
            user_id="user_42",
            event_time=_ts(2026, 3, 1),
            field_name="email",
            old_value="old@example.com",
            new_value="new@example.com",
        )
        store = IdentityStore(snapshots=(snapshot,), audit_log=(audit,))

        # The request arrives under the OLD email only.
        case = _case("old@example.com", _ts(2026, 6, 1))

        resolved = resolve_identity(case, store)

        assert resolved is not None
        # Must resolve the SAME user_id the current snapshot assigns.
        assert resolved.user_id == "user_42"
        # Both current and historical emails are compiled (both <= audit_at).
        assert normalize_email("old@example.com") in resolved.emails
        assert normalize_email("new@example.com") in resolved.emails

    def test_historical_match_when_no_other_snapshot_field_matches(self):
        # Ensure the subject is found purely via the audit-log history even when
        # another decoy subject exists.
        snapshots = (
            _snapshot("user_1", email="current@example.com"),
            _snapshot("decoy", email="decoy@example.com", email_hash="decoyhash"),
        )
        audit = AuditLogEntry(
            audit_id="audit_9",
            user_id="user_1",
            event_time=_ts(2026, 2, 1),
            field_name="email",
            old_value="ancient@example.com",
            new_value="current@example.com",
        )
        store = IdentityStore(snapshots=snapshots, audit_log=(audit,))
        case = _case("ancient@example.com", _ts(2026, 6, 1))

        resolved = resolve_identity(case, store)

        assert resolved is not None
        assert resolved.user_id == "user_1"


class TestAuditAtGating:
    """Requirement 2.4: only identifiers with event_time <= audit_at included."""

    def test_identifier_changed_after_audit_at_is_excluded(self):
        # Snapshot (current) phone was updated AFTER audit_at, so the current
        # phone must be excluded; the historical phone (changed before) included.
        snapshot = _snapshot(
            "user_7",
            email="person@example.com",
            phone="+1999NEW",
            updated_at=_ts(2026, 9, 1),  # after audit_at
        )
        phone_change = AuditLogEntry(
            audit_id="audit_p",
            user_id="user_7",
            event_time=_ts(2026, 9, 1),  # change happened AFTER audit_at
            field_name="phone",
            old_value="+1000OLD",
            new_value="+1999NEW",
        )
        store = IdentityStore(snapshots=(snapshot,), audit_log=(phone_change,))
        # audit_at is BEFORE the phone change and snapshot update.
        case = _case("person@example.com", _ts(2026, 6, 1))

        resolved = resolve_identity(case, store)

        assert resolved is not None
        assert resolved.user_id == "user_7"
        # The new phone (changed after audit_at) must NOT be present.
        assert "+1999NEW" not in resolved.phones
        # The old phone's change event_time is also after audit_at, so it is
        # excluded as well: no phone identifier should be compiled at all.
        assert resolved.phones == frozenset()

    def test_identifier_changed_at_or_before_audit_at_is_included(self):
        snapshot = _snapshot(
            "user_8",
            email="who@example.com",
            phone="+1CURRENT",
            updated_at=_ts(2026, 1, 1),  # at/before audit_at
        )
        phone_change = AuditLogEntry(
            audit_id="audit_q",
            user_id="user_8",
            event_time=_ts(2026, 2, 1),  # change at/before audit_at
            field_name="phone",
            old_value="+1PRIOR",
            new_value="+1CURRENT",
        )
        store = IdentityStore(snapshots=(snapshot,), audit_log=(phone_change,))
        case = _case("who@example.com", _ts(2026, 6, 1))

        resolved = resolve_identity(case, store)

        assert resolved is not None
        # Both the prior and current phone values were valid at/before audit_at.
        assert "+1PRIOR" in resolved.phones
        assert "+1CURRENT" in resolved.phones

    def test_snapshot_values_excluded_when_snapshot_updated_after_audit_at(self):
        # The entire current snapshot was updated after audit_at; none of its
        # current values should be compiled, but the subject still resolves via
        # its (earlier) historical email change.
        snapshot = _snapshot(
            "user_9",
            name="Current Name",
            email="current@example.com",
            email_hash="currenthash",
            updated_at=_ts(2026, 9, 1),  # after audit_at
        )
        email_change = AuditLogEntry(
            audit_id="audit_e",
            user_id="user_9",
            event_time=_ts(2026, 2, 1),  # before audit_at
            field_name="email",
            old_value="former@example.com",
            new_value="current@example.com",
        )
        store = IdentityStore(snapshots=(snapshot,), audit_log=(email_change,))
        case = _case("former@example.com", _ts(2026, 6, 1))

        resolved = resolve_identity(case, store)

        assert resolved is not None
        assert resolved.user_id == "user_9"
        # Historical emails (both before audit_at) are present.
        assert normalize_email("former@example.com") in resolved.emails
        assert normalize_email("current@example.com") in resolved.emails
        # The snapshot-only name was gated out (snapshot updated after audit_at).
        assert normalize_email("Current Name") not in resolved.names
        assert resolved.names == frozenset()


class TestNoMatch:
    """Requirement 2.5: unmatched email resolves to None."""

    def test_no_match_returns_none(self):
        store = IdentityStore(
            snapshots=(
                _snapshot("user_1", email="jane@example.com"),
                _snapshot("user_2", email="bob@example.com", email_hash="hashbob"),
            ),
            audit_log=(
                AuditLogEntry(
                    audit_id="audit_1",
                    user_id="user_1",
                    event_time=_ts(2026, 3, 1),
                    field_name="email",
                    old_value="janeold@example.com",
                    new_value="jane@example.com",
                ),
            ),
        )
        case = _case("nobody@example.com", _ts(2026, 6, 1))

        assert resolve_identity(case, store) is None

    def test_empty_store_returns_none(self):
        store = IdentityStore(snapshots=(), audit_log=())
        case = _case("anyone@example.com", _ts(2026, 6, 1))

        assert resolve_identity(case, store) is None
