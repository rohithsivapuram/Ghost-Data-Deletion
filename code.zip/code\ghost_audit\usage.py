"""Usage and cost reporter for the deletion-audit agent (Requirements 18.1-18.7).

The :class:`UsageReporter` records model calls during a run and writes a
Markdown ``usage_report.md`` summarizing the final full-dataset run that
produced ``output.csv``.

Deterministic runs
------------------

The default engine is deterministic and makes zero model calls. In that case
the report explicitly states zero calls, zero tokens, ``$0.00`` cost, and
``none (deterministic run)`` for providers/models (Requirement 18.1).

LLM-assisted runs
-----------------

When the optional LLM layer is enabled, :meth:`UsageReporter.record_call`
accumulates per-(provider, model) call counts and input/output tokens. The
report then states each provider and model used (Requirement 18.2), call
counts and input/output tokens (Requirement 18.3), total and average tokens per
case (Requirement 18.4), estimated total and per-case cost (Requirement 18.5),
and per-model plus overall totals (Requirement 18.6).

Cost model
----------

Cost is computed from a simple ``model -> (input_cost_per_1k, output_cost_per_1k)``
table. Unknown models default to ``(0.0, 0.0)`` so deterministic runs cost
``$0.00`` and unpriced models never inflate the estimate. Costs are summed over
all recorded calls.

Secrets
-------

The report contains only aggregate counts, token totals, cost, and
provider/model names -- never API keys, credentials, or sensitive configuration
(Requirement 18.7).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

__all__ = ["ModelUsage", "UsageReporter", "DEFAULT_COST_PER_1K"]


# model name -> (input_cost_per_1k_tokens, output_cost_per_1k_tokens) in USD.
# Unknown/deterministic models fall back to the zero-cost default below.
DEFAULT_COST_PER_1K: dict[str, tuple[float, float]] = {}

# Fallback cost for any model not present in the cost table.
_ZERO_COST = (0.0, 0.0)


@dataclass
class ModelUsage:
    """Accumulated usage for a single (provider, model) pair."""

    provider: str
    model: str
    calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens


class UsageReporter:
    """Records model-call usage and writes a Markdown usage report."""

    def __init__(
        self, cost_per_1k: dict[str, tuple[float, float]] | None = None
    ) -> None:
        # Keyed by (provider, model) to keep per-model/provider totals distinct.
        self._usage: dict[tuple[str, str], ModelUsage] = {}
        self._cases: int = 0
        self._cost_per_1k = (
            dict(DEFAULT_COST_PER_1K) if cost_per_1k is None else dict(cost_per_1k)
        )

    # --- recording ----------------------------------------------------------

    def record_call(
        self, provider: str, model: str, in_tok: int, out_tok: int
    ) -> None:
        """Record a single model call's provider, model, and token counts."""
        key = (provider, model)
        usage = self._usage.get(key)
        if usage is None:
            usage = ModelUsage(provider=provider, model=model)
            self._usage[key] = usage
        usage.calls += 1
        usage.input_tokens += int(in_tok)
        usage.output_tokens += int(out_tok)

    def set_case_count(self, n: int) -> None:
        """Set the number of cases in the run, used for per-case averages."""
        self._cases = int(n)

    # --- aggregates ---------------------------------------------------------

    @property
    def total_calls(self) -> int:
        return sum(u.calls for u in self._usage.values())

    @property
    def total_input_tokens(self) -> int:
        return sum(u.input_tokens for u in self._usage.values())

    @property
    def total_output_tokens(self) -> int:
        return sum(u.output_tokens for u in self._usage.values())

    @property
    def total_tokens(self) -> int:
        return self.total_input_tokens + self.total_output_tokens

    def _model_cost(self, usage: ModelUsage) -> float:
        in_rate, out_rate = self._cost_per_1k.get(usage.model, _ZERO_COST)
        return (usage.input_tokens / 1000.0) * in_rate + (
            usage.output_tokens / 1000.0
        ) * out_rate

    @property
    def total_cost(self) -> float:
        return sum(self._model_cost(u) for u in self._usage.values())

    def _avg_tokens_per_case(self) -> float:
        if self._cases <= 0:
            return 0.0
        return self.total_tokens / self._cases

    def _cost_per_case(self) -> float:
        if self._cases <= 0:
            return 0.0
        return self.total_cost / self._cases

    # --- report -------------------------------------------------------------

    def _render(self) -> str:
        lines: list[str] = ["# Usage and Cost Report", ""]

        if self.total_calls == 0:
            # Deterministic run: zero calls reported explicitly (Req 18.1).
            lines += [
                "Providers/models used: none (deterministic run)",
                "",
                "This run made no model calls; all decisions were produced by the "
                "deterministic pipeline.",
                "",
                "## Overall Totals",
                "",
                "- Model calls: 0",
                "- Input tokens: 0",
                "- Output tokens: 0",
                "- Total tokens: 0",
                f"- Cases: {self._cases}",
                "- Average tokens per case: 0",
                "- Estimated total cost: $0.00",
                "- Estimated per-case cost: $0.00",
                "",
            ]
            return "\n".join(lines)

        # Providers/models used (Requirement 18.2).
        providers = sorted({u.provider for u in self._usage.values()})
        models = sorted({f"{u.provider}/{u.model}" for u in self._usage.values()})
        lines += [
            f"Providers used: {', '.join(providers)}",
            f"Models used: {', '.join(models)}",
            "",
        ]

        # Per-model totals table (Requirements 18.3, 18.6).
        lines += [
            "## Per-Model Totals",
            "",
            "| Provider | Model | Calls | Input Tokens | Output Tokens | "
            "Total Tokens | Cost (USD) |",
            "|---|---|---|---|---|---|---|",
        ]
        for key in sorted(self._usage.keys()):
            u = self._usage[key]
            lines.append(
                f"| {u.provider} | {u.model} | {u.calls} | {u.input_tokens} | "
                f"{u.output_tokens} | {u.total_tokens} | "
                f"${self._model_cost(u):.2f} |"
            )
        lines.append("")

        # Overall totals (Requirements 18.3, 18.4, 18.5, 18.6).
        lines += [
            "## Overall Totals",
            "",
            f"- Model calls: {self.total_calls}",
            f"- Input tokens: {self.total_input_tokens}",
            f"- Output tokens: {self.total_output_tokens}",
            f"- Total tokens: {self.total_tokens}",
            f"- Cases: {self._cases}",
            f"- Average tokens per case: {self._avg_tokens_per_case():.2f}",
            f"- Estimated total cost: ${self.total_cost:.2f}",
            f"- Estimated per-case cost: ${self._cost_per_case():.4f}",
            "",
        ]
        return "\n".join(lines)

    def write_report(self, path: Path) -> None:
        """Write the Markdown usage report to ``path`` (UTF-8, ``\\n``).

        For a deterministic run with zero recorded calls, the report states
        zero calls and ``$0.00`` cost (Requirement 18.1). Otherwise it reports
        the measured providers/models, call counts, token totals, averages, and
        estimated costs (Requirements 18.2-18.6). No secrets are written
        (Requirement 18.7).
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8", newline="\n") as handle:
            handle.write(self._render())
