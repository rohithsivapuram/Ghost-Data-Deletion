"""Unit tests for the serializer (``code/ghost_audit/serialize.py``).

These focused example-based tests cover the ``output.csv`` contract and the
``build_rows`` gap-filling behavior (Requirements 11.1, 11.2, 11.3, 15.2):

- ``write_output`` writes exactly the header ``case_id,deletion_status,steps_json``
  as the first line.
- A ``NOT_APPLICABLE`` :class:`CaseResult` with empty steps serializes its
  ``steps_json`` column as ``[]``.
- Rows are written sorted by ``case_id`` ascending.
- ``build_rows`` fills any ``case_id`` missing from ``results`` with a default
  ``NOT_APPLICABLE`` / ``[]`` :class:`CaseResult`.
"""

from __future__ import annotations

import csv

from ghost_audit.models import CaseResult, Step
from ghost_audit.serialize import build_rows, write_output


def _read_rows(path):
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.reader(handle))


class TestWriteOutputHeader:
    def test_first_line_is_exact_header(self, tmp_path):
        """The first line of ``output.csv`` is exactly the contract header."""
        write_output([], tmp_path)
        out = tmp_path / "output.csv"
        with out.open("r", encoding="utf-8", newline="") as handle:
            first_line = handle.readline().rstrip("\r\n")
        assert first_line == "case_id,deletion_status,steps_json"


class TestNotApplicableSerialization:
    def test_empty_steps_serialize_as_empty_json_array(self, tmp_path):
        """A NOT_APPLICABLE case with no steps writes ``[]`` in steps_json."""
        rows = [
            CaseResult(case_id="case_01", deletion_status="NOT_APPLICABLE", steps=())
        ]
        write_output(rows, tmp_path)
        reader = _read_rows(tmp_path / "output.csv")
        assert reader[1] == ["case_01", "NOT_APPLICABLE", "[]"]


class TestRowSorting:
    def test_rows_written_sorted_by_case_id(self, tmp_path):
        """Rows are emitted in ascending ``case_id`` order (Requirement 11.3)."""
        rows = [
            CaseResult(case_id="case_10", deletion_status="NOT_APPLICABLE", steps=()),
            CaseResult(case_id="case_02", deletion_status="COMPLETE", steps=()),
            CaseResult(case_id="case_01", deletion_status="INCOMPLETE", steps=()),
        ]
        write_output(rows, tmp_path)
        reader = _read_rows(tmp_path / "output.csv")
        case_ids = [r[0] for r in reader[1:]]
        assert case_ids == ["case_01", "case_02", "case_10"]


class TestBuildRows:
    def test_fills_missing_case_ids_with_not_applicable_default(self):
        """Missing case_ids default to NOT_APPLICABLE with an empty step plan."""
        present = CaseResult(
            case_id="case_02",
            deletion_status="COMPLETE",
            steps=(
                Step(
                    step_no=1,
                    phase="VERIFICATION",
                    system_id="account_service",
                    resource_id="account_001",
                    operation="VERIFY_RECORD_ABSENT",
                    state="ABSENT",
                    evidence_id="evidence_1",
                ),
            ),
        )
        results = {"case_02": present}
        all_case_ids = ["case_03", "case_01", "case_02"]

        rows = build_rows(results, all_case_ids)

        # Every case_id emits exactly one row, sorted ascending.
        assert [r.case_id for r in rows] == ["case_01", "case_02", "case_03"]

        by_id = {r.case_id: r for r in rows}
        # The present result is preserved unchanged.
        assert by_id["case_02"] is present
        # Missing case_ids are defaulted to NOT_APPLICABLE / empty steps.
        assert by_id["case_01"].deletion_status == "NOT_APPLICABLE"
        assert by_id["case_01"].steps == ()
        assert by_id["case_03"].deletion_status == "NOT_APPLICABLE"
        assert by_id["case_03"].steps == ()

    def test_all_present_results_are_returned_sorted(self):
        """When no case_ids are missing, all results pass through, sorted."""
        a = CaseResult(case_id="case_b", deletion_status="COMPLETE", steps=())
        b = CaseResult(case_id="case_a", deletion_status="INCOMPLETE", steps=())
        rows = build_rows({"case_b": a, "case_a": b}, ["case_b", "case_a"])
        assert [r.case_id for r in rows] == ["case_a", "case_b"]
