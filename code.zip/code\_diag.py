"""Temporary diagnostic: dump current vs expected per sample case."""
from __future__ import annotations
import csv, json, sys
from pathlib import Path

_CODE_DIR = Path(__file__).resolve().parent
if str(_CODE_DIR) not in sys.path:
    sys.path.insert(0, str(_CODE_DIR))

from ghost_audit import loaders, pipeline, validate
from ghost_audit.models import Case

root = Path(".").resolve()

def load_sample_cases(root):
    path = root / loaders.DATASET_DIR / "sample_deletion_requests.csv"
    cases = []
    with path.open("r", encoding="utf-8-sig", newline="") as h:
        for row in csv.DictReader(h):
            cases.append(Case(
                case_id=row["case_id"], email=row["email"],
                requested_at=loaders.parse_timestamp(row["requested_at"]),
                reported_status=row["reported_status"],
                reported_at=loaders.parse_timestamp(row["reported_at"]),
                audit_at=loaders.parse_timestamp(row["audit_at"]),
                request_text=row["request_text"]))
    return cases

cases = load_sample_cases(root)
store = loaders.load_identities(root)
rules = loaders.load_rules(root)
manifest = loaders.load_evidence_manifest(root)
all_records, _ = pipeline.dispatch.parse_all(manifest)
file_captured_at = {ef.file_id: ef.captured_at for ef in manifest}
engine = pipeline.select_engine()

sample_rows = validate.load_output_rows(root / loaders.DATASET_DIR / "sample_output.csv")

def fmt_steps(steps):
    return [(s["phase"], s["system_id"], s["resource_id"], s["operation"], s.get("evidence_id","")) for s in steps]

only = sys.argv[1:] if len(sys.argv) > 1 else None
for case in cases:
    if only and case.case_id not in only:
        continue
    result = pipeline.process_case(case, store, rules, all_records, file_captured_at, engine)
    got_steps = [{"step_no": s.step_no, "phase": s.phase, "system_id": s.system_id,
                  "resource_id": s.resource_id, "operation": s.operation, "state": s.state,
                  "evidence_id": s.evidence_id} for s in result.steps]
    exp_status, exp_steps = sample_rows[case.case_id]
    gs = fmt_steps(got_steps)
    es = fmt_steps(exp_steps)
    status_ok = result.deletion_status == exp_status
    steps_ok = gs == es
    mark = "OK " if status_ok and steps_ok else ("S* " if not status_ok else "st ")
    print(f"{mark}{case.case_id}: got={result.deletion_status} exp={exp_status}")
    if not steps_ok:
        print(f"    GOT : {gs}")
        print(f"    EXP : {es}")
