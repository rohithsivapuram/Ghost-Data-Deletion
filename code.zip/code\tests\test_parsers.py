"""Unit tests for the deterministic evidence parsers (task 7.6).

Each parser is exercised with small, self-contained fixtures (tiny strings,
dicts, and a minimal SQLite dump written to ``tmp_path``) so the tests do not
depend on the full dataset. For every parser we assert the extracted,
normalized identifiers, the ``present`` flag, and the raw ``state_signal`` on
the frozen :class:`~ghost_audit.models.ParsedRecord`.

Covers:
- handover text parser (``parse_handover_txt``)
- lookup-trace log parser (``parse_lookup_log``)
- JSON snapshot/service-export parser (``parse_json_records``)
- SQLite ``.sql`` snapshot parser (``parse_sql_snapshot``)

Requirements: 4.1, 4.2, 4.4
"""

from __future__ import annotations

from datetime import datetime, timezone

from ghost_audit.models import ParsedRecord
from ghost_audit.parsers.handover import parse_handover_txt
from ghost_audit.parsers.image import parse_image
from ghost_audit.parsers.json_records import parse_json_records
from ghost_audit.parsers.logs import parse_lookup_log
from ghost_audit.parsers.pdf import parse_pdf
from ghost_audit.parsers.sql import parse_sql_snapshot

FILE_ID = "evidence_test"


def _by_resource(records: list[ParsedRecord]) -> dict[str, ParsedRecord]:
    """Index records by ``resource_id`` for concise per-record assertions."""
    return {r.resource_id: r for r in records}


# ---------------------------------------------------------------------------
# Handover text parser (parse_handover_txt) -- Requirement 4.1
# ---------------------------------------------------------------------------
class TestParseHandoverTxt:
    # A header block plus bullet record lines. One line per state of interest,
    # one record carrying an UPPERCASE email (to check normalization), one
    # record carrying an opaque user_39 reference, and one malformed line.
    TEXT = "\n".join(
        [
            "Shift Handover - 2026-07-16",
            "Outstanding deletion-audit items:",
            "",
            "- 2026-07-16T08:00:00Z | account_service | account_1 | USER_PROFILE | NOT_FOUND | no direct identifier",
            "- 2026-07-16T08:00:00Z | account_service | account_2 | USER_PROFILE | FOUND | Jane.DOE@Example.COM",
            "- 2026-07-16T08:00:00Z | account_service | account_3 | ACCOUNT_TOMBSTONE | ANONYMIZED | no direct identifier",
            "- 2026-07-16T08:00:00Z | integration_service | flow_7 | DATA_FLOW | ACTIVE | sync.OWNER@Example.com",
            "- 2026-07-16T08:00:00Z | account_service | account_9 | USER_PROFILE | FOUND | user_39",
            "- this is a malformed line with no pipes",
            "",
        ]
    )

    def test_record_count_skips_header_and_malformed(self):
        records = parse_handover_txt(self.TEXT, FILE_ID)
        # Five well-formed record lines; header/blank/malformed lines skipped.
        assert len(records) == 5

    def test_not_found_is_absent_with_no_identifiers(self):
        rec = _by_resource(parse_handover_txt(self.TEXT, FILE_ID))["account_1"]
        assert rec.system_id == "account_service"
        assert rec.data_category == "USER_PROFILE"
        assert rec.state_signal == "NOT_FOUND"
        assert rec.present is False
        assert rec.identifiers == frozenset()

    def test_found_email_is_normalized_lowercase(self):
        rec = _by_resource(parse_handover_txt(self.TEXT, FILE_ID))["account_2"]
        assert rec.state_signal == "FOUND"
        assert rec.present is True
        # Uppercase email in the source is lowercased by normalization.
        assert rec.identifiers == frozenset({"jane.doe@example.com"})

    def test_anonymized_tombstone_has_no_identifiers(self):
        rec = _by_resource(parse_handover_txt(self.TEXT, FILE_ID))["account_3"]
        assert rec.data_category == "ACCOUNT_TOMBSTONE"
        assert rec.state_signal == "ANONYMIZED"
        assert rec.present is True
        # "no direct identifier" contributes nothing.
        assert rec.identifiers == frozenset()

    def test_active_data_flow_with_email(self):
        rec = _by_resource(parse_handover_txt(self.TEXT, FILE_ID))["flow_7"]
        assert rec.system_id == "integration_service"
        assert rec.data_category == "DATA_FLOW"
        assert rec.state_signal == "ACTIVE"
        assert rec.present is True
        assert rec.identifiers == frozenset({"sync.owner@example.com"})

    def test_user_id_reference_kept_verbatim(self):
        rec = _by_resource(parse_handover_txt(self.TEXT, FILE_ID))["account_9"]
        assert rec.state_signal == "FOUND"
        assert rec.present is True
        # Opaque user reference is preserved exactly (not lowercased/altered).
        assert rec.identifiers == frozenset({"user_39"})

    def test_observed_at_is_parsed_timestamp(self):
        rec = _by_resource(parse_handover_txt(self.TEXT, FILE_ID))["account_1"]
        assert rec.observed_at == datetime(2026, 7, 16, 8, 0, 0, tzinfo=timezone.utc)
        assert rec.file_id == FILE_ID


# ---------------------------------------------------------------------------
# Lookup-trace log parser (parse_lookup_log) -- Requirements 4.1
# ---------------------------------------------------------------------------
class TestParseLookupLog:
    TEXT = "\n".join(
        [
            # A *_started line that must be skipped (no resolved state).
            "2026-05-01T09:00:00Z level=INFO service=account_service "
            "event=profile_lookup_started resource_id=account_100",
            # 404 -> absent / NOT_FOUND.
            "2026-05-01T09:00:01Z level=INFO service=account_service "
            "event=profile_lookup_completed resource_id=account_100 "
            "lookup_key=Gone.USER@Example.com http_status=404",
            # 200 -> present / FOUND, with an email identifier to normalize.
            "2026-05-01T09:00:02Z level=INFO service=account_service "
            "event=profile_lookup_completed resource_id=account_200 "
            "email=Found.USER@Example.com http_status=200",
            # connector enabled -> ACTIVE.
            "2026-05-01T09:00:03Z level=INFO service=integration_service "
            "event=connector_config_read_completed resource_id=flow_5 enabled=true",
            # restore policy disallowed -> BLOCKED.
            "2026-05-01T09:00:04Z level=INFO service=backup_service "
            "event=restore_policy_read_completed resource_id=backup_9 "
            "restore_allowed=false",
            # index miss -> absent / NOT_FOUND.
            "2026-05-01T09:00:05Z level=INFO service=search_service "
            "event=index_query_completed resource_id=search_3 result=miss",
        ]
    )

    def test_started_line_is_skipped(self):
        records = parse_lookup_log(self.TEXT, FILE_ID)
        # Five *_completed lines resolve to records; the *_started line does not.
        assert len(records) == 5
        assert all(r.resource_id != "account_100" or r.state_signal != "STARTED"
                   for r in records)

    def test_http_404_is_not_found(self):
        rec = _by_resource(parse_lookup_log(self.TEXT, FILE_ID))["account_100"]
        assert rec.system_id == "account_service"
        assert rec.state_signal == "NOT_FOUND"
        assert rec.present is False
        # lookup_key email is normalized even on a NOT_FOUND line.
        assert rec.identifiers == frozenset({"gone.user@example.com"})

    def test_http_200_is_found_with_normalized_email(self):
        rec = _by_resource(parse_lookup_log(self.TEXT, FILE_ID))["account_200"]
        assert rec.system_id == "account_service"
        assert rec.state_signal == "FOUND"
        assert rec.present is True
        assert rec.identifiers == frozenset({"found.user@example.com"})

    def test_connector_enabled_is_active(self):
        rec = _by_resource(parse_lookup_log(self.TEXT, FILE_ID))["flow_5"]
        assert rec.system_id == "integration_service"
        assert rec.state_signal == "ACTIVE"
        assert rec.present is True

    def test_restore_disallowed_is_blocked(self):
        rec = _by_resource(parse_lookup_log(self.TEXT, FILE_ID))["backup_9"]
        assert rec.system_id == "backup_service"
        assert rec.state_signal == "BLOCKED"
        assert rec.present is True

    def test_index_miss_is_not_found(self):
        rec = _by_resource(parse_lookup_log(self.TEXT, FILE_ID))["search_3"]
        assert rec.system_id == "search_service"
        assert rec.state_signal == "NOT_FOUND"
        assert rec.present is False

    def test_resource_and_system_mapping(self):
        records = parse_lookup_log(self.TEXT, FILE_ID)
        # system_id always comes from service=, resource_id from resource_id=.
        assert {r.resource_id for r in records} == {
            "account_100",
            "account_200",
            "flow_5",
            "backup_9",
            "search_3",
        }


# ---------------------------------------------------------------------------
# JSON parser (parse_json_records) -- Requirements 4.1
# ---------------------------------------------------------------------------
class TestParseJsonSnapshotBundle:
    # Shape (A): a snapshot bundle with several collections across systems.
    BUNDLE = {
        "snapshots": [
            {
                "captured_at": "2026-07-16T08:00:00Z",
                "data_store": "account_service",
                "collection": "customer_profiles",
                "records": [
                    {
                        "resource_id": "account_2",
                        "email": "Jane.DOE@Example.COM",
                        "full_name": "Jane Doe",
                    }
                ],
            },
            {
                "captured_at": "2026-07-16T08:00:00Z",
                "data_store": "identity_service",
                "collection": "deleted_customer_references",
                "records": [
                    {
                        "resource_id": "tomb_anon",
                        "name": None,
                        "email": None,
                        "phone": None,
                        "email_hash": None,
                    },
                    {
                        "resource_id": "tomb_pii",
                        "name": None,
                        "email": "Leftover.USER@Example.com",
                        "phone": None,
                        "email_hash": None,
                    },
                ],
            },
            {
                "captured_at": "2026-07-16T08:00:00Z",
                "data_store": "integration_service",
                "collection": "connector_configurations",
                "records": [{"resource_id": "flow_1", "enabled": True}],
            },
            {
                "captured_at": "2026-07-16T08:00:00Z",
                "data_store": "backup_service",
                "collection": "backup_catalog",
                "records": [{"resource_id": "backup_1", "restore_allowed": True}],
            },
        ]
    }

    def test_profile_record_found_with_normalized_email(self):
        rec = _by_resource(parse_json_records(self.BUNDLE, FILE_ID))["account_2"]
        assert rec.system_id == "account_service"
        assert rec.data_category == "USER_PROFILE"
        assert rec.state_signal == "FOUND"
        assert rec.present is True
        assert "jane.doe@example.com" in rec.identifiers

    def test_tombstone_all_null_is_anonymized(self):
        rec = _by_resource(parse_json_records(self.BUNDLE, FILE_ID))["tomb_anon"]
        assert rec.data_category == "ACCOUNT_TOMBSTONE"
        assert rec.state_signal == "ANONYMIZED"
        assert rec.identifiers == frozenset()

    def test_tombstone_with_email_is_identifiable(self):
        rec = _by_resource(parse_json_records(self.BUNDLE, FILE_ID))["tomb_pii"]
        assert rec.data_category == "ACCOUNT_TOMBSTONE"
        assert rec.state_signal == "IDENTIFIABLE"
        assert rec.identifiers == frozenset({"leftover.user@example.com"})

    def test_connector_enabled_is_active(self):
        rec = _by_resource(parse_json_records(self.BUNDLE, FILE_ID))["flow_1"]
        assert rec.data_category == "DATA_FLOW"
        assert rec.state_signal == "ACTIVE"

    def test_backup_restore_allowed_is_active(self):
        rec = _by_resource(parse_json_records(self.BUNDLE, FILE_ID))["backup_1"]
        assert rec.data_category == "BACKUP_ARCHIVE"
        assert rec.state_signal == "ACTIVE"


class TestParseJsonServiceExport:
    # Shape (B): account_service profile_lookups with a 404 and a 200.
    EXPORT = {
        "service_exports": {
            "account_service": {
                "profile_lookups": [
                    {
                        "resource_id": "account_404",
                        "observed_at": "2026-07-16T08:00:00Z",
                        "status_code": 404,
                    },
                    {
                        "resource_id": "account_200",
                        "observed_at": "2026-07-16T08:00:00Z",
                        "status_code": 200,
                        "profile": {"email": "Nested.USER@Example.com"},
                    },
                ]
            }
        }
    }

    def test_status_404_is_not_found(self):
        rec = _by_resource(parse_json_records(self.EXPORT, FILE_ID))["account_404"]
        assert rec.system_id == "account_service"
        assert rec.state_signal == "NOT_FOUND"
        assert rec.present is False

    def test_status_200_is_found_with_nested_email_normalized(self):
        rec = _by_resource(parse_json_records(self.EXPORT, FILE_ID))["account_200"]
        assert rec.system_id == "account_service"
        assert rec.state_signal == "FOUND"
        assert rec.present is True
        assert rec.identifiers == frozenset({"nested.user@example.com"})


# ---------------------------------------------------------------------------
# SQL snapshot parser (parse_sql_snapshot) -- Requirements 4.2, 4.4
# ---------------------------------------------------------------------------
class TestParseSqlInventory:
    # Inventory dump: snapshot_scope + a few typed category tables.
    SQL = """
    CREATE TABLE snapshot_scope (
        origin_system TEXT,
        captured_at TEXT
    );
    INSERT INTO snapshot_scope VALUES ('account_service', '2026-07-16T08:00:00Z');
    INSERT INTO snapshot_scope VALUES ('integration_service', '2026-07-16T08:00:00Z');
    INSERT INTO snapshot_scope VALUES ('backup_service', '2026-07-16T08:00:00Z');

    CREATE TABLE customer_profiles (
        resource_id TEXT,
        email TEXT,
        full_name TEXT,
        updated_at TEXT
    );
    INSERT INTO customer_profiles VALUES
        ('account_2', 'Jane.DOE@Example.COM', 'Jane Doe', '2026-07-16T08:00:00Z');

    CREATE TABLE connector_subscriptions (
        resource_id TEXT,
        enabled INTEGER,
        updated_at TEXT
    );
    INSERT INTO connector_subscriptions VALUES ('flow_1', 1, '2026-07-16T08:00:00Z');

    CREATE TABLE backup_restore_entries (
        resource_id TEXT,
        restore_allowed INTEGER,
        updated_at TEXT
    );
    INSERT INTO backup_restore_entries VALUES ('backup_1', 0, '2026-07-16T08:00:00Z');
    """

    def _write(self, tmp_path):
        path = tmp_path / "inventory.sql"
        path.write_text(self.SQL, encoding="utf-8")
        return path

    def test_profile_system_category_and_normalized_email(self, tmp_path):
        rec = _by_resource(parse_sql_snapshot(self._write(tmp_path), FILE_ID))[
            "account_2"
        ]
        assert rec.system_id == "account_service"
        assert rec.data_category == "USER_PROFILE"
        assert rec.state_signal == "FOUND"
        assert rec.present is True
        assert "jane.doe@example.com" in rec.identifiers

    def test_connector_enabled_is_active(self, tmp_path):
        rec = _by_resource(parse_sql_snapshot(self._write(tmp_path), FILE_ID))[
            "flow_1"
        ]
        assert rec.system_id == "integration_service"
        assert rec.data_category == "DATA_FLOW"
        assert rec.state_signal == "ACTIVE"

    def test_backup_restore_blocked(self, tmp_path):
        rec = _by_resource(parse_sql_snapshot(self._write(tmp_path), FILE_ID))[
            "backup_1"
        ]
        assert rec.system_id == "backup_service"
        assert rec.data_category == "BACKUP_ARCHIVE"
        assert rec.state_signal == "BLOCKED"


class TestParseSqlReplica:
    # Replica dump: a primary and a read-replica table, both with record_json
    # holding an inner customer_profiles record. Replication drift means both
    # tables yield a record for the same resource.
    SQL = """
    CREATE TABLE customer_data_primary (
        resource_id TEXT,
        origin_system TEXT,
        collection_name TEXT,
        record_json TEXT,
        updated_at TEXT
    );
    INSERT INTO customer_data_primary VALUES (
        'account_2',
        'account_service',
        'customer_profiles',
        '{"resource_id": "account_2", "email": "Jane.DOE@Example.COM"}',
        '2026-07-16T08:00:00Z'
    );

    CREATE TABLE customer_data_read_replica (
        resource_id TEXT,
        origin_system TEXT,
        collection_name TEXT,
        record_json TEXT,
        updated_at TEXT
    );
    INSERT INTO customer_data_read_replica VALUES (
        'account_2',
        'account_service',
        'customer_profiles',
        '{"resource_id": "account_2", "email": "Jane.DOE@Example.COM"}',
        '2026-07-16T08:00:00Z'
    );
    """

    def _write(self, tmp_path):
        path = tmp_path / "replica.sql"
        path.write_text(self.SQL, encoding="utf-8")
        return path

    def test_both_tables_produce_records(self, tmp_path):
        records = parse_sql_snapshot(self._write(tmp_path), FILE_ID)
        # Replication drift: primary + replica each emit a record for account_2.
        assert len(records) == 2
        tables = {r.raw["table"] for r in records}
        assert tables == {"customer_data_primary", "customer_data_read_replica"}

    def test_category_system_and_inner_email_normalized(self, tmp_path):
        records = parse_sql_snapshot(self._write(tmp_path), FILE_ID)
        for rec in records:
            assert rec.resource_id == "account_2"
            assert rec.data_category == "USER_PROFILE"
            assert rec.system_id == "account_service"  # from origin_system
            assert rec.identifiers == frozenset({"jane.doe@example.com"})
            assert rec.present is True


# ---------------------------------------------------------------------------
# Optional PDF parser (parse_pdf) -- Requirements 4.3, 4.5
# ---------------------------------------------------------------------------
class TestParsePdf:
    def _write_pdf(self, tmp_path, name: str, body: bytes):
        path = tmp_path / name
        path.write_bytes(body)
        return path

    def test_recovers_email_from_uncompressed_stream(self, tmp_path):
        # A minimal PDF content stream with a parenthesized email token plus a
        # YYYYMMDD date in the filename for the observation time.
        body = b"%PDF-1.4\nBT (Customer Jane.DOE@Example.COM) Tj ET\n%%EOF"
        path = self._write_pdf(tmp_path, "account_history_report_20260718.pdf", body)
        records = parse_pdf(path, FILE_ID)
        assert len(records) == 1
        rec = records[0]
        assert rec.state_signal == "FOUND"
        assert rec.present is True
        assert "jane.doe@example.com" in rec.identifiers
        assert rec.observed_at == datetime(2026, 7, 18, tzinfo=timezone.utc)
        assert rec.resource_id == "account_history_report_20260718"
        assert rec.file_id == FILE_ID

    def test_recovers_opaque_reference(self, tmp_path):
        body = b"%PDF-1.4\nBT (subject user_39 record) Tj ET\n%%EOF"
        path = self._write_pdf(tmp_path, "handover_doc_20260310.pdf", body)
        records = parse_pdf(path, FILE_ID)
        assert len(records) == 1
        assert records[0].identifiers == frozenset({"user_39"})

    def test_no_identifiers_returns_empty(self, tmp_path):
        # Readable text but no identifiers -> "no facts extracted".
        body = b"%PDF-1.4\nBT (Quarterly summary of operations) Tj ET\n%%EOF"
        path = self._write_pdf(tmp_path, "summary_20260718.pdf", body)
        assert parse_pdf(path, FILE_ID) == []

    def test_identifier_without_filename_date_returns_empty(self, tmp_path):
        # An identifier is present but there is no grounded observation time.
        body = b"%PDF-1.4\nBT (user_39) Tj ET\n%%EOF"
        path = self._write_pdf(tmp_path, "undated_document.pdf", body)
        assert parse_pdf(path, FILE_ID) == []

    def test_missing_file_returns_empty_and_does_not_raise(self, tmp_path):
        missing = tmp_path / "does_not_exist_20260718.pdf"
        assert parse_pdf(missing, FILE_ID) == []

    def test_binary_garbage_returns_empty(self, tmp_path):
        path = self._write_pdf(tmp_path, "garbage_20260718.pdf", b"\x00\x01\x02\x03")
        assert parse_pdf(path, FILE_ID) == []


# ---------------------------------------------------------------------------
# Optional image parser (parse_image) -- Requirements 4.3, 4.5
# ---------------------------------------------------------------------------
class TestParseImage:
    def test_deterministic_default_returns_empty(self, tmp_path):
        path = tmp_path / "account_admin_console_20260926.png"
        path.write_bytes(b"\x89PNG\r\n\x1a\n")
        assert parse_image(path, FILE_ID) == []

    def test_missing_file_returns_empty_and_does_not_raise(self, tmp_path):
        missing = tmp_path / "nope.png"
        assert parse_image(missing, FILE_ID) == []
