"""Output validator and sample-set comparison (Requirements 12.1-12.8, 13.3).

This module checks that a produced ``output.csv`` conforms to the output
contract (AGENTS.md §6.3) and, for the public sample set, compares the agent's
output against ``sample_output.csv``.

Validation (``validate_output``)
--------------------------------

``validate_output(root, requests)`` reads ``root/"output.csv"`` and returns a
list of :class:`Violation` values -- one per contract breach -- rather than
raising, so every problem in the file is reported at once (Requirement 12.8).
An empty list means the file is fully valid. The checks are:

- the header equals ``case_id,deletion_status,steps_json`` (Requirement 12.1);
- there are exactly ``len(requests)`` data rows (518 for the full set,
  Requirement 12.1);
- each ``case_id`` appears exactly once and matches a request ``case_id``
  (Requirement 12.2);
- each ``deletion_status`` is one of ``COMPLETE``/``INCOMPLETE``/
  ``NOT_APPLICABLE`` (Requirement 12.3);
- each ``steps_json`` parses as a JSON array whose ``step_no`` values are
  ``1..N`` with no gaps (Requirement 12.4);
- each step object carries exactly the seven contract fields (Requirement 11.4);
- ``NOT_APPLICABLE`` rows have an empty ``steps_json`` array (Requirement 12.5);
- ``COMPLETE`` rows contain only ``VERIFICATION`` steps, each citing a non-empty
  ``evidence_id`` (Requirement 12.6);
- for ``INCOMPLETE`` rows, every ``REMEDIATION`` and ``VERIFICATION`` step has an
  empty ``evidence_id`` while every ``FINDING`` step has a non-empty
  ``evidence_id`` (Requirements 12.7, 9.4).

Sample comparison (``compare_to_sample``)
-----------------------------------------

``compare_to_sample`` accepts two dicts mapping ``case_id`` to
``(deletion_status, steps_list)`` where ``steps_list`` is a list of already
parsed step dicts, and returns a :class:`SampleReport`. JSON object-key order
and whitespace are irrelevant because steps are compared as parsed data
normalized to the seven contract fields, while array order is significant
(Requirement 13.3). ``load_output_rows`` is a convenience that reads a CSV with
the contract header and parses each ``steps_json`` via ``json.loads`` into that
shape.
"""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass, field
from pathlib import Path

from .models import Case
from .serialize import OUTPUT_HEADER, STEP_FIELDS

__all__ = [
    "Violation",
    "SampleReport",
    "validate_output",
    "compare_to_sample",
    "load_output_rows",
]

# The allowed values of the deletion_status column (Requirement 12.3).
_VALID_STATUSES = frozenset({"COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"})

# The exact, sorted set of fields each serialized step object must carry.
_STEP_FIELD_SET = frozenset(STEP_FIELDS)


@dataclass(frozen=True)
class Violation:
    """A single output-contract breach (Requirement 12.8).

    ``case_id`` identifies the offending row, or is ``""`` for a file-level
    problem (wrong header, wrong row count). ``check`` is a short name of the
    failed check and ``detail`` carries human-readable specifics.
    """

    case_id: str
    check: str
    detail: str


@dataclass(frozen=True)
class SampleReport:
    """The result of comparing agent output to ``sample_output.csv`` (Req 13.3)."""

    total: int
    status_matches: int
    status_mismatches: list[tuple[str, str, str]] = field(default_factory=list)
    step_mismatches: list[str] = field(default_factory=list)

    def summary(self) -> str:
        """A one-line human-readable summary of the comparison."""
        return (
            f"{self.status_matches}/{self.total} status matches, "
            f"{len(self.status_mismatches)} status mismatches, "
            f"{len(self.step_mismatches)} step-array mismatches"
        )


def _normalize_step(step: dict) -> dict:
    """Project a step dict onto exactly the seven contract fields.

    Extra keys are dropped and object-key order is irrelevant (dict equality is
    order-independent), so two steps compare equal iff their seven contract
    fields are equal (Requirement 13.3).
    """
    return {field_name: step.get(field_name) for field_name in STEP_FIELDS}


def _parse_steps_cell(cell: str):
    """Parse a ``steps_json`` CSV cell, returning ``(parsed, error)``.

    ``parsed`` is the decoded JSON value on success (``error`` is ``None``); on
    a JSON error ``parsed`` is ``None`` and ``error`` is the message string.
    """
    try:
        return json.loads(cell), None
    except (json.JSONDecodeError, ValueError) as exc:
        return None, str(exc)


def _check_step_numbering(steps: list) -> str | None:
    """Return an error message if ``step_no`` values are not ``1..N``.

    Consecutive integers starting at 1 with no gaps or repeats (Req 12.4).
    """
    expected = list(range(1, len(steps) + 1))
    actual = [step.get("step_no") for step in steps]
    if actual != expected:
        return f"expected step_no {expected}, got {actual}"
    return None


def _validate_row_steps(case_id: str, status: str, steps: list) -> list[Violation]:
    """Validate a single row's parsed step array against the contract."""
    violations: list[Violation] = []

    # Every step object carries exactly the seven contract fields (Req 11.4).
    for step in steps:
        if not isinstance(step, dict):
            violations.append(
                Violation(case_id, "step_schema", f"step is not an object: {step!r}")
            )
            continue
        if frozenset(step.keys()) != _STEP_FIELD_SET:
            violations.append(
                Violation(
                    case_id,
                    "step_schema",
                    f"step fields {sorted(step.keys())} != {sorted(STEP_FIELDS)}",
                )
            )

    # Consecutive step_no starting at 1 (Requirement 12.4).
    numbering_error = _check_step_numbering(steps)
    if numbering_error is not None:
        violations.append(Violation(case_id, "step_numbering", numbering_error))

    if status == "NOT_APPLICABLE":
        # NOT_APPLICABLE => steps_json is an empty array (Requirement 12.5).
        if steps:
            violations.append(
                Violation(
                    case_id,
                    "not_applicable_nonempty",
                    f"NOT_APPLICABLE must have empty steps, got {len(steps)}",
                )
            )
    elif status == "COMPLETE":
        # COMPLETE => every step is a VERIFICATION step citing non-empty
        # evidence_id (Requirement 12.6).
        for step in steps:
            if not isinstance(step, dict):
                continue
            if step.get("phase") != "VERIFICATION":
                violations.append(
                    Violation(
                        case_id,
                        "complete_non_verification",
                        f"COMPLETE step phase={step.get('phase')!r} is not VERIFICATION",
                    )
                )
            if not step.get("evidence_id"):
                violations.append(
                    Violation(
                        case_id,
                        "complete_empty_evidence",
                        "COMPLETE VERIFICATION step has empty evidence_id",
                    )
                )
    elif status == "INCOMPLETE":
        # INCOMPLETE => FINDING steps cite non-empty evidence; REMEDIATION and
        # VERIFICATION steps have empty evidence_id (Requirements 12.7, 9.4).
        for step in steps:
            if not isinstance(step, dict):
                continue
            phase = step.get("phase")
            evidence_id = step.get("evidence_id")
            if phase == "FINDING":
                if not evidence_id:
                    violations.append(
                        Violation(
                            case_id,
                            "incomplete_finding_empty_evidence",
                            "INCOMPLETE FINDING step has empty evidence_id",
                        )
                    )
            elif phase in ("REMEDIATION", "VERIFICATION"):
                if evidence_id != "":
                    violations.append(
                        Violation(
                            case_id,
                            "incomplete_future_nonempty_evidence",
                            f"INCOMPLETE {phase} step evidence_id must be empty, "
                            f"got {evidence_id!r}",
                        )
                    )

    return violations


def validate_output(root: Path, requests: list[Case]) -> list[Violation]:
    """Validate ``root/"output.csv"`` against the contract (Requirements 12.1-12.8).

    Returns a list of :class:`Violation` values (empty when fully valid). Every
    detected problem is collected and reported rather than raising so a single
    pass surfaces all violations with their ``case_id`` and failed check
    (Requirement 12.8).
    """
    violations: list[Violation] = []
    path = Path(root) / "output.csv"

    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        rows = list(reader)

    if not rows:
        violations.append(Violation("", "empty_file", "output.csv is empty"))
        return violations

    # Header check (Requirement 12.1).
    header = tuple(rows[0])
    if header != OUTPUT_HEADER:
        violations.append(
            Violation(
                "",
                "header",
                f"header {list(header)} != {list(OUTPUT_HEADER)}",
            )
        )

    data_rows = rows[1:]

    # Row-count check (Requirement 12.1).
    if len(data_rows) != len(requests):
        violations.append(
            Violation(
                "",
                "row_count",
                f"expected {len(requests)} data rows, got {len(data_rows)}",
            )
        )

    known_case_ids = {case.case_id for case in requests}
    seen: dict[str, int] = {}

    for data_row in data_rows:
        if len(data_row) != 3:
            violations.append(
                Violation(
                    data_row[0] if data_row else "",
                    "malformed_row",
                    f"expected 3 columns, got {len(data_row)}: {data_row!r}",
                )
            )
            continue

        case_id, status, steps_cell = data_row
        seen[case_id] = seen.get(case_id, 0) + 1

        # Known case_id check (Requirement 12.2). Uniqueness is reported once
        # below after the full pass.
        if case_id not in known_case_ids:
            violations.append(
                Violation(case_id, "unknown_case_id", "case_id not in requests")
            )

        # deletion_status check (Requirement 12.3).
        if status not in _VALID_STATUSES:
            violations.append(
                Violation(
                    case_id,
                    "invalid_status",
                    f"deletion_status {status!r} not in {sorted(_VALID_STATUSES)}",
                )
            )

        # steps_json parses as a JSON array (Requirement 12.4).
        parsed, error = _parse_steps_cell(steps_cell)
        if error is not None:
            violations.append(
                Violation(case_id, "steps_json_parse", f"invalid JSON: {error}")
            )
            continue
        if not isinstance(parsed, list):
            violations.append(
                Violation(
                    case_id,
                    "steps_json_not_array",
                    f"steps_json is {type(parsed).__name__}, not an array",
                )
            )
            continue

        # Only run structural/status-specific checks for known valid statuses;
        # invalid-status rows already have a violation recorded.
        if status in _VALID_STATUSES:
            violations.extend(_validate_row_steps(case_id, status, parsed))

    # Uniqueness check (Requirement 12.2): each case_id appears exactly once.
    for case_id, count in seen.items():
        if count > 1:
            violations.append(
                Violation(
                    case_id,
                    "duplicate_case_id",
                    f"case_id appears {count} times",
                )
            )

    return violations


def load_output_rows(path: Path) -> dict[str, tuple[str, list[dict]]]:
    """Read a contract CSV into ``{case_id: (deletion_status, steps_list)}``.

    The CSV must have the header ``case_id,deletion_status,steps_json``; each
    ``steps_json`` cell is parsed via :func:`json.loads` into a list of step
    dicts. Used to load both agent output and ``sample_output.csv`` for
    :func:`compare_to_sample`.
    """
    result: dict[str, tuple[str, list[dict]]] = {}
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            steps = json.loads(row["steps_json"])
            result[row["case_id"]] = (row["deletion_status"], steps)
    return result


def compare_to_sample(
    output_rows: dict[str, tuple[str, list[dict]]],
    sample_rows: dict[str, tuple[str, list[dict]]],
) -> SampleReport:
    """Compare agent output to the sample answers (Requirement 13.3).

    Both arguments map ``case_id`` to ``(deletion_status, steps_list)`` where
    ``steps_list`` is a list of already-parsed step dicts. Object-key order and
    whitespace are irrelevant (steps compare as data normalized to the seven
    contract fields) while array order is significant: a difference at any index
    marks that case a step mismatch.

    Returns a :class:`SampleReport` with the status-match count, the list of
    status mismatches as ``(case_id, expected, got)``, and the list of
    ``case_id`` whose step arrays differ. The comparison is keyed on the sample
    ``case_id`` set.
    """
    status_matches = 0
    status_mismatches: list[tuple[str, str, str]] = []
    step_mismatches: list[str] = []

    for case_id in sample_rows:
        expected_status, expected_steps = sample_rows[case_id]
        if case_id not in output_rows:
            status_mismatches.append((case_id, expected_status, "<missing>"))
            step_mismatches.append(case_id)
            continue

        got_status, got_steps = output_rows[case_id]

        if got_status == expected_status:
            status_matches += 1
        else:
            status_mismatches.append((case_id, expected_status, got_status))

        expected_norm = [_normalize_step(step) for step in expected_steps]
        got_norm = [_normalize_step(step) for step in got_steps]
        if expected_norm != got_norm:
            step_mismatches.append(case_id)

    return SampleReport(
        total=len(sample_rows),
        status_matches=status_matches,
        status_mismatches=status_mismatches,
        step_mismatches=step_mismatches,
    )
