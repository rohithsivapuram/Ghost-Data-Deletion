"""Pytest configuration.

Ensures the ``code/`` directory (this file's directory) is on ``sys.path`` so
tests can ``import ghost_audit`` regardless of the directory pytest is invoked
from.
"""

import os
import sys

_CODE_DIR = os.path.dirname(os.path.abspath(__file__))
if _CODE_DIR not in sys.path:
    sys.path.insert(0, _CODE_DIR)
